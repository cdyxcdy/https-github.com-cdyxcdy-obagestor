# MEU CONTROLE

FAÇA UM APLICATIVO DE CONTROLE FINANCEIRO. RETIRAR LOGO LOVABLE.

QUERO QUE TENHA ABAS NAS CORES 3D EDITAVÉIS: RENDA TOTAL,CARTÕES, RELATÓRIOS,RECEITAS E GASTOS E PERFIL.

TODOS COM FUNÇÃO DE EDITAR E EXCLUÍR.

EMBAIXO QUERO: INICIO, LANÇAMENTOS, ORÇAMENTOS, CONTAS, METAS E BATE-PAPO SIMPLES

COM ENVIO DE FOTOS E MENSAGEM PODENDO SER DELETADAS SEGURANDO POR 2 SEGUNDOS,LIBERAR EMOGIS.

NA ABA DE PERFIL COLOCAR EDITÁVEL: MOEDA PADRÃO REAL, DÓLAR OU EURO.

NA ABA DE CARTÕES COLOCAR JÁ PRA ESCOLHA: BANCO SANTDER, BANCO DO BRASIL,

BANCO MERCADO PAGO, BANCO NUBANK, BANCO INTER, BANCO C6, BANCO PICPAY, BANCO SAFRA,

BANCO SICOOB, BANCO ITAÚ. E TODOS COM VALORES INVESTIDOS EDITÁVEIS.

NA ABA DE RENDA TOTAL COLOCAR: GASTOS TOTAIS, DESCONTOS(EDITÁVEL), VALOR TOTAL

EM CONTA(EDITÁVEL).

CRIAR EM RENDA TOTAL: INVESTIMENTOS FINACEIROS PODENDO SER EDITÁVEL, BANCOS, PORCENTAGEM, VALORES,

RETIRADA, INVESTIDOS, TRANSFERIDO. TAMBÉM O VALOR TOTAL DE RENDIMENTOS E

VALOR TOTAL DE INVESTIMENTOS DE TODOS BANCOS.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://obagestor.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/baba826a-1a6d-4dbd-8535-977b385c3f01).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
