# Sincronização em tempo real entre dispositivos

## O que será criado
- Entrada segura por e-mail e senha, com opção de entrar pelo Google.
- Dados financeiros privados para cada pessoa.
- Sincronização automática de renda, cartões, investimentos, lançamentos, orçamentos, contas, metas, perfil e notificações.
- Atualizações em tempo real: uma alteração no celular aparecerá no computador e no tablet conectados à mesma conta.
- Estado de conexão e salvamento visível, com funcionamento seguro quando a conexão oscilar.
- Migração inicial dos dados já salvos no aparelho para a conta, sem duplicá-los.

## Segurança
- Cada conta poderá consultar e alterar somente os próprios dados.
- As regras de privacidade serão aplicadas diretamente no banco de dados.
- Fotos das metas também ficarão vinculadas à conta correspondente.

## Detalhes técnicos
- Criar uma tabela de estado financeiro por usuário, com permissões de leitura, criação e atualização limitadas ao proprietário.
- Ativar atualizações em tempo real nessa tabela.
- Colocar o painel na área protegida do aplicativo e criar uma tela pública de acesso.
- Substituir a persistência exclusiva do navegador pela nuvem, mantendo o armazenamento local apenas para migração e tolerância temporária à conexão.
- Validar os dados recebidos e enviados antes de salvar.
- Testar entrada, migração, edição e atualização em duas sessões simultâneas.
