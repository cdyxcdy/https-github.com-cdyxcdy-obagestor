# Baixar relatório em PDF

## Objetivo
Adicionar à aba **Relatórios** um botão para baixar em PDF os dados do dia ou mês selecionado.

## Alterações
- Incluir o botão **Baixar PDF** junto ao filtro do relatório, com bom encaixe no celular.
- Gerar o arquivo diretamente no aparelho, mantendo os dados financeiros privados.
- Incluir no PDF: período escolhido, total de receitas, total de gastos, saldo do período, gastos por categoria e todos os lançamentos filtrados.
- Criar páginas adicionais automaticamente quando houver muitos lançamentos.
- Usar a moeda escolhida no perfil e um nome de arquivo baseado no período.
- Exibir estado vazio no documento quando não houver lançamentos no período.

## Detalhes técnicos
- Usar uma biblioteca de PDF compatível com o navegador e carregá-la somente ao tocar no botão, evitando aumentar desnecessariamente o carregamento inicial.
- Preservar os filtros e cálculos atuais da aba.
- Validar o download e a apresentação no tamanho de tela do celular, além de verificar a compilação do aplicativo.
