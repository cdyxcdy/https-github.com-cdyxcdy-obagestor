# Aplicativo de controle financeiro

## O que será criado
- Painel inicial em português com visual moderno, colorido e efeito 3D, sem marca Lovable.
- Abas superiores: Renda Total, Cartões, Relatórios, Receitas e Gastos e Perfil.
- Navegação inferior: Início, Lançamentos, Orçamentos, Contas, Metas e Bate-papo.
- Edição e exclusão nos registros financeiros, cartões, investimentos, orçamentos, contas e metas.
- Perfil editável com moeda padrão em real, dólar ou euro.
- Cartões dos dez bancos solicitados, cada um com valor investido editável.
- Resumo de renda com gastos totais, descontos, saldo em conta, rendimentos e investimentos consolidados.
- Investimentos por banco com porcentagem, valores, retiradas, investidos e transferidos.
- Bate-papo simples com mensagens, emojis, envio de fotos e exclusão ao segurar por 2 segundos.

## Experiência visual
- Interface mobile-first, também adaptada para telas grandes.
- Fundo claro, textos de alto contraste e cartões com cores distintas e profundidade 3D.
- Gráficos e resumos fáceis de ler, com valores formatados na moeda escolhida.

## Detalhes técnicos
- Dados do aplicativo persistidos no navegador para o protótipo funcional imediato.
- Fotos do bate-papo armazenadas localmente no dispositivo.
- Lovable Cloud ativado para futura sincronização, contas de usuário e armazenamento compartilhado.
- Metadados próprios do aplicativo e favicon neutro, sem a marca Lovable.
