# Totais de investimentos e despesas fixas

## O que será alterado
- Fazer **Total investido** somar somente o campo **Investido** de todos os bancos cadastrados em Investimentos financeiros.
- Fazer **Rendimento mensal** somar o ganho mensal de todos esses bancos: valor investido × porcentagem mensal.
- Manter **Renda total** ligada ao valor editável de **Total em conta**.
- Remover **Orçamentos** e **Contas** da navegação inferior.
- Adicionar a aba **Despesas fixas** com inclusão, edição e exclusão.
- Cada despesa será recorrente por mês, com nome, valor e dia de vencimento.
- Adicionar o botão **Marcar como pago**. Ao confirmar, o valor será descontado uma única vez do **Total em conta** no mês atual.
- Exibir o mês atual e o estado **Pago/Pendente**; no mês seguinte, a despesa volta automaticamente a ficar pendente.

## Sincronização e segurança
- Sincronizar investimentos, totais, despesas fixas e pagamentos entre web, celular e tablet.
- Registrar cada pagamento de forma atômica na conta do usuário, evitando desconto duplicado ou conflito entre aparelhos.
- Preservar os dados antigos durante a troca das abas.

## Validação
- Testar os cálculos dos totais com vários bancos.
- Testar criação, edição, exclusão e renovação mensal das despesas.
- Testar o pagamento simultaneamente em dois aparelhos e confirmar apenas um desconto no saldo.
- Conferir a navegação e o encaixe em celular e computador.

## Detalhes técnicos
- Ampliar o estado financeiro validado com despesas fixas e histórico mensal de pagamentos.
- Criar operações protegidas para alterar uma despesa e registrar pagamento junto com a redução do saldo em uma única transação.
- Atualizar a navegação inferior para quatro itens: Início, Lançamentos, Despesas fixas e Metas.
