# Mover a calculadora para a navegação inferior

## Alteração
- Remover a calculadora de conversão da área **Moedas** na tela inicial.
- Criar a aba inferior **Conversão**, ao lado de **Metas**.
- Manter na nova aba as mesmas conversões entre Real, Dólar e Euro e as mesmas cotações automáticas ou manuais já configuradas.
- Manter as despesas do exterior na área **Moedas**, abaixo dos valores em Dólar e Euro.

## Validação
- Conferir no celular que a barra inferior mostra quatro abas sem cortes.
- Testar uma conversão e confirmar que o resultado usa a cotação atual selecionada.
