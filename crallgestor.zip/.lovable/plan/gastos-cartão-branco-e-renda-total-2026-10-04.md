# Gastos, cartão branco e Renda total

## Alterações
- Ao criar um lançamento do tipo **gasto**, descontar seu valor de **Total em conta**.
- Ao editar um gasto, aplicar somente a diferença do valor; ao excluir, devolver o valor ao saldo.
- Não alterar o saldo automaticamente para lançamentos do tipo receita, conforme solicitado.
- Fazer essas operações de forma atômica para evitar descontos duplicados ou conflitos entre celular, tablet e web.
- Remover o bloco **Descontos** da tela **Renda total** e reorganizar os blocos restantes.
- Deixar todas as letras dos cartões de cor **Branco** em negrito e com contraste adequado.

## Validação
- Testar inclusão, edição e exclusão de gastos e conferir o Total em conta.
- Testar a mesma alteração em duas sessões para confirmar a sincronização.
- Conferir o cartão branco e a tela Renda total no celular.

## Detalhes técnicos
- Manter o campo antigo de descontos apenas para compatibilidade dos dados salvos, sem exibi-lo na interface.
- Criar uma operação protegida para mutar um lançamento e ajustar o saldo na mesma transação.
