# Ajustes em investimentos e navegação

## Alterações
- Remover o campo e a informação **Transferido** dos investimentos, preservando os demais dados já salvos.
- Calcular o **Rendimento mensal** sobre o capital líquido: `(Investido − Retirada) × porcentagem mensal`, sem permitir base negativa.
- Aplicar a mesma fórmula ao total geral e ao rendimento exibido em cada banco.
- Remover apenas a aba inferior **Lançamentos**; manter **Receitas e gastos** na parte superior para registrar e consultar movimentações.
- Ajustar a navegação inferior para três itens: **Início**, **Despesas fixas** e **Metas**.
- Fazer o atalho de últimos lançamentos abrir **Receitas e gastos**.

## Validação e publicação
- Conferir a nova fórmula e a navegação no celular.
- Verificar que o aplicativo continua compilando sem erros.
- Publicar a atualização e enviar o link do aplicativo para celular.
