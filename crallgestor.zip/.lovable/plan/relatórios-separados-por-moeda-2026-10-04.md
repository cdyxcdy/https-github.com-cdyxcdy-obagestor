# Relatórios separados por moeda

## Relatórios no aplicativo
- Remover a conversão automática dos gastos em Real para Dólar e Euro.
- Considerar como gastos em **Real** somente os lançamentos do tipo gasto em Receitas e gastos.
- Considerar como gastos em **Dólar** somente as despesas do exterior em USD do período.
- Considerar como gastos em **Euro** somente as despesas do exterior em EUR do período.
- Manter cada total independente, sem alterar ou recalcular as outras moedas.

## PDF geral
- Gerar um único PDF para o dia ou mês selecionado.
- Mostrar os totais separados em Real, Dólar e Euro, sem conversão cambial.
- Organizar os gastos em seções por categoria.
- Listar os lançamentos em Real por categoria e as despesas exteriores nas categorias Dólar e Euro.

## Validação
- Conferir os três totais independentes na tela de Relatórios.
- Baixar o PDF no celular e revisar todas as páginas, categorias e valores.
