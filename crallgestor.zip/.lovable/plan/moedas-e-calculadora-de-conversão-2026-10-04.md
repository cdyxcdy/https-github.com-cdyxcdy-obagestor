# Moedas e calculadora de conversão

## O que será adicionado
- Criar, abaixo dos investimentos, uma área **Moedas** com **Dólar** e **Euro**.
- Permitir editar o valor investido em cada moeda.
- Mostrar o equivalente em Real usando a cotação escolhida.
- Adicionar uma calculadora para converter entre Real, Dólar e Euro.

## Cotações
- Buscar automaticamente as cotações atuais de Dólar e Euro.
- Permitir substituir cada cotação por um valor manual editável.
- Incluir uma ação para voltar à cotação automática.
- Exibir quando a cotação foi atualizada e usar o último valor disponível se a consulta estiver indisponível.

## Sincronização e validação
- Sincronizar valores investidos e cotações manuais entre celular, tablet e web.
- Manter a consulta automática privada e sem exigir chave do usuário.
- Validar a nova área e a calculadora no celular.
