import { useEffect, useRef } from 'react';
import { useRouter } from '@tanstack/react-router';

const overlayKey = '__obaOverlay';
let overlaySequence = 0;
const overlays: number[] = [];

/** Adds a transient history entry so native Back dismisses the topmost window. */
export function useAppBack(onClose: () => void, active = true) {
  const router = useRouter({ warn: false });
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!active) return;
    const token = ++overlaySequence;
    const history = router?.history;
    let alive = true;
    let pushed = false;
    queueMicrotask(() => {
      if (!alive) return;
      const ignored = history?._ignoreSubscribers;
      if (history) history._ignoreSubscribers = true;
      window.history.pushState({ ...window.history.state, [overlayKey]: token }, '');
      if (history) history._ignoreSubscribers = ignored ?? false;
      overlays.push(token);
      pushed = true;
    });
    const onPop = (event: PopStateEvent) => {
      if (overlays.at(-1) === token && window.history.state?.[overlayKey] !== token) {
        event.stopImmediatePropagation();
        closeRef.current();
      }
    };
    window.addEventListener('popstate', onPop, true);
    return () => {
      alive = false;
      window.removeEventListener('popstate', onPop, true);
      const index = overlays.indexOf(token);
      if (index >= 0) overlays.splice(index, 1);
      if (pushed && window.history.state?.[overlayKey] === token) {
        window.addEventListener('popstate', event => event.stopImmediatePropagation(), { capture: true, once: true });
        window.history.back();
      }
    };
  }, [active, router]);
}