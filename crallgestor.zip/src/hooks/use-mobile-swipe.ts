import { useRef, type TouchEvent, type PointerEvent, type MouseEvent } from 'react';
import { swipeSection } from '@/lib/mobile-swipe';

export function useMobileSwipe(view: string, select: (section: string) => void) {
  const start = useRef<{ x: number; y: number } | null>(null);
  const pointer = useRef<{ id: number; x: number; y: number } | null>(null);
  const dragged = useRef(false);
  const trackDrag = (event: PointerEvent<HTMLElement>) => {
    const origin = pointer.current;
    if (origin && origin.id === event.pointerId && Math.hypot(event.clientX - origin.x, event.clientY - origin.y) > 16) dragged.current = true;
  };
  const cancel = () => { start.current = null; };
  return {
    onPointerDownCapture(event: PointerEvent<HTMLElement>) {
      dragged.current = false;
      pointer.current = window.innerWidth < 768 && event.pointerType !== 'mouse'
        ? { id: event.pointerId, x: event.clientX, y: event.clientY } : null;
    },
    onPointerMoveCapture: trackDrag,
    onPointerUpCapture(event: PointerEvent<HTMLElement>) {
      trackDrag(event);
      pointer.current = null;
    },
    onPointerCancelCapture() {
      if (pointer.current) dragged.current = true;
      pointer.current = null;
    },
    onClickCapture(event: MouseEvent<HTMLElement>) {
      if (window.innerWidth < 768 && dragged.current && event.detail !== 0) {
        event.preventDefault();
        event.stopPropagation();
      }
    },
    onTouchStartCapture(event: TouchEvent<HTMLElement>) {
      const target = event.target;
      if (window.innerWidth >= 768 || event.touches.length !== 1 || document.querySelector('[role="dialog"], [role="alertdialog"]') || (target instanceof Element && target.closest('header, input, select, textarea, [role="slider"], [contenteditable], .shopping-row'))) { cancel(); return; }
      const touch = event.touches[0];
      if (touch) start.current = { x: touch.clientX, y: touch.clientY };
    },
    onTouchMoveCapture(event: TouchEvent<HTMLElement>) {
      const touch = event.touches[0];
      if (!start.current || !touch || event.touches.length !== 1) { cancel(); return; }
      const dx = Math.abs(touch.clientX - start.current.x);
      const dy = Math.abs(touch.clientY - start.current.y);
      if (dy > 16 && dy > dx * 1.8) cancel();
    },
    onTouchEndCapture(event: TouchEvent<HTMLElement>) {
      const origin = start.current;
      cancel();
      const touch = event.changedTouches[0];
      if (!origin || !touch || document.querySelector('[role="dialog"], [role="alertdialog"]')) return;
      const next = swipeSection(view, touch.clientX - origin.x, touch.clientY - origin.y, window.innerWidth);
      if (next) { dragged.current = true; select(next); }
    },
    onTouchCancelCapture: cancel,
  };
}