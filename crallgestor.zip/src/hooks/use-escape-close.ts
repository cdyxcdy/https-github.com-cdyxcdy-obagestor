import { useEffect, useRef } from "react";
import { registerEscapeClose } from "@/lib/escape-close";

/**
 * Closes the topmost window or tab when Escape is pressed.
 * Higher priority wins when several are open; system dialogs still close themselves first.
 */
export function useEscapeClose(onClose: () => void, active = true, priority = 0) {
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    if (!active) return;
    return registerEscapeClose(() => closeRef.current(), priority);
  }, [active, priority]);
}
