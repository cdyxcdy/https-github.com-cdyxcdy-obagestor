import { useLayoutEffect, useReducer } from 'react';

/** Reset after the new content commits, even when reopening the same section. */
export function useScrollToTop() {
  const [opening, requestTop] = useReducer((value: number) => value + 1, 0);

  useLayoutEffect(() => {
    const reset = () => window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    reset();
    // Navigation may restore a saved position after the content commits.
    // Repeat after paint so that explicit section selections win that race.
    let followUp: number | undefined;
    const frame = window.requestAnimationFrame(() => {
      reset();
      followUp = window.requestAnimationFrame(reset);
    });
    const settled = window.setTimeout(reset, 100);
    const restored = window.setTimeout(reset, 250);
    return () => {
      window.cancelAnimationFrame(frame);
      if (followUp !== undefined) window.cancelAnimationFrame(followUp);
      window.clearTimeout(settled);
      window.clearTimeout(restored);
    };
  }, [opening]);

  return requestTop;
}