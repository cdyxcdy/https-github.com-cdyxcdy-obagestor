import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [
    { title: "Nova senha — Oba Financeiro" },
    { name: "description", content: "Crie uma nova senha para acessar o Oba Financeiro." },
    { property: "og:title", content: "Nova senha — Oba Financeiro" },
    { property: "og:description", content: "Recupere o acesso às suas finanças." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState(""); const [message, setMessage] = useState(""); const [busy, setBusy] = useState(false);
  const save = async () => {
    if (password.length < 8 || password.length > 72) { setMessage("A senha precisa ter entre 8 e 72 caracteres."); return; }
    setBusy(true); const { error } = await supabase.auth.updateUser({ password }); setBusy(false);
    if (error) { setMessage("Link inválido ou expirado. Peça um novo na tela de entrada."); return; }
    void navigate({ to: "/dashboard" });
  };
  return <main className="finance-dark grid min-h-dvh place-items-center px-4 text-foreground"><div className="money-card w-full max-w-md rounded-3xl p-6"><h1 className="text-2xl font-bold">Criar nova senha</h1><input type="password" autoComplete="new-password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Nova senha" aria-label="Nova senha" className="mt-5 w-full rounded-xl border border-input bg-background/60 px-4 py-3 outline-none focus:ring-2 focus:ring-ring"/>{message && <p role="status" className="mt-3 text-sm text-destructive">{message}</p>}<Button className="mt-5 w-full" disabled={busy} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar nova senha"}</Button></div></main>;
}
