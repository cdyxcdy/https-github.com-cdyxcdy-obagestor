import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import selo from "@/assets/selo-humanus.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Entrar — CRALL GESTOR" },
    { name: "description", content: "Acesso privado ao CRALL GESTOR." },
    { property: "og:title", content: "Entrar — CRALL GESTOR" },
    { property: "og:description", content: "Acesso privado ao CRALL GESTOR." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  useEffect(() => { void supabase.auth.getUser().then(({ data }) => { if (data.user) void navigate({ to: "/dashboard" }); }); const { data } = supabase.auth.onAuthStateChange(event => { if (event === "SIGNED_IN") void navigate({ to: "/dashboard" }); }); return () => data.subscription.unsubscribe(); }, [navigate]);
  // One-time device authorization; afterwards the session stays saved and only the password screen appears.
  const authorize = async () => { setBusy(true); const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin, extraParams: { prompt: "select_account" } }); if (r.error) setBusy(false); };
  return <main className="finance-dark grid min-h-dvh place-items-center px-4 py-6 text-foreground">
    <section className="flex w-full max-w-md flex-col items-center gap-8">
      <img src={selo.url} alt="Selo Humanus" width={320} height={320} className="size-64 object-contain drop-shadow-[0_0_40px_var(--primary-glow)] sm:size-80"/>
      <button type="button" disabled={busy} onClick={() => void authorize()} className="text-xs text-muted-foreground underline-offset-4 hover:underline">{busy ? "Aguarde…" : "Autorizar este aparelho"}</button>
    </section>
  </main>;
}
