import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useState } from "react";
import { ArrowLeft, Bell, FileDown, Paperclip, Plus, Search, Trash2, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { getMyLicense } from "@/lib/license.functions";
import { assignEmployeeNumbers, buildEmployeeFormPdf, employeeSections, formatEmployeeNumber, nextEmployeeNumber, paydayIsTomorrow, validateEmployeeNumber, type EmployeeData } from "@/lib/employees";
import { useEscapeClose } from "@/hooks/use-escape-close";

export const Route = createFileRoute("/_authenticated/funcionarios")({
  head: () => ({ meta: [
    { title: "Funcionários — CRALL GESTOR" },
    { name: "description", content: "Cadastro privado de funcionários, alerta de salário e ficha A4 para impressão." },
    { property: "og:title", content: "Funcionários — CRALL GESTOR" },
    { property: "og:description", content: "Dossiê privado de funcionários." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Page,
});

type Doc = { path: string; name: string; at: string };
type Employee = { id: string; data: EmployeeData; photo_path: string | null; documents: Doc[]; created_at: string };

function Page() {
  const loadLicense = useServerFn(getMyLicense);
  const [admin, setAdmin] = useState<boolean | null>(null);
  useEffect(() => { void loadLicense().then(r => setAdmin(r.isAdmin)).catch(() => setAdmin(false)); }, [loadLicense]);
  if (admin === null) return <main className="finance-dark grid min-h-dvh place-items-center text-foreground"><p className="text-sm text-muted-foreground">Verificando acesso…</p></main>;
  if (!admin) return <main className="finance-dark grid min-h-dvh place-items-center text-foreground"><p className="text-sm text-muted-foreground">Acesso restrito ao proprietário.</p></main>;
  return <Employees />;
}

function download(bytes: Uint8Array, name: string) {
  const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type: "application/pdf" }));
  const a = document.createElement("a"); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function Employees() {
  const [list, setList] = useState<Employee[] | null>(null);
  const [thumbs, setThumbs] = useState<Record<string, string>>({});
  const [selected, setSelected] = useState<Employee | "new" | null>(null);
  const [q, setQ] = useState(""); const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    const { data, error } = await supabase.from("employees").select("*").order("created_at", { ascending: false });
    if (error) { setError("Não foi possível carregar os funcionários."); return; }
    setList((data ?? []).map(e => ({ id: e.id, data: (e.data ?? {}) as EmployeeData, photo_path: e.photo_path, documents: (e.documents ?? []) as Doc[], created_at: String(e.created_at ?? "") })));
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    if (!list) return;
    void Promise.all((list.filter(e => e.photo_path).map(async e =>
      [e.photo_path as string, (await supabase.storage.from("employee-files").createSignedUrl(e.photo_path as string, 3600)).data?.signedUrl] as const
    ))).then(rs => setThumbs(Object.fromEntries(rs.filter(r => r[1]).map(r => [r[0], r[1] as string]))));
  }, [list]);
  const numbers = assignEmployeeNumbers(list ?? []);
  const numberById = new Map<string, number>((list ?? []).map((e, i) => [e.id, numbers[i] ?? 0]));
  const editing = selected && selected !== "new" ? selected : null;
  const takenNumbers = Array.from(numberById).filter(([id]) => id !== editing?.id).map(([, n]) => n);
  const due = (list ?? []).filter(e => paydayIsTomorrow(Number(e.data["diaPagamento"])));
  const shown = (list ?? []).filter(e => (e.data["nome"] ?? "").toLowerCase().includes(q.toLowerCase()));
  const navigate = useNavigate();
  useEscapeClose(() => {
    if (selected) { setSelected(null); return; }
    void navigate({ to: "/dashboard", search: { tab: "home" } });
  }, true, 10);

  return <main className="finance-dark min-h-dvh px-4 py-6 text-foreground"><div className="mx-auto max-w-5xl">
    <header className="mb-5 flex flex-wrap items-center gap-3">
      <Link to="/dashboard" search={{ tab: "home" }} className="grid size-10 place-items-center rounded-xl border border-border bg-card" aria-label="Voltar ao painel"><ArrowLeft size={18}/></Link>
      <h1 className="font-display text-2xl font-bold">Funcionários</h1>
      <div className="ml-auto flex gap-2">
        <Button variant="outline" className="gap-2" onClick={async () => download(await buildEmployeeFormPdf(), "ficha-funcionario.pdf")}><FileDown size={16}/>Ficha A4 em branco</Button>
        <Button className="gap-2" onClick={() => setSelected("new")}><Plus size={16}/>Novo funcionário</Button>
      </div>
    </header>
    {error && <p role="alert" className="mb-3 text-sm text-destructive">{error}</p>}
    {due.length > 0 && <div role="status" className="mb-4 flex items-center gap-2 rounded-xl border border-accent/50 bg-accent/10 px-4 py-3 text-sm font-bold"><Bell size={18} className="text-accent"/>Amanhã é dia de pagamento: {due.map(e => e.data["nome"] || "Sem nome").join(", ")}</div>}
    {selected ? <EmployeeForm key={selected === "new" ? "new" : selected.id} employee={selected === "new" ? null : selected} number={selected === "new" ? nextEmployeeNumber([...numberById.values()]) : numberById.get(selected.id) ?? nextEmployeeNumber([...numberById.values()])} taken={takenNumbers} onDone={async () => { setSelected(null); await refresh(); }} onError={setError}/> : <section className="money-card rounded-3xl p-5">
      <label className="relative mb-4 block"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"/><input aria-label="Buscar funcionário" placeholder="Buscar por nome" value={q} onChange={e => setQ(e.target.value)} className="w-full pl-9"/></label>
      {!list ? <p className="text-sm text-muted-foreground">Carregando…</p> : !shown.length ? <p className="py-8 text-center text-sm text-muted-foreground">Nenhum funcionário cadastrado.</p> :
        <ul className="divide-y divide-border">{shown.map(e => <li key={e.id}><button type="button" onClick={() => setSelected(e)} className="flex w-full items-center gap-3 py-3 text-left">
          <span className="w-9 shrink-0 text-center font-display text-xl font-bold text-primary" title={`Cadastro ${formatEmployeeNumber(numberById.get(e.id) ?? 0)}`}>{formatEmployeeNumber(numberById.get(e.id) ?? 0)}</span>
          <span className="grid size-10 shrink-0 place-items-center overflow-hidden rounded-full bg-muted">{e.photo_path && thumbs[e.photo_path] ? <img src={thumbs[e.photo_path]} alt="" className="size-full object-cover"/> : <UserRound size={18}/>}</span>
          <span className="flex-1"><strong className="block">{e.data["nome"] || "Sem nome"}</strong><small className="text-muted-foreground">{e.data["telefone"] || "Sem telefone"}{e.data["diaPagamento"] ? ` · paga dia ${e.data["diaPagamento"]}` : ""}</small></span>
          <small className="text-muted-foreground">{e.documents.length} arquivo(s)</small>
        </button></li>)}</ul>}
    </section>}
  </div></main>;
}

function EmployeeForm({ employee, number, taken, onDone, onError }: { employee: Employee | null; number: number; taken: number[]; onDone: () => Promise<void>; onError: (m: string) => void }) {
  const [data, setData] = useState<EmployeeData>(employee?.data ?? {});
  const [numberText, setNumberText] = useState(formatEmployeeNumber(number));
  const [busy, setBusy] = useState(false);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [docs, setDocs] = useState<Doc[]>(employee?.documents ?? []);
  const [photoPath, setPhotoPath] = useState<string | null>(employee?.photo_path ?? null);
  useEffect(() => { if (!photoPath) { setPhotoUrl(null); return; } void supabase.storage.from("employee-files").createSignedUrl(photoPath, 3600).then(r => setPhotoUrl(r.data?.signedUrl ?? null)); }, [photoPath]);

  const upload = async (file: File, kind: string) => {
    const { data: u } = await supabase.auth.getUser(); if (!u.user) throw new Error("auth");
    const path = `${u.user.id}/${kind}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "_")}`;
    const { error } = await supabase.storage.from("employee-files").upload(path, file); if (error) throw error;
    return path;
  };
  const save = async () => {
    if (!(data["nome"] ?? "").trim()) { onError("Informe o nome do funcionário."); return; }
    const check = validateEmployeeNumber(numberText, taken);
    if (!check.ok) { onError(check.message); return; }
    setBusy(true);
    const row = { data: { ...data, matricula: String(check.number) }, photo_path: photoPath, documents: docs };
    const { error } = employee ? await supabase.from("employees").update(row).eq("id", employee.id) : await supabase.from("employees").insert(row);
    setBusy(false);
    if (error) { onError("Não foi possível salvar."); return; }
    onError(""); await onDone();
  };
  const remove = async () => { if (!employee || !confirm("Excluir este funcionário e seus arquivos?")) return; await supabase.storage.from("employee-files").remove([...docs.map(d => d.path), ...(photoPath ? [photoPath] : [])]); await supabase.from("employees").delete().eq("id", employee.id); await onDone(); };
  const openDoc = async (d: Doc) => { const r = await supabase.storage.from("employee-files").createSignedUrl(d.path, 600); if (r.data) window.open(r.data.signedUrl, "_blank", "noopener"); };

  return <section className="money-card rounded-3xl p-5">
    <div className="mb-5 flex flex-wrap items-center gap-4">
      <span className="grid size-20 place-items-center overflow-hidden rounded-2xl bg-muted">{photoUrl ? <img src={photoUrl} alt="Foto do funcionário" className="size-full object-cover"/> : <UserRound size={28}/>}</span>
      <label className="cursor-pointer text-sm font-bold text-primary">Trocar foto<input type="file" accept="image/*" className="sr-only" onChange={async e => { const f = e.target.files?.[0]; if (!f) return; try { setPhotoPath(await upload(f, "fotos")); } catch { onError("Falha ao enviar a foto."); } }}/></label>
      <label className="rounded-xl border border-border bg-background px-3 py-1.5 text-center"><small className="block text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Nº de cadastro</small><input value={numberText} onChange={e => setNumberText(e.target.value.replace(/\D/g, "").slice(0, 4))} inputMode="numeric" maxLength={4} aria-label="Número de cadastro" className="mt-1 w-16 text-center font-display text-lg font-bold"/></label>
      <Button variant="outline" className="ml-auto gap-2" onClick={async () => download(await buildEmployeeFormPdf(data), `ficha-${(data["nome"] || "funcionario").replace(/\s+/g, "-")}.pdf`)}><FileDown size={16}/>Ficha A4 deste funcionário</Button>
    </div>
    {employeeSections.map(s => <fieldset key={s.title} className="mb-5"><legend className="mb-2 font-display font-bold">{s.title}</legend>
      <div className="grid gap-3 sm:grid-cols-2">{s.fields.map(f => <label key={f.key} className="text-sm font-semibold">{f.label}<input type={f.type ?? "text"} value={data[f.key] ?? ""} maxLength={200} onChange={e => setData({ ...data, [f.key]: e.target.value })} className="mt-1 w-full"/></label>)}</div>
    </fieldset>)}
    <fieldset className="mb-5"><legend className="mb-2 font-display font-bold">Arquivo (fichas devolvidas)</legend>
      <ul className="mb-2 space-y-1">{docs.map(d => <li key={d.path} className="flex items-center gap-2 text-sm"><Paperclip size={14}/><button type="button" className="text-primary hover:underline" onClick={() => void openDoc(d)}>{d.name}</button><small className="text-muted-foreground">{new Date(d.at).toLocaleDateString("pt-BR")}</small></li>)}{!docs.length && <li className="text-sm text-muted-foreground">Nenhum arquivo anexado.</li>}</ul>
      <label className="cursor-pointer text-sm font-bold text-primary">+ Anexar PDF ou foto<input type="file" accept="application/pdf,image/*" className="sr-only" onChange={async e => { const f = e.target.files?.[0]; if (!f) return; try { const path = await upload(f, "documentos"); setDocs([...docs, { path, name: f.name, at: new Date().toISOString() }]); } catch { onError("Falha ao anexar o arquivo."); } }}/></label>
      <p className="mt-1 text-xs text-muted-foreground">Clique em Salvar depois de anexar.</p>
    </fieldset>
    <div className="flex flex-wrap gap-2">
      <Button disabled={busy} onClick={() => void save()}>{busy ? "Salvando…" : "Salvar"}</Button>
      <Button variant="outline" onClick={() => void onDone()}>Cancelar</Button>
      {employee && <Button variant="ghost" className="ml-auto gap-1 text-destructive" onClick={() => void remove()}><Trash2 size={16}/>Excluir</Button>}
    </div>
  </section>;
}
