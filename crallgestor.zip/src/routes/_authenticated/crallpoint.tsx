import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useCallback, useEffect, useState } from "react";
import { ArrowLeft, Fingerprint, RefreshCw, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { getMyLicense } from "@/lib/license.functions";
import { formatPunchTime, groupPunchesByDay, punchKinds, punchLabel, type PunchKind } from "@/lib/point";
import { useEscapeClose } from "@/hooks/use-escape-close";

export const Route = createFileRoute("/_authenticated/crallpoint")({
  head: () => ({ meta: [
    { title: "Crall Point — CRALL GESTOR" },
    { name: "description", content: "Batidas de ponto dos funcionários com foto, nome, horário e tipo de batida." },
    { property: "og:title", content: "Crall Point — CRALL GESTOR" },
    { property: "og:description", content: "Registro de ponto da equipe." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Page,
});

type Employee = { id: string; nome: string; photo_path: string | null };
type Punch = { id: string; employee_id: string; kind: string; punched_at: string };

const tone: Record<PunchKind, string> = {
  entrada: "var(--income)",
  intervalo: "var(--card-orange)",
  retorno: "var(--primary)",
  saida: "var(--records)",
};

function Page() {
  const loadLicense = useServerFn(getMyLicense);
  const [admin, setAdmin] = useState<boolean | null>(null);
  useEffect(() => { void loadLicense().then(r => setAdmin(r.isAdmin)).catch(() => setAdmin(false)); }, [loadLicense]);
  if (admin === null) return <main className="finance-dark grid min-h-dvh place-items-center text-foreground"><p className="text-sm text-muted-foreground">Verificando acesso…</p></main>;
  if (!admin) return <main className="finance-dark grid min-h-dvh place-items-center text-foreground"><p className="text-sm text-muted-foreground">Acesso restrito ao proprietário.</p></main>;
  return <Point />;
}

function Point() {
  const [staff, setStaff] = useState<Employee[] | null>(null);
  const [punches, setPunches] = useState<Punch[] | null>(null);
  const [thumbs, setThumbs] = useState<Record<string, string>>({});
  const [picked, setPicked] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(() => new Date());
  const navigate = useNavigate();
  useEscapeClose(() => void navigate({ to: "/dashboard", search: { tab: "home" } }), true, 10);

  const refresh = useCallback(async () => {
    const [people, beats] = await Promise.all([
      supabase.from("employees").select("id, data, photo_path").order("created_at", { ascending: true }),
      supabase.from("employee_punches").select("id, employee_id, kind, punched_at").order("punched_at", { ascending: false }).limit(500),
    ]);
    if (people.error || beats.error) { setError("Não foi possível carregar o ponto."); return; }
    setStaff((people.data ?? []).map(p => ({ id: p.id, nome: String((p.data as Record<string, string>)?.["nome"] ?? "") || "Sem nome", photo_path: p.photo_path })));
    setPunches((beats.data ?? []).map(b => ({ id: b.id, employee_id: b.employee_id, kind: b.kind, punched_at: String(b.punched_at ?? "") })));
    setError("");
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  useEffect(() => {
    if (!staff) return;
    void Promise.all(staff.filter(s => s.photo_path).map(async s =>
      [s.photo_path as string, (await supabase.storage.from("employee-files").createSignedUrl(s.photo_path as string, 3600)).data?.signedUrl] as const
    )).then(rs => setThumbs(Object.fromEntries(rs.filter(r => r[1]).map(r => [r[0], r[1] as string]))));
  }, [staff]);

  const people = staff ?? [];
  const chosen = picked || people[0]?.id || "";
  const records = groupPunchesByDay(punches ?? [], now);
  const nameOf = (id: string) => people.find(p => p.id === id)?.nome ?? "Funcionário removido";
  const photoOf = (id: string) => people.find(p => p.id === id)?.photo_path ?? null;

  const register = async (which: PunchKind) => {
    if (!chosen) { setError("Cadastre um funcionário antes de bater ponto."); return; }
    setBusy(true);
    const { error: e } = await supabase.from("employee_punches").insert({ employee_id: chosen, kind: which });
    setBusy(false);
    if (e) { setError("Não foi possível registrar a batida."); return; }
    setError("");
    await refresh();
  };

  return <main className="finance-dark min-h-dvh px-4 py-6 text-foreground"><div className="mx-auto max-w-3xl">
    <header className="mb-5 flex flex-wrap items-center gap-3">
      <Link to="/dashboard" search={{ tab: "home" }} className="grid size-10 place-items-center rounded-xl border border-border bg-card" aria-label="Voltar ao painel"><ArrowLeft size={18}/></Link>
      <span className="grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground"><Fingerprint size={20}/></span>
      <h1 className="font-display text-2xl font-bold">Crall Point</h1>
      <Button variant="outline" size="icon" className="ml-auto" onClick={() => void refresh()} aria-label="Atualizar batidas"><RefreshCw size={16}/></Button>
    </header>

    {error && <p role="alert" className="mb-3 text-sm text-destructive">{error}</p>}

    <section className="money-card mb-5 rounded-3xl p-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <small className="block text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Agora</small>
          <p className="font-display text-4xl font-bold tabular-nums">{now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</p>
        </div>
        <label className="text-sm font-semibold">Funcionário
          <select value={chosen} onChange={e => setPicked(e.target.value)} className="mt-1 block w-full min-w-56 sm:w-auto">
            {people.map(p => <option key={p.id} value={p.id}>{p.nome}</option>)}
          </select>
        </label>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {punchKinds.map(k => <button key={k.key} type="button" onClick={() => void register(k.key)} disabled={busy || !people.length}
          className="rounded-xl border-2 px-4 py-2 text-sm font-bold transition-opacity disabled:opacity-50"
          style={{ borderColor: tone[k.key], color: tone[k.key] }}>{k.label}</button>)}
      </div>
      <p className="mt-2 text-xs text-muted-foreground">Clique no tipo de batida para registrar o horário de agora.</p>
    </section>

    {!punches ? <p className="text-sm text-muted-foreground">Carregando…</p> : !punches.length
      ? <section className="money-card rounded-3xl p-8 text-center"><p className="font-display text-lg font-bold">Nenhuma batida registrada</p><p className="mt-1 text-sm text-muted-foreground">As batidas aparecem aqui. Quando um outro aplicativo sincronizar o ponto, ele também chega nesta lista.</p></section>
      : records.map(day => <section key={day.key} className="money-card mb-4 rounded-3xl p-5">
        <div className="mb-3 flex items-center gap-2">
          <h2 className="font-display text-lg font-bold capitalize">{day.label}</h2>
          <span className="ml-auto rounded-full bg-muted px-2.5 py-0.5 text-xs font-bold text-muted-foreground">{day.items.length} batida(s)</span>
        </div>
        <ul className="divide-y divide-border">
          {day.items.map(p => <li key={p.id} className="flex flex-wrap items-center gap-3 py-3">
            <span className="grid size-11 shrink-0 place-items-center overflow-hidden rounded-full bg-muted">
              {photoOf(p.employee_id) && thumbs[photoOf(p.employee_id) as string]
                ? <img src={thumbs[photoOf(p.employee_id) as string]} alt="" className="size-full object-cover"/>
                : <UserRound size={18}/>}
            </span>
            <span className="min-w-0 flex-1"><strong className="block truncate">{nameOf(p.employee_id)}</strong>
              <small className="font-semibold" style={{ color: tone[p.kind as PunchKind] ?? "var(--muted-foreground)" }}>{punchLabel(p.kind)}</small></span>
            <span className="font-display text-2xl font-bold tabular-nums">{formatPunchTime(p.punched_at)}</span>
          </li>)}
        </ul>
      </section>)}
  </div></main>;
}
