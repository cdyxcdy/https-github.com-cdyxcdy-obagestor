// @refresh reset
// Gesture-hook changes must remount the preview rather than reuse an outdated hook queue.
import { createFileRoute, Link, redirect, useNavigate } from "@tanstack/react-router";
import { createAppOpeningGuard } from "@/lib/app-opening";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  ArrowDownLeft, ArrowUpRight, BarChart3, Bell, CircleDollarSign, Coins,
  CalendarCheck, Check, CreditCard, Edit3, Home, LogOut,
  Gauge, Globe2, Landmark, Plus, ReceiptText, RefreshCw, Settings2, Sparkles, Trash2, WalletCards,
  X,
  Mail, Users, ListChecks, ShoppingCart, UserRound, Mic,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { getExchangeRates, getFinanceState, getSelicRate, mutateFinanceCard, mutateFinanceRecord, mutateFixedExpense, mutateForeignExpense, patchFinanceState, saveFinanceState } from "@/lib/finance.functions";
import { bootstrapAdmin, getMyLicense, listUsersForLicense } from "@/lib/license.functions";
import { AdminClients } from "@/components/LicenseLock";
import { financeStateSchema } from "@/lib/finance-schema";
import { TasksManager } from "@/components/tasks/TasksManager";
import { Agenda } from "@/components/Agenda";
import { MarketTicker } from "@/components/MarketTicker";
import { FloatingToolButtons } from "@/components/FloatingTools";
import { CrallAssistant } from "@/components/CrallAssistant";
import { agendaSchema, type Appointment } from "@/lib/agenda";
import { useScrollToTop } from "@/hooks/use-scroll-to-top";
import { useMobileSwipe } from "@/hooks/use-mobile-swipe";
import { useAppBack } from "@/hooks/use-app-back";
import { useEscapeClose } from "@/hooks/use-escape-close";
import { emptyTasks, type TasksState } from "@/lib/tasks-schema";
import { collectReminders, defaultNotifications, notificationOptions, notificationSettingsSchema, type NotificationSettings } from "@/lib/notification-settings";
import { deleteAllInboxItems, deleteInboxItem, markAllRead, pushInbox, useInbox } from "@/lib/inbox";
import { financialPaymentMethods, fixedPaymentModes, paymentLabel, submittedPaymentMethod, financialMessage } from "@/lib/payment-presentation";
import { wholeMoney } from "@/lib/whole-money";
import { parseVoiceRecord } from "@/lib/voice-record";
import { getMonthlyHomeValues, daysToCardDue } from "@/lib/home-month";
import { getCardAvailableBalance, getHomeCardBalances, getTotalExpenses } from "@/lib/card-balances";
import { newestRecordsFirst, recordDisplayDate } from "@/lib/record-order";
import { DesktopHome, DesktopSidebar } from "@/components/DesktopPanel";
import { cardThumbnail } from "@/lib/card-thumbnails";
import { Area, AreaChart, Bar as RechartsBar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const shouldOpenHome = createAppOpeningGuard();

export const Route = createFileRoute("/_authenticated/dashboard")({
  validateSearch: (search: Record<string, unknown>): { tab?: string | undefined } => ({ tab: typeof search['tab'] === 'string' && ['home','roleta','cards','records','tasks','frotapro','fixedExpenses'].includes(search['tab']) ? search['tab'] : undefined }),
  beforeLoad: ({ cause, search }) => {
    const embedded = typeof window !== 'undefined' && window.self !== window.top;
    if (!embedded && shouldOpenHome(cause, search.tab)) throw redirect({ to: '/dashboard', search: { tab: 'home' }, replace: true });
  },
  head: () => ({ meta: [
    { title: "CRALL GESTOR — Painel" },
    { name: "description", content: "Organize renda, cartões, investimentos, gastos, despesas fixas e metas em um só lugar." },
    { property: "og:title", content: "CRALL GESTOR — Painel" },
    { property: "og:description", content: "Seu painel completo para organizar a vida financeira." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: LicenseGate,
});

function LicenseGate() {
  const loadLicense = useServerFn(getMyLicense);
  const [license, setLicense] = useState<{ licensed: boolean; suspended: boolean; expired: boolean; expiresAt: string | null; serverNow: number; isAdmin: boolean; adminsExist: boolean; trialAvailable: boolean; isTrial: boolean } | null>(null);
  useEffect(() => {
    let active = true;
    const check = async () => {
      try { const result = await loadLicense(); if (active) setLicense(result); }
      catch { if (active) setLicense({ licensed: false, suspended: false, expired: false, expiresAt: null, serverNow: Date.now(), isAdmin: false, adminsExist: true, trialAvailable: false, isTrial: false }); }
    };
    void check();
    const timer = window.setInterval(() => void check(), 10000);
    const onVisible = () => { if (document.visibilityState === "visible") void check(); };
    window.addEventListener("focus", onVisible);
    document.addEventListener("visibilitychange", onVisible);
    return () => { active = false; window.clearInterval(timer); window.removeEventListener("focus", onVisible); document.removeEventListener("visibilitychange", onVisible); };
  }, [loadLicense]);
  useEffect(() => {
    if (!license?.licensed || license.isAdmin || !license.expiresAt) return;
    const remaining = Date.parse(license.expiresAt) - license.serverNow;
    const started = performance.now();
    let timer: number;
    const checkExpiry = () => {
      const left = remaining - (performance.now() - started);
      if (left > 0) { timer = window.setTimeout(checkExpiry, Math.min(left, 2147483647)); return; }
      setLicense(current => current && !current.isAdmin ? { ...current, licensed: false, expired: true } : current);
    };
    checkExpiry();
    return () => window.clearTimeout(timer);
  }, [license]);
  if (!license) return <main className="finance-dark grid min-h-dvh place-items-center text-foreground"><p className="text-sm text-muted-foreground">Verificando seu acesso…</p></main>;
  if (!license.isAdmin) return <OwnerOnly adminsExist={license.adminsExist} onBecameAdmin={async () => setLicense(await loadLicense())} />;
  return <FinanceApp isAdmin={license.isAdmin} />;
}

function OwnerOnly({ adminsExist, onBecameAdmin }: { adminsExist: boolean; onBecameAdmin: () => Promise<void> }) {
  const runBootstrap = useServerFn(bootstrapAdmin);
  const [busy, setBusy] = useState(false); const [message, setMessage] = useState("");
  const claim = async () => { setBusy(true); setMessage(""); try { const r = await runBootstrap(); if (r.isAdmin) await onBecameAdmin(); else setMessage("Esta conta não é a do proprietário."); } catch { setMessage("Esta conta não é a do proprietário."); } finally { setBusy(false); } };
  return <main className="finance-dark grid min-h-dvh place-items-center px-4 text-foreground"><section className="money-card w-full max-w-md rounded-3xl p-6 text-center">
    <h1 className="font-display text-2xl font-bold">Acesso restrito</h1>
    <p className="mt-3 text-sm text-muted-foreground">O CRALL GESTOR é de uso exclusivo do proprietário. Entre com a conta Google autorizada.</p>
    {!adminsExist && <Button className="mt-5 w-full" disabled={busy} onClick={() => void claim()}>Sou o proprietário — ativar</Button>}
    {message && <p role="status" className="mt-3 text-sm text-destructive">{message}</p>}
    <Button variant="outline" className="mt-4 w-full gap-2" onClick={() => void supabase.auth.signOut().then(() => window.location.assign("/"))}><LogOut size={18}/> Trocar de conta</Button>
  </section></main>;
}

type Currency = "BRL" | "USD" | "EUR";
type RecordItem = { id: number; title: string; category: string; amount: number; type: "receita" | "gasto"; date: string; paymentMethod?: string; cardId?: number; cardName?: string; accountType?:"Crédito"|"Débito"; fixedExpenseId?:number; paidAt?:string };
type CardBrand = "Visa" | "Mastercard" | "Elo" | "American Express" | "Nenhuma";
type CardStatus = "Ativo" | "Bloqueado" | "Arquivado";
type Bank = { creditAdjustment?: number; debitAdjustment?: number; desiredBalances?: { creditLimit: number; debitBalance: number }; id: number; name: string; invested: number; creditLimit: number; debitBalance: number; dueDay: number; color?: CardColor; brand?: CardBrand; status?: CardStatus; primary?: boolean };
type Investment = { id: number; bank: string; percentage: number; value: number; withdrawal: number; invested: number; applicationDate?:string };
type SimpleItem = { id: number; name: string; value: number; extra?: number; image?: string };
type FixedExpense = { id: number; name: string; amount: number; dueDay: number; paidMonths: string[] };
type FixedExpensePayment = { cardId: number; cardName: string; accountType: "Crédito" | "Débito" };
type ForeignExpense = { id:number; name:string; amount:number; currency:"USD"|"EUR"; date:string; paid:boolean; paidAt:string|null; paidBrlAmount:number|null };
type CurrencyAssets = { usdInvested:number; eurInvested:number; manualUsdRate:number|null; manualEurRate:number|null; autoUsdRate:number|null; autoEurRate:number|null; ratesUpdatedAt:string|null };
type Store = {
  currency: Currency; name: string; discount: number; balance: number;
  banks: Bank[]; investments: Investment[]; records: RecordItem[];
  budgets: SimpleItem[]; accounts: SimpleItem[]; fixedExpenses: FixedExpense[]; foreignExpenses: ForeignExpense[]; goals: SimpleItem[];
  notifications: NotificationSettings;
  currencyAssets: CurrencyAssets;
  homeResets: { credit: number; expenses: number };
  tasks: TasksState;
  agenda: Appointment[];
};
type CardColor = "Rosa" | "Verde" | "Azul" | "Preto" | "Roxo" | "Vermelho" | "Dourado" | "Cinza metálico" | "Prateado" | "Branco" | "Laranjado";

const initialStore: Store = {
  currency: "BRL", name: "Usuário", discount: 0, balance: 0,
  banks: [],
  investments: [], records: [], budgets: [], accounts: [], fixedExpenses: [], foreignExpenses: [], goals: [], notifications: defaultNotifications,
  currencyAssets: { usdInvested: 0, eurInvested: 0, manualUsdRate: null, manualEurRate: null, autoUsdRate: null, autoEurRate: null, ratesUpdatedAt: null },
  homeResets: { credit: 0, expenses: 0 },
  tasks: emptyTasks,
  agenda: [],
};

const topTabs = [
  { id: "cards", label: "Cartões", icon: CreditCard },
  { id: "records", label: "Receitas e gastos", icon: ReceiptText },
  { id: "fixedExpenses", label: "Despesas fixas", icon: CalendarCheck },
  { id: "tasks", label: "Minhas Tarefas", icon: ListChecks },
  { id: "frotapro", label: "FrotaPro", icon: Gauge },
] as const;
const bottomTabs = [
  { id: "home", label: "Início", icon: Home },
] as const;

function FinanceApp({ isAdmin }: { isAdmin: boolean }) {
  const { user } = Route.useRouteContext();
  const userAvatar = user.user_metadata?.["avatar_url"] ? String(user.user_metadata["avatar_url"]) : null;
  const fullName = String(user.user_metadata?.["full_name"] ?? user.user_metadata?.["name"] ?? "").trim();
  const firstName = (fullName ? fullName.split(/\s+/)[0] : String(user.email ?? "").split("@")[0]) || "Cliente";
  const [avatarFailed, setAvatarFailed] = useState(false);
  const headerAvatar = userAvatar && !avatarFailed ? userAvatar : null;
  const navigate = useNavigate();
  const loadCloud = useServerFn(getFinanceState);
  const saveCloud = useServerFn(saveFinanceState);
  const patchCloud = useServerFn(patchFinanceState);
  const mutateCardCloud = useServerFn(mutateFinanceCard);
  const mutateRecordCloud = useServerFn(mutateFinanceRecord);
  const mutateFixedExpenseCloud = useServerFn(mutateFixedExpense);
  const mutateForeignExpenseCloud = useServerFn(mutateForeignExpense);
  const loadExchangeRates = useServerFn(getExchangeRates);
  const loadSelicRate = useServerFn(getSelicRate);
  const [store, setStore] = useState(initialStore);
  const { tab } = Route.useSearch();
  const view = tab ?? 'home';
  const activeSection = view === 'home' ? { id: 'home', label: 'INICIO - APENAS INFORMAÇÕES', icon: Home } : view === 'roleta' ? { id: 'roleta', label: 'MENU RÁPIDO', icon: Gauge } : topTabs.find(section => section.id === view);
  const requestTop = useScrollToTop();
  const swipeHandlers = useMobileSwipe(view, section => {
    requestTop();
    void navigate({ to: '/dashboard', search: { tab: section } });
  });
  const [hydrated, setHydrated] = useState(false);
  const [syncStatus, setSyncStatus] = useState<"loading"|"saved"|"saving"|"offline">("loading");
  const [modal, setModal] = useState<ReactNode>(null);
  const [agendaOpen, setAgendaOpen] = useState(false);
  useAppBack(() => setModal(null), modal !== null);
  useEscapeClose(() => {
    if (modal) { setModal(null); return; }
    if (view !== 'home') { requestTop(); void navigate({ to: '/dashboard', search: { tab: 'home' } }); }
  }, true, 10);
  useEffect(() => { requestTop(); }, [view, requestTop]);
  const skipNextSave = useRef(false);
  const dirtyKeys = useRef(new Set<keyof Store>());
  const localRevision = useRef(0);
  const storeRef = useRef(store);
  const cardsPending = useRef(0);
  const recordsPending = useRef(0);
  const fixedExpensesPending = useRef(0);
  const foreignExpensesPending = useRef(0);
  useEffect(() => { storeRef.current = store; }, [store]);
  useEffect(() => { const media = window.matchMedia("(max-width: 767px)"); const check = () => { if (media.matches && view === 'dashboard') void navigate({to:'/dashboard',search:{tab:'home'},replace:true}); if (view === 'roleta' || (media.matches && view === 'frotapro')) void navigate({to:'/dashboard',search:{tab:'home'},replace:true}); }; check(); media.addEventListener("change", check); return () => media.removeEventListener("change", check); }, [view,navigate]);
  const updateStore: React.Dispatch<React.SetStateAction<Store>> = action => {
    setStore(previous => {
      const next = typeof action === "function" ? action(previous) : action;
      (Object.keys(next) as (keyof Store)[]).forEach(key => {
        if (next[key] !== previous[key]) dirtyKeys.current.add(key);
      });
      localRevision.current += 1;
      return next;
    });
  };
  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const cloud = await loadCloud();
        if (!active) return;
        if (cloud) setStore(cloud.state as Store);
        else {
          const startingState = initialStore;
          setStore(startingState);
          await saveCloud({ data: startingState });
        }
        setSyncStatus("saved");
      } catch { setSyncStatus("offline"); }
      finally { if (active) setHydrated(true); }
    })();
    return () => { active = false; };
  }, [loadCloud, saveCloud]);
  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(`meu-controle-v2-${user.id}`, JSON.stringify(store));
    if (skipNextSave.current) { skipNextSave.current = false; return; }
    if (dirtyKeys.current.size === 0) return;
    setSyncStatus("saving");
    const revision = localRevision.current;
    const changedKeys = [...dirtyKeys.current];
    const changes = Object.fromEntries(changedKeys.map(key => [key, store[key]]));
    const timer = window.setTimeout(() => { void patchCloud({ data: changes }).then(() => {
      if (localRevision.current === revision) {
        changedKeys.forEach(key => dirtyKeys.current.delete(key));
        setSyncStatus("saved");
      }
    }).catch(() => setSyncStatus("offline")); }, 500);
    return () => window.clearTimeout(timer);
  }, [store, hydrated, patchCloud]);
  useEffect(() => {
    const applyCloudState = (next: unknown) => {
      const parsed = financeStateSchema.safeParse(next);
      if (!parsed.success || dirtyKeys.current.size > 0 || cardsPending.current > 0 || recordsPending.current > 0 || fixedExpensesPending.current > 0 || foreignExpensesPending.current > 0 || JSON.stringify(parsed.data) === JSON.stringify(storeRef.current)) return;
      skipNextSave.current = true; setStore(parsed.data as Store); setSyncStatus("saved");
    };
    const refreshFromCloud = async () => {
      try {
        if (dirtyKeys.current.size > 0) {
          const keys = [...dirtyKeys.current];
          const changes = Object.fromEntries(keys.map(key => [key, storeRef.current[key]]));
          const revision = localRevision.current;
          await patchCloud({ data: changes });
          if (localRevision.current === revision) keys.forEach(key => dirtyKeys.current.delete(key));
          setSyncStatus("saved");
          return;
        }
        const cloud = await loadCloud(); if (cloud) applyCloudState(cloud.state);
      }
      catch { setSyncStatus("offline"); }
    };
    const channel = supabase.channel(`finance-state-${user.id}`).on("postgres_changes", { event: "*", schema: "public", table: "finance_states", filter: `user_id=eq.${user.id}` }, payload => {
      const parsed = financeStateSchema.safeParse((payload.new as { state?: unknown }).state);
      if (!parsed.success) return;
      applyCloudState(parsed.data);
    }).subscribe(status => {
      if (status === "SUBSCRIBED") { setSyncStatus(current => current === "saving" ? current : "saved"); void refreshFromCloud(); }
      if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") setSyncStatus("offline");
    });
    const interval = window.setInterval(() => { if (document.visibilityState === "visible") void refreshFromCloud(); }, 3000);
    const onFocus = () => { void refreshFromCloud(); };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => { window.clearInterval(interval); window.removeEventListener("focus", onFocus); document.removeEventListener("visibilitychange", onFocus); void supabase.removeChannel(channel); };
  }, [user.id, loadCloud, patchCloud]);

  const money = (value: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);
  const income = store.records.filter(r => r.type === "receita").reduce((sum, r) => sum + r.amount, 0);
  const expenses = getTotalExpenses(store.records);
  const totalInvested = store.investments.reduce((sum, i) => sum + i.invested, 0);
  const cardInvestedTotal = store.banks.reduce((sum, bank) => sum + bank.invested, 0);
  const totalYield = store.investments.reduce((sum, i) => sum + (Math.max(0, i.invested - i.withdrawal) * i.percentage / 100), 0);
  const notifications = useMemo(()=>notificationSettingsSchema.parse(store.notifications ?? {}),[store.notifications]);
  const loadClients = useServerFn(listUsersForLicense);
  const [pendingClients,setPendingClients]=useState(0);
  const notify=(title:string,body:string)=>{pushInbox(user.id,title,body);void sendBrowserNotification(title,body)};
  const openClients=()=>setModal(<div className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur" onClick={()=>setModal(null)}><div className="relative w-full max-w-md" onClick={e=>e.stopPropagation()}><Button variant="icon" size="icon" className="absolute right-3 top-7 z-10" aria-label="Fechar" onClick={()=>setModal(null)}><X size={18}/></Button><AdminClients onCount={setPendingClients}/></div></div>);
  useEffect(()=>{if(!isAdmin)return;let stop=false;const key=`notified-clients-${user.id}`;
    const check=async()=>{try{const list=await loadClients();if(stop)return;const pending=list.filter(u=>!u.licensed&&!u.suspended);setPendingClients(pending.length);
      const seen=new Set<string>(JSON.parse(localStorage.getItem(key)??"[]"));const fresh=pending.filter(u=>!seen.has(u.id));
      if(fresh.length&&notifications.clientsPending){void notify("Novo cliente aguardando liberação",fresh.length===1?`${fresh[0]?.email??"Cliente"} criou conta. Confira o Pix de R$ 30,00.`:`${fresh.length} novos clientes aguardando liberação.`);fresh.forEach(u=>seen.add(u.id));localStorage.setItem(key,JSON.stringify([...seen]))}}catch{}};
    void check();const timer=setInterval(()=>void check(),120000);return()=>{stop=true;clearInterval(timer)}},[isAdmin,user.id,notifications.clientsPending]);
  useEffect(()=>{if(!hydrated||!notifications.dailyBalance)return;const now=new Date();if(now.getHours()<8)return;const key=`daily-balance-${user.id}-${now.toISOString().slice(0,10)}`;if(localStorage.getItem(key))return;localStorage.setItem(key,"sent");void notify("Total em conta",money(storeRef.current.balance))},[hydrated,notifications.dailyBalance,user.id]);
  useEffect(()=>{
    if(!hydrated)return;
    const check=()=>{
      const date=new Date().toLocaleDateString("sv-SE");
      for(const reminder of collectReminders(notifications,{...storeRef.current,tasks:storeRef.current.tasks??emptyTasks})){
        const key=`reminder-${user.id}-${reminder.id}-${date}`;
        if(localStorage.getItem(key))continue;
        notify(reminder.title,reminder.body);localStorage.setItem(key,"sent");
      }
    };
    check();const timer=window.setInterval(check,60000);return()=>window.clearInterval(timer);
  },[hydrated,user.id,notifications,store.banks,store.fixedExpenses,store.tasks,store.agenda]);
  const saveTasks=(tasks:TasksState)=>{
    const previous=storeRef.current.tasks??emptyTasks;
    updateStore(current=>({...current,tasks}));
    if(notifications.taskSettlements)for(const item of tasks.accounts){
      const old=previous.accounts.find(v=>v.id===item.id);
      if(old&&old.settled!==item.settled)notify(item.settled?(item.kind==="Pagar"?"Conta paga":"Conta recebida"):"Conta reaberta",`${item.title}: ${money(item.amount)}.`);
    }
  };
  const patch = <K extends keyof Store>(key: K, value: Store[K]) => updateStore(s => ({ ...s, [key]: value }));
  const saveAgenda = async (items: Appointment[]) => {
    const agenda = agendaSchema.parse(items);
    await patchCloud({ data: { agenda } });
    setStore(current => ({ ...current, agenda }));
  };
  const mutateCard = async (card: Bank, remove = false) => {
    cardsPending.current += 1;
    setSyncStatus("saving");
    try {
      const result = await mutateCardCloud({ data: { card, delete: remove } });
      setStore(current => ({ ...current, banks: result.banks as Bank[] }));
      if(notifications.cardMovements)void notify(remove?"Cartão removido":"Cartão atualizado",`${card.name}: ${money(card.debitBalance)} em débito e ${money(card.creditLimit)} de limite de crédito.`);
      setSyncStatus("saved");
    } catch (error) {
      setSyncStatus("offline");
      if(error instanceof Error&&(error.message.includes("INSUFFICIENT_CARD_BALANCE")||error.message.includes("CARD_REQUIRED")))setModal(<BalanceWarningModal title="Pagamento não realizado" text="O cartão escolhido não possui saldo suficiente ou deixou de estar disponível. Escolha outro cartão ou forma de pagamento." close={()=>setModal(null)}/>);
    } finally {
      cardsPending.current = Math.max(0, cardsPending.current - 1);
    }
  };
  const changeRecord = async (record: RecordItem, action: "upsert"|"delete") => {
    recordsPending.current += 1;
    setSyncStatus("saving");
    try {
      const result = await mutateRecordCloud({ data: { record, action } });
      setStore(current => ({ ...current, records: result.records as RecordItem[], balance: result.balance }));
      if(action==="upsert"&&(record.type==="receita"?notifications.incomeMessages:notifications.expenseMessages))void notify(record.type==="receita"?"Receita adicionada":"Gasto adicionado",`${record.title}: ${money(record.amount)}.`);
      if(action==="delete"&&(record.type==="receita"?notifications.incomeMessages:notifications.expenseMessages))void notify("Lançamento excluído",`${record.title}: ${money(record.amount)}.`);
      if(record.cardName&&notifications.cardMovements)void notify("Movimentação no cartão",`${record.cardName}: ${record.type==="receita"?"entrada de":"saída de"} ${money(record.amount)}${record.accountType?` no ${record.accountType.toLowerCase()}`:""}.`);
      setSyncStatus("saved");
    } catch (error) {
      setSyncStatus("offline");
      if(error instanceof Error&&error.message.includes("INSUFFICIENT_CARD_BALANCE"))setModal(<BalanceWarningModal title="Pagamento não realizado" text="O cartão escolhido ficou sem saldo disponível. Escolha outro cartão ou modo de pagamento." close={()=>setModal(null)}/>);
    } finally {
      recordsPending.current = Math.max(0, recordsPending.current - 1);
    }
  };
  const changeFixedExpense = async (expense: FixedExpense, action: "upsert"|"delete"|"pay", month?: string, payment?: FixedExpensePayment) => {
    fixedExpensesPending.current += 1;
    setSyncStatus("saving");
    try {
      const result = await mutateFixedExpenseCloud({ data: { expense, action, ...(month ? { month } : {}), ...(payment ? { payment } : {}) } });
      setStore(current => ({ ...current, fixedExpenses: result.fixedExpenses as FixedExpense[], records: result.records as RecordItem[], balance: result.balance }));
      if(action==="pay"&&notifications.fixedExpensePayments)void notify("Despesa fixa paga",`${expense.name}: ${money(expense.amount)} descontados do Total em conta.`);
      if(action==="pay"&&payment&&notifications.cardMovements)void notify("Movimentação no cartão",`${payment.cardName}: saída de ${money(expense.amount)} no ${payment.accountType.toLowerCase()} para pagar ${expense.name}.`);
      setSyncStatus("saved");
    } catch {
      setSyncStatus("offline");
    } finally {
      fixedExpensesPending.current = Math.max(0, fixedExpensesPending.current - 1);
    }
  };
  const changeForeignExpense = async (expense:ForeignExpense,action:"upsert"|"delete"|"pay",brlAmount?:number) => {
    foreignExpensesPending.current+=1; setSyncStatus("saving");
    try { const result=await mutateForeignExpenseCloud({data:{expense,action,...(brlAmount!==undefined?{brlAmount}:{})}});setStore(current=>({...current,foreignExpenses:result.foreignExpenses as ForeignExpense[],currencyAssets:result.currencyAssets as CurrencyAssets}));setSyncStatus("saved");if(action==="pay"&&notifications.foreignExpensePayments)void notify("Despesa do exterior paga",`${expense.name}: valor descontado do rendimento em ${expense.currency==="USD"?"Dólar":"Euro"}.`) }
    catch { setSyncStatus("offline") } finally { foreignExpensesPending.current=Math.max(0,foreignExpensesPending.current-1) }
  };

  return (
    <div className={`finance-dark desktop-shell min-h-screen pb-32 lg:pb-4 text-foreground ${view === 'home' ? 'mobile-home-screen desktop-wide' : view === 'frotapro' ? 'desktop-wide' : ''}`} {...swipeHandlers}>
      <DesktopSidebar userId={user.id} email={user.email ?? ""} notifications={notifications} saveNotifications={nextNotifications=>updateStore(s=>({...s,notifications:nextNotifications}))} view={view} isAdmin={isAdmin} onSelect={requestTop} openAgenda={()=>setAgendaOpen(true)} onSettings={()=>setModal(<NotificationsModal isAdmin={isAdmin} settings={notifications} save={nextNotifications=>updateStore(s=>({...s,notifications:nextNotifications}))} close={()=>setModal(null)}/>)} onLogout={()=>void supabase.auth.signOut().then(()=>navigate({to:"/"}))}/>
      <header className="sticky top-0 z-30 border-b border-border bg-background/85 shadow-[0_14px_42px_var(--glass-shadow)] backdrop-blur-2xl">
        <div className="finance-content mx-auto flex flex-wrap items-center justify-between gap-3 px-4 py-4 lg:py-2">
          <div className="flex min-w-0 items-center gap-2">
          <Link to="/dashboard" search={{tab:'home'}} onClick={requestTop} className="flex min-w-0 items-center gap-3" aria-label="Ir ao início">
            {headerAvatar
              ? <img src={headerAvatar} alt={`Foto de ${firstName}`} onError={() => setAvatarFailed(true)} className="size-11 rounded-xl border border-primary/40 object-cover shadow-[0_5px_0_var(--primary-shadow),0_12px_25px_var(--primary-glow)]"/>
              : <span className="tab-3d grid size-11 place-items-center rounded-xl bg-primary text-lg font-bold text-primary-foreground shadow-[0_5px_0_var(--primary-shadow),0_12px_25px_var(--primary-glow)]">{firstName.slice(0,1).toUpperCase()}</span>}
            <span className="text-left"><strong className="block truncate font-display text-base">{firstName}</strong><span className="flex items-center gap-1.5 text-xs text-muted-foreground"><i className={`size-2 rounded-full ${syncStatus==="offline"?"bg-destructive":syncStatus==="saving"?"bg-accent animate-pulse":"bg-[var(--income)]"}`}/>{syncStatus==="saved"?"Sincronizado":syncStatus==="saving"?"Salvando…":syncStatus==="offline"?"Sem conexão":"Carregando…"}</span></span>
          </Link>
          <Button variant="icon" size="icon" className="shrink-0 rounded-xl md:size-12" onClick={()=>setAgendaOpen(true)} aria-label="Agenda" title="Agenda"><CalendarCheck size={20}/></Button>
          <FloatingToolButtons userId={user.id}/>
          </div>
          {isAdmin&&<Link to="/compras" aria-label="Lista de Compras" title="Lista de Compras" className="tab-3d hidden size-12 shrink-0 place-items-center rounded-xl border border-primary/40 bg-card text-primary md:grid lg:hidden"><ShoppingCart size={26}/></Link>}
          {isAdmin&&<Link to="/funcionarios" aria-label="Funcionários" title="Funcionários" className="tab-3d hidden size-12 shrink-0 place-items-center rounded-xl border border-primary/40 bg-card text-primary md:grid lg:hidden"><UserRound size={26}/></Link>}
          {isAdmin&&<span className="lg:hidden"><CrallAssistant/></span>}
          <span className="hidden flex-1 md:block lg:hidden"/><MarketTicker/>
          <div className="flex shrink-0 items-center justify-end gap-2"><Button variant="icon" size="icon" className="rounded-xl md:size-12" onClick={()=>void supabase.auth.signOut().then(()=>navigate({to:"/"}))} aria-label="Sair"><LogOut size={18}/></Button></div>
        </div>
        <nav className="finance-content mx-auto hidden gap-3 px-4 pb-4 pt-2 md:grid md:grid-cols-4 lg:hidden" aria-label="Seções financeiras">
          {topTabs.filter(tab => isAdmin || tab.id !== 'frotapro').map(tab => <Button asChild key={tab.id} variant="ghost" aria-pressed={view===tab.id} data-section={tab.id} className="finance-section-tab"><Link to="/dashboard" search={{tab:tab.id}} onClick={requestTop}><span className="finance-section-icon"><tab.icon size={20} strokeWidth={2.5}/></span><span className="finance-section-label">{tab.label}</span></Link></Button>)}
        </nav>
      </header>

      <main className="finance-content mx-auto px-4 py-8 lg:py-3 max-md:touch-pan-y">
        <Agenda open={agendaOpen} onOpenChange={setAgendaOpen} items={store.agenda} save={saveAgenda}/>
         {(view === 'home' || view === 'records') && <div className="mb-4 flex justify-center gap-2 md:hidden" aria-hidden="true"><span className={`h-1 w-10 rounded-full transition-colors ${view === 'home' ? 'bg-primary' : 'bg-muted-foreground/30'}`}/><span className={`h-1 w-10 rounded-full transition-colors ${view === 'records' ? 'bg-primary' : 'bg-muted-foreground/30'}`}/></div>}
         {view === "roleta" && <div className="md:hidden"><RoletaView isAdmin={isAdmin} onBack={() => { requestTop(); void navigate({ to: '/dashboard', search: { tab: 'home' } }); }}/></div>}
         {activeSection && <div key={activeSection.id} className="finance-section-tab mobile-section-heading mb-6 flex items-center md:hidden" data-section={activeSection.id} aria-pressed="true"><span className="finance-section-icon"><activeSection.icon size={20} strokeWidth={2.5}/></span><h1 className="finance-section-label">{activeSection.id === 'home' ? <><span className="mobile-section-title">INICIO</span><span className="mobile-section-subtitle"> - APENAS INFORMAÇÕES</span></> : activeSection.label}</h1></div>}
         {view === "home" && <><div className="lg:hidden"><HomeView store={store} money={wholeMoney} income={income} expenses={expenses} invested={cardInvestedTotal} setStore={updateStore} open={setModal}/></div><div className="hidden lg:block"><DesktopHome store={store} money={wholeMoney} expenses={expenses} onSelect={requestTop} userId={user.id} isAdmin={isAdmin} saveRecord={r=>void changeRecord(r as RecordItem,"upsert")} saveCard={c=>void mutateCard(c as Bank)}/></div></>} 
         {view === "income" && <IncomeView store={store} money={money} expenses={expenses} totalInvested={totalInvested} totalYield={totalYield} setStore={updateStore} open={setModal} loadRates={loadExchangeRates} loadSelic={loadSelicRate} changeForeignExpense={changeForeignExpense}/>} 
         {view === "cards" && <CardsView banks={store.banks} records={store.records} money={money} saveCard={card=>mutateCard(card)} deleteCard={card=>mutateCard(card,true)} open={setModal}/>} 
        {view === "tasks" && <FinancialTasksView store={store} saveTasks={saveTasks}/>}
        {view === "frotapro" && (isAdmin ? <FrotaProView userId={user.id} onEscape={() => { requestTop(); void navigate({ to: '/dashboard', search: { tab: 'home' } }); }}/> : <p className="text-sm text-muted-foreground">FrotaPro é exclusivo do proprietário.</p>)}
        {view === "records" && <RecordsView records={store.records} banks={store.banks} money={money} change={changeRecord} open={setModal}/>} 
         {view === "fixedExpenses" && <FixedExpensesView items={store.fixedExpenses} banks={store.banks} records={store.records} money={money} change={changeFixedExpense} open={setModal}/>} 
        {view === "dashboard" && <DashboardView store={store}/>} 
      </main>
      <BottomNav view={view} onSelect={requestTop}/>
      {modal}
    </div>
  );
}

function RoletaView({ isAdmin, onBack }: { isAdmin: boolean; onBack: () => void }) {
  const requestTop = useScrollToTop();
  const items = [
    { id: "cards", label: "Cartões", icon: CreditCard },
    { id: "records", label: "Receitas e Gastos", icon: ReceiptText },
    { id: "fixedExpenses", label: "Despesas Fixas", icon: CalendarCheck },
    ...(isAdmin ? [{ id: "frotapro", label: "FrotaPro", icon: Gauge }] : []),
  ];
  const angles = items.length === 4 ? [-90, 0, 90, 180] : [-90, 30, 150];
  return <section aria-label="Menu rápido" className="select-none">
    <div className="mb-4 flex justify-start"><Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground" onClick={onBack}><ArrowDownLeft className="-rotate-90" size={16}/>Voltar</Button></div>
    <div className="roleta-wheel" role="navigation" aria-label="Roleta de seções">
      <div className="roleta-hub" aria-hidden="true"><Sparkles size={22}/><span>CRALL</span></div>
      {items.map((item, index) => {
        const angle = (angles[index] ?? -90) * Math.PI / 180;
        const x = 50 + 38 * Math.cos(angle);
        const y = 50 + 38 * Math.sin(angle);
        return <Link key={`${item.id}-${item.label}`} to="/dashboard" search={{ tab: item.id }} onClick={requestTop} className="roleta-node" style={{ left: `${x}%`, top: `${y}%` }} aria-label={item.label}>
          <span className="roleta-node-icon"><item.icon size={22} strokeWidth={2.2}/></span>
          <span className="roleta-node-label">{item.label}</span>
        </Link>;
      })}
    </div>
  </section>;
}

function PageTitle({ icon, title, subtitle, action }: { icon: ReactNode; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="mb-7 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 sm:flex sm:justify-between"><div className="flex min-w-0 items-center gap-3"><span className="grid size-11 shrink-0 place-items-center rounded-lg bg-foreground text-background">{icon}</span><div className="min-w-0"><h1 className="text-xl font-bold sm:text-3xl">{title}</h1><p className="mt-1 text-sm text-muted-foreground">{subtitle}</p></div></div>{action}</div>;
}

function HomeView({store,money,income,expenses,invested,setStore,open}:{store:Store;money:(n:number)=>string;income:number;expenses:number;invested:number;setStore:React.Dispatch<React.SetStateAction<Store>>;open:(m:ReactNode)=>void}) {
  const cardBalances=getHomeCardBalances(store.banks,store.records);
  const transferIncome=store.records.filter(record=>record.type==="receita"&&(record.paymentMethod==="Pix"||record.paymentMethod==="Transferência")).reduce((sum,record)=>sum+record.amount,0);
  void income;
  void setStore; void open;
  const monthly=getMonthlyHomeValues(store.records);
  const shownCredit=cardBalances.credit;
  const shownExpenses=expenses;
  return <div className="home-overview rise-in space-y-5"><BalanceBar label="Crédito disponível" available={shownCredit} money={money} icon={<CreditCard size={18}/>} tone="text-primary" alertOnLow/><div className="rounded-2xl border-2 border-accent/60 bg-accent/10 p-4 shadow-[0_0_30px_var(--primary-glow)] sm:p-5"><span className="text-xs font-bold uppercase text-muted-foreground">GASTOS TOTAIS</span><strong className="financial-value mt-2 block font-display text-accent">− {money(shownExpenses)}</strong></div><div className="grid grid-cols-2 gap-3 sm:gap-4"><BalanceBar label="Débito disponível" available={cardBalances.debit} money={money} icon={<ArrowDownLeft size={18}/>} tone="text-[var(--income)]"/><DarkDatum label="Recebimento por transferência" value={`+ ${money(transferIncome)}`} tone="text-[var(--income)]"/></div><div className="grid grid-cols-2 gap-3 sm:gap-4"><DarkMetric label="Despesas fixas pagas" value={money(monthly.fixedPaid)} icon={<CalendarCheck/>} tone="text-accent"/><DarkMetric label="Investimento dos cartões" value={money(invested)} icon={<Sparkles/>} tone="text-[var(--reports)]" fit/></div></div>;
}

function BalanceBar({label,available,money,icon,tone,alertOnLow}:{label:string;available:number;money:(n:number)=>string;icon:ReactNode;tone:string;alertOnLow?:boolean}) {
  const siren=alertOnLow===true&&available<=500;
  const alert=alertOnLow===true&&!siren&&available<=1000;
  return <div className={`money-card rounded-2xl p-4 [container-type:inline-size] sm:p-5 ${siren?"blink-siren":alert?"blink-yellow":""}`}><div className={`flex items-center gap-2 ${tone}`}>{icon}<p className="text-xs font-bold uppercase text-muted-foreground">{label}</p></div><p className={`financial-value mt-3 font-display font-bold ${tone}`}>{money(available)}</p>{siren&&<p className="mt-2 animate-pulse text-xs font-bold text-destructive">Atenção! Urgente!</p>} {alert&&<p className="mt-2 text-xs font-bold text-[var(--warning,#eab308)]">Chegou a R$ 1.000!</p>}</div>;
}

function DarkDatum({label,value,tone}:{label:string;value:string;tone:string}) { return <div className="money-card rounded-2xl p-5 [container-type:inline-size]"><span className="text-xs font-bold uppercase text-muted-foreground">{label}</span><strong className={`financial-value mt-2 block font-display ${tone}`}>{value}</strong></div>; }
function DarkMetric({label,value,icon,tone,fit}:{label:string;value:string;icon:ReactNode;tone:string;fit?:boolean}) { return <div className="money-card rounded-2xl p-5 [container-type:inline-size]"><span className={`grid size-10 place-items-center rounded-xl bg-muted shadow-inner ${tone}`}>{icon}</span><p className="mt-5 text-xs font-bold uppercase text-muted-foreground">{label}</p><p className={`${fit?"financial-value-sm":"financial-value"} mt-2 font-display font-bold ${tone}`}>{value}</p></div>; }

function Metric({ label, value, icon, tone }: { label:string; value:string; icon:ReactNode; tone:string }) { return <div className="money-card h-full rounded-lg p-5"><div className={`mb-5 grid size-10 place-items-center rounded-lg shadow-[0_4px_0_color-mix(in_oklch,currentColor,transparent_82%)] ${tone}`}>{icon}</div><p className="text-sm text-muted-foreground">{label}</p><p className="mt-1 break-words font-display text-2xl font-bold">{value}</p></div>; }

function getCardUsage(records:RecordItem[]) {
  const grouped=records.filter(record=>record.type==="gasto"&&record.cardName).reduce<Record<string,{name:string;count:number;amount:number}>>((result,record)=>{const key=String(record.cardId??record.cardName);const current=result[key]??{name:record.cardName??"Cartão",count:0,amount:0};current.count+=1;current.amount+=record.amount;result[key]=current;return result},{});
  return Object.values(grouped).sort((a,b)=>b.count-a.count||b.amount-a.amount);
}

function DashboardView({store}:{store:Store}) {
  const [months,setMonths]=useState<3|6|12>(6);
  const [days,setDays]=useState<15|30>(30);
  const realMoney=(value:number)=>new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(value);
  const compactMoney=(value:number)=>new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL",notation:"compact",maximumFractionDigits:1}).format(value);
  const income=store.records.filter(record=>record.type==="receita").reduce((sum,record)=>sum+record.amount,0);
  const expenses=store.records.filter(record=>record.type==="gasto").reduce((sum,record)=>sum+record.amount,0);
  const totalYield=store.investments.reduce((sum,item)=>sum+Math.max(0,item.invested-item.withdrawal)*item.percentage/100,0);
  const cardUsage=getCardUsage(store.records);
  const monthFlow=useMemo(()=>{
    const now=new Date();
    return Array.from({length:months},(_,index)=>{
      const date=new Date(now.getFullYear(),now.getMonth()-(months-1-index),1);
      const key=`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}`;
      const monthly=store.records.filter(record=>record.date.slice(0,7)===key);
      return {month:new Intl.DateTimeFormat("pt-BR",{month:"short"}).format(date).replace(".",""),Entradas:monthly.filter(record=>record.type==="receita").reduce((sum,record)=>sum+record.amount,0),Gastos:monthly.filter(record=>record.type==="gasto").reduce((sum,record)=>sum+record.amount,0)};
    });
  },[months,store.records]);
  const now=new Date();
  const periodStart=new Date(now.getFullYear(),now.getMonth()-(months-1),1).toISOString().slice(0,10);
  const inPeriod=store.records.filter(r=>r.date>=periodStart);
  const sumOf=(list:RecordItem[],type:RecordItem["type"])=>list.filter(r=>r.type===type).reduce((sum,r)=>sum+r.amount,0);
  const change=(current:number,previous:number)=>previous>0?Math.round((current-previous)/previous*100):null;
  const isoDay=(d:Date)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  const dayStart=isoDay(new Date(now.getFullYear(),now.getMonth(),now.getDate()-(days-1)));
  const dayPrevStart=isoDay(new Date(now.getFullYear(),now.getMonth(),now.getDate()-(2*days-1)));
  const inDays=store.records.filter(r=>r.date>=dayStart);
  const inPrevDays=store.records.filter(r=>r.date>=dayPrevStart&&r.date<dayStart);
  const dayIncome=sumOf(inDays,"receita");const dayExpenses=sumOf(inDays,"gasto");const dayResult=dayIncome-dayExpenses;
  const dayPrevIncome=sumOf(inPrevDays,"receita");const dayPrevExpenses=sumOf(inPrevDays,"gasto");
  const categoryData=Object.entries(inPeriod.filter(r=>r.type==="gasto").reduce<Record<string,number>>((acc,r)=>{acc[r.category]=(acc[r.category]??0)+r.amount;return acc},{})).map(([name,valor])=>({name,valor})).sort((a,b)=>b.valor-a.valor);
  const cardDetails=store.banks.filter(b=>b.status!=="Arquivado").map(bank=>{const used=store.records.filter(r=>r.cardId===bank.id&&r.type==="gasto");const creditTotal=bank.creditLimit+store.records.filter(r=>r.cardId===bank.id&&r.type==="receita"&&r.accountType==="Crédito").reduce((s,r)=>s+r.amount,0);const creditSpent=used.filter(r=>r.paymentMethod==="Cartão crédito").reduce((s,r)=>s+r.amount,0);return {bank,count:used.length,amount:used.reduce((s,r)=>s+r.amount,0),credit:getCardAvailableBalance(bank,store.records,"Crédito"),debit:getCardAvailableBalance(bank,store.records,"Débito"),usage:creditTotal>0?Math.min(100,Math.round(creditSpent/creditTotal*100)):0}}).sort((a,b)=>b.count-a.count||b.amount-a.amount).slice(0,6);
  const monthKey=now.toISOString().slice(0,7);
  const fixedPaidTotal=store.fixedExpenses.filter(f=>f.paidMonths.includes(monthKey)).reduce((s,f)=>s+f.amount,0);
  const fixedPending=store.fixedExpenses.filter(f=>!f.paidMonths.includes(monthKey));
  const fixedPendingTotal=fixedPending.reduce((s,f)=>s+f.amount,0);
  const upcoming=fixedPending.slice().sort((a,b)=>a.dueDay-b.dueDay).slice(0,4);
  const cardInvested=store.banks.reduce((s,b)=>s+b.invested,0);
  const usdRate=store.currencyAssets.manualUsdRate??store.currencyAssets.autoUsdRate;const eurRate=store.currencyAssets.manualEurRate??store.currencyAssets.autoEurRate;
  const foreignPaid=(currency:"USD"|"EUR")=>store.foreignExpenses.filter(f=>f.paid&&f.currency===currency).reduce((s,f)=>s+f.amount,0);
  const fx=(currency:"USD"|"EUR",v:number)=>new Intl.NumberFormat("pt-BR",{style:"currency",currency}).format(v);
  const tooltipFormatter=(value:unknown)=>realMoney(Number(Array.isArray(value)?value[0]??0:value??0));
  return <div className="rise-in">
    <section className="money-card mt-6 rounded-lg p-5"><div className="flex flex-wrap items-center justify-between gap-3"><h2 className="font-bold">Resultado dos últimos {days} dias</h2><div className="flex rounded-lg bg-muted p-1" aria-label="Período do resultado">{([15,30] as const).map(value=><Button key={value} size="sm" variant={days===value?"primary":"ghost"} onClick={()=>setDays(value)}>{value} dias</Button>)}</div></div><p className="mt-4 flex flex-wrap items-baseline gap-x-3 gap-y-1 font-display text-lg font-bold sm:text-2xl"><span className="text-[var(--income)]">{realMoney(dayIncome)}</span><span className="text-muted-foreground">−</span><span className="text-[var(--records)]">{realMoney(dayExpenses)}</span><span className="text-muted-foreground">=</span><span className={dayResult>=0?"text-primary":"text-destructive"}>{dayResult>=0?"+":"−"} {realMoney(Math.abs(dayResult))}</span></p><p className={`mt-1 text-sm font-bold ${dayResult>=0?"text-primary":"text-destructive"}`}>{dayResult>=0?"Resultado positivo":"Resultado negativo"}</p><div className="mt-5 grid gap-3 sm:grid-cols-2"><ChangeBadge label="Entradas" value={change(dayIncome,dayPrevIncome)} goodWhenUp/><ChangeBadge label="Gastos" value={change(dayExpenses,dayPrevExpenses)} goodWhenUp={false}/></div><p className="mt-2 text-xs text-muted-foreground">Comparação com os {days} dias anteriores.</p></section>
    <div className="mt-5 grid gap-5 "><DynamicChart title="Gastos por categoria" subtitle="As três maiores estão destacadas" empty={!categoryData.length}><ResponsiveContainer width="100%" height="100%"><BarChart data={categoryData} layout="vertical" margin={{top:4,right:8,left:0,bottom:0}}><CartesianGrid stroke="var(--border)" strokeDasharray="4 4" horizontal={false}/><XAxis type="number" tickFormatter={value=>compactMoney(Number(value))} tick={{fill:"var(--muted-foreground)",fontSize:10}} axisLine={false} tickLine={false}/><YAxis type="category" dataKey="name" width={96} tick={{fill:"var(--muted-foreground)",fontSize:11}} axisLine={false} tickLine={false}/><Tooltip formatter={tooltipFormatter} contentStyle={{background:"var(--popover)",border:"1px solid var(--border)",borderRadius:"8px",color:"var(--popover-foreground)"}}/><RechartsBar dataKey="valor" name="Gasto" radius={[0,6,6,0]}>{categoryData.map((item,index)=><Cell key={item.name} fill={index<3?"var(--accent)":"var(--muted-foreground)"}/>)}</RechartsBar></BarChart></ResponsiveContainer></DynamicChart>
      <section className="money-card rounded-lg p-4 sm:p-5"><h2 className="font-bold">Despesas fixas de {new Intl.DateTimeFormat("pt-BR",{month:"long"}).format(now)}</h2><div className="mt-4 grid grid-cols-2 gap-3"><Data label="Total pago" value={realMoney(fixedPaidTotal)}/><Data label="Total pendente" value={realMoney(fixedPendingTotal)}/></div><h3 className="mt-5 text-sm font-bold text-muted-foreground">Próximos vencimentos</h3><ul className="mt-2 space-y-2">{upcoming.length?upcoming.map(f=><li key={f.id} className="flex items-center justify-between gap-3 rounded-lg bg-muted px-3 py-2 text-sm"><span className="min-w-0 break-words">{f.name} · dia {f.dueDay}</span><strong>{realMoney(f.amount)}</strong></li>):<li className="text-sm text-muted-foreground">Todas as despesas do mês estão pagas.</li>}</ul></section></div>
    <section className="money-card mt-5 rounded-lg p-4 sm:p-5"><h2 className="font-bold">Cartões mais usados</h2>{cardDetails.length?<div className="mt-4 overflow-x-auto"><table className="w-full min-w-[640px] text-left text-sm"><thead className="text-xs text-muted-foreground"><tr><th className="py-2">Cartão</th><th>Compras</th><th>Valor gasto</th><th>Crédito disp.</th><th>Débito disp.</th><th>Limite usado</th></tr></thead><tbody>{cardDetails.map(c=><tr key={c.bank.id} className="border-t border-border"><td className="py-2 font-bold">{c.bank.name}</td><td>{c.count}</td><td>{realMoney(c.amount)}</td><td>{realMoney(c.credit)}</td><td>{realMoney(c.debit)}</td><td><span className={c.usage>=80?"font-bold text-destructive":""}>{c.usage}%</span></td></tr>)}</tbody></table></div>:<EmptyState text="Nenhum cartão ativo"/>}</section>
    <div className="mt-5 grid gap-5"><section className="money-card rounded-lg p-4 sm:p-5"><h2 className="font-bold">Investimentos dos cartões</h2><p className="mt-1 text-sm text-muted-foreground">Somente em Real</p><p className="mt-4 font-display text-2xl font-bold text-[var(--reports)]">{realMoney(cardInvested)}</p></section></div>
    <section className="money-card mt-6 rounded-lg p-4 sm:p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="font-bold">Movimentação mensal</h2><p className="mt-1 text-sm text-muted-foreground">Toque nos pontos para conferir os valores</p></div><div className="flex rounded-lg bg-muted p-1" aria-label="Período do gráfico">{([3,6,12] as const).map(value=><Button key={value} size="sm" variant={months===value?"primary":"ghost"} onClick={()=>setMonths(value)}>{value} meses</Button>)}</div></div><div className="mt-5 h-64 w-full sm:h-80"><ResponsiveContainer width="100%" height="100%"><AreaChart data={monthFlow} margin={{top:8,right:4,left:-18,bottom:0}}><defs><linearGradient id="incomeArea" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--income)" stopOpacity={0.55}/><stop offset="95%" stopColor="var(--income)" stopOpacity={0.04}/></linearGradient><linearGradient id="expenseArea" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--records)" stopOpacity={0.5}/><stop offset="95%" stopColor="var(--records)" stopOpacity={0.04}/></linearGradient></defs><CartesianGrid stroke="var(--border)" strokeDasharray="4 4" vertical={false}/><XAxis dataKey="month" tick={{fill:"var(--muted-foreground)",fontSize:12}} axisLine={false} tickLine={false}/><YAxis tickFormatter={value=>compactMoney(Number(value))} tick={{fill:"var(--muted-foreground)",fontSize:11}} axisLine={false} tickLine={false}/><Tooltip formatter={tooltipFormatter} contentStyle={{background:"var(--popover)",border:"1px solid var(--border)",borderRadius:"8px",color:"var(--popover-foreground)"}}/><Legend/><Area type="monotone" dataKey="Entradas" stroke="var(--income)" strokeWidth={3} fill="url(#incomeArea)" activeDot={{r:6}} animationDuration={700}/><Area type="monotone" dataKey="Gastos" stroke="var(--records)" strokeWidth={3} fill="url(#expenseArea)" activeDot={{r:6}} animationDuration={900}/></AreaChart></ResponsiveContainer></div></section>
    </div>;
}

function ChangeBadge({label,value,goodWhenUp=true,note}:{label:string;value:number|null;goodWhenUp?:boolean;note?:string}) { const good=value!==null&&(goodWhenUp?value>=0:value<=0); return <div className="rounded-lg bg-muted p-3"><span className="block text-xs text-muted-foreground">{label}</span><strong className={`block font-display text-lg ${value===null?"":good?"text-primary":"text-destructive"}`}>{note??(value===null?"Sem comparação":`${value>0?"▲ +":value<0?"▼ ":""}${value}%`)}</strong></div>; }

function DynamicChart({title,subtitle,empty,children}:{title:string;subtitle:string;empty:boolean;children:ReactNode}) { return <section className="money-card rounded-lg p-4 sm:p-5"><h2 className="font-bold">{title}</h2><p className="mt-1 text-sm text-muted-foreground">{subtitle}</p><div className="mt-4 h-64 w-full">{empty?<div className="grid h-full place-items-center"><EmptyState text="Ainda não há dados para este gráfico"/></div>:children}</div></section>; }

function IncomeView({ store, money, expenses, totalInvested, totalYield, setStore, open, loadRates, loadSelic, changeForeignExpense }: { store:Store; money:(n:number)=>string; expenses:number; totalInvested:number; totalYield:number; setStore:React.Dispatch<React.SetStateAction<Store>>; open:(n:ReactNode)=>void; loadRates:()=>Promise<{rates:{USD:number;EUR:number}|null;date:string|null}>; loadSelic:()=>Promise<{rate:number|null;date:string|null}>; changeForeignExpense:(expense:ForeignExpense,action:"upsert"|"delete"|"pay",brlAmount?:number)=>Promise<void> }) {
  void loadSelic;
  const editBalance=()=>open(<EditModal title="Editar valor em conta" fields={[{key:"value",label:"Valor",type:"number",value:store.balance}]} onClose={()=>open(null)} onSave={v=>{setStore(s=>({...s,balance:Number(v["value"])}));open(null)}}/>);
  const removeInvestment=(id:number)=>setStore(s=>({...s,investments:s.investments.filter(i=>i.id!==id)}));
  const editInvestment=(item?:Investment)=>open(<EditModal title={item?"Editar investimento":"Novo investimento"} fields={[{key:"bank",label:"Banco",value:item?.bank??""},{key:"percentage",label:"Rendimento mensal (%)",type:"number",value:item?.percentage??0},{key:"value",label:"Valor atual",type:"number",value:item?.value??0},{key:"withdrawal",label:"Retirada",type:"number",value:item?.withdrawal??0},{key:"invested",label:"Capital aplicado",type:"number",value:item?.invested??0},{key:"applicationDate",label:"Data da aplicação",type:"date",value:item?.applicationDate??new Date().toISOString().slice(0,10)}]} onClose={()=>open(null)} onSave={v=>{const next={id:item?.id??Date.now(),bank:String(v["bank"]),percentage:Number(v["percentage"]),value:Number(v["value"]),withdrawal:Number(v["withdrawal"]),invested:Number(v["invested"]),applicationDate:String(v["applicationDate"])};setStore(s=>({...s,investments:item?s.investments.map(i=>i.id===item.id?next:i):[...s.investments,next]}));if(store.notifications?.yield)sendBrowserNotification("Rendimento mensal atualizado",`${next.bank}: ${next.percentage}% ao mês.`);open(null)}}/>);
  return <div className="rise-in"><ActionBar action={<Button onClick={()=>editInvestment()}><Plus size={18}/> <span className="hidden sm:inline">Investimento</span></Button>}/><div className="grid gap-4"><Metric label="Gastos totais" value={money(expenses)} icon={<ArrowUpRight/>} tone="bg-[var(--records)]"/></div>
    <div className="mt-7 grid grid-cols-2 gap-3"><Metric label="Total investido" value={money(totalInvested)} icon={<Sparkles/>} tone="bg-[var(--reports)]"/><Metric label="Rendimento mensal" value={money(totalYield)} icon={<ArrowDownLeft/>} tone="bg-[var(--income)]"/></div>
    <p className="mt-3 text-xs text-muted-foreground">Total investido soma apenas o capital investido. O rendimento mensal usa o capital investido restante após as retiradas.</p>
    <h2 className="mb-3 mt-8 text-xl font-bold">Investimentos financeiros</h2><div className="grid gap-4 ">{store.investments.length ? store.investments.map(i=>{const days=i.applicationDate?Math.max(0,Math.floor((Date.now()-new Date(`${i.applicationDate}T12:00:00`).getTime())/86400000)):30;const iofRate=iofRateForDays(days);const earnings=Math.max(0,i.value-i.invested);const iof=Math.min(i.withdrawal,earnings)*iofRate/100;return <article key={i.id} className="money-card rounded-lg p-5"><div className="flex items-start justify-between"><div className="min-w-0"><p className="text-sm text-muted-foreground">{i.bank}</p><p className="financial-value mt-1 font-display font-bold">{money(i.value)}</p><p className="mt-1 text-sm font-bold text-primary">+ {money(Math.max(0,i.invested-i.withdrawal)*i.percentage/100)} por mês</p></div><div className="flex"><Button variant="icon" size="icon" onClick={()=>editInvestment(i)} aria-label="Editar"><Edit3 size={17}/></Button><Button variant="icon" size="icon" onClick={()=>removeInvestment(i.id)} aria-label="Excluir"><Trash2 size={17}/></Button></div></div><div className="mt-5 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4"><Data label="Rendimento mensal" value={`${i.percentage}%`}/><Data label="Capital aplicado" value={money(i.invested)}/><Data label="Retirada" value={money(i.withdrawal)}/><Data label="IOF estimado" value={money(iof)}/></div><p className="mt-3 text-xs text-muted-foreground">IOF regressivo: {iofRate}% sobre o rendimento da retirada após {days} dias.</p></article>}) : <EmptyState text="Nenhum investimento cadastrado"/>}</div>
    <CurrencySection assets={store.currencyAssets} setAssets={currencyAssets=>setStore(s=>({...s,currencyAssets}))} loadRates={loadRates} foreignExpenses={store.foreignExpenses} money={money} changeForeignExpense={changeForeignExpense} open={open}/></div>;
}

function numberInPortuguese(value:number) {
  const units=["","um","dois","três","quatro","cinco","seis","sete","oito","nove","dez","onze","doze","treze","quatorze","quinze","dezesseis","dezessete","dezoito","dezenove"];
  const tens=["","","vinte","trinta","quarenta","cinquenta","sessenta","setenta","oitenta","noventa"];
  const hundreds=["","cento","duzentos","trezentos","quatrocentos","quinhentos","seiscentos","setecentos","oitocentos","novecentos"];
  const underThousand=(amount:number)=>{if(amount===100)return "cem";const parts:string[]=[];const hundred=Math.floor(amount/100);const rest=amount%100;if(hundred)parts.push(hundreds[hundred]??"");if(rest){const words=rest<20?(units[rest]??""):`${tens[Math.floor(rest/10)]??""}${rest%10?` e ${units[rest%10]??""}`:""}`;parts.push(words)}return parts.join(" e ")};
  const wholeWords=(amount:number)=>{if(amount===0)return "zero";const scales=[{value:1_000_000_000_000,singular:"trilhão",plural:"trilhões"},{value:1_000_000_000,singular:"bilhão",plural:"bilhões"},{value:1_000_000,singular:"milhão",plural:"milhões"},{value:1_000,singular:"mil",plural:"mil"}];let remaining=amount;const parts:string[]=[];for(const scale of scales){const count=Math.floor(remaining/scale.value);if(count){parts.push(scale.value===1_000&&count===1?"mil":`${underThousand(count)} ${count===1?scale.singular:scale.plural}`);remaining%=scale.value}}if(remaining)parts.push(underThousand(remaining));return parts.join(remaining>0&&parts.length>1&&remaining<100?" e ":" ")};
  const rounded=Math.round(Math.max(0,value)*100);const reais=Math.floor(rounded/100);const cents=rounded%100;const realText=`${wholeWords(reais)} ${reais===1?"real":"reais"}`;return cents?`${realText} e ${wholeWords(cents)} ${cents===1?"centavo":"centavos"}`:realText;
}

function iofRateForDays(days:number) { const rates=[96,93,90,86,83,80,76,73,70,66,63,60,56,53,50,46,43,40,36,33,30,26,23,20,16,13,10,6,3,0];return days>=30?0:rates[Math.max(0,days)]??0; }

function CurrencySection({assets,setAssets,loadRates,foreignExpenses,money,changeForeignExpense,open}:{assets:CurrencyAssets;setAssets:(assets:CurrencyAssets)=>void;loadRates:()=>Promise<{rates:{USD:number;EUR:number}|null;date:string|null}>;foreignExpenses:ForeignExpense[];money:(n:number)=>string;changeForeignExpense:(expense:ForeignExpense,action:"upsert"|"delete"|"pay",brlAmount?:number)=>Promise<void>;open:(v:ReactNode)=>void}) {
  const [refreshing,setRefreshing]=useState(false);
  const refresh=async()=>{setRefreshing(true);try{const result=await loadRates();if(result.rates)setAssets({...assets,autoUsdRate:result.rates.USD,autoEurRate:result.rates.EUR,ratesUpdatedAt:result.date??new Date().toISOString()})}finally{setRefreshing(false)}};
  useEffect(()=>{void refresh()},[]);
  const usdRate=assets.manualUsdRate??assets.autoUsdRate; const eurRate=assets.manualEurRate??assets.autoEurRate;
  const editCurrency=(currency:"USD"|"EUR")=>{const isUsd=currency==="USD";openCurrencyEditor(currency,isUsd?assets.usdInvested:assets.eurInvested,isUsd?assets.manualUsdRate:assets.manualEurRate)};
  const openCurrencyEditor=(currency:"USD"|"EUR",invested:number,manualRate:number|null)=>{
    const nextInvested=window.prompt(`Valor em Real investido para converter em ${currency}`,String(invested)); if(nextInvested===null)return;
    const nextRate=window.prompt(`Cotação manual de 1 ${currency} em Real. Deixe vazio para usar a automática.`,manualRate===null?"":String(manualRate)); if(nextRate===null)return;
    const validInvested=Math.max(0,Number(nextInvested)||0); const parsedRate=nextRate.trim()===""?null:Math.max(0,Number(nextRate)||0);
    setAssets({...assets,...(currency==="USD"?{usdInvested:validInvested,manualUsdRate:parsedRate}:{eurInvested:validInvested,manualEurRate:parsedRate})});
  };
  const currencyValue=(currency:"USD"|"EUR",value:number)=>new Intl.NumberFormat("pt-BR",{style:"currency",currency}).format(value);
  const convertedInvestment=(valueInReal:number,rate:number|null)=>rate&&rate>0?valueInReal/rate:null;
  const rateDate=assets.ratesUpdatedAt?new Intl.DateTimeFormat("pt-BR").format(new Date(`${assets.ratesUpdatedAt.slice(0,10)}T12:00:00`)):"Ainda não atualizada";
  return <section className="mt-10"><div className="mb-3 flex items-center justify-between gap-3"><div><h2 className="flex items-center gap-2 text-xl font-bold"><Coins size={21}/> Moedas</h2><p className="mt-1 text-sm text-muted-foreground">Valores investidos e conversão em Real</p></div><Button variant="icon" size="icon" onClick={()=>void refresh()} disabled={refreshing} aria-label="Atualizar cotações"><RefreshCw className={refreshing?"animate-spin":""} size={18}/></Button></div>
    <div className="grid gap-4 md:grid-cols-2">{(["USD","EUR"] as const).map(currency=>{const invested=currency==="USD"?assets.usdInvested:assets.eurInvested;const rate=currency==="USD"?usdRate:eurRate;const manual=currency==="USD"?assets.manualUsdRate:assets.manualEurRate;const converted=convertedInvestment(invested,rate);return <article key={currency} className="money-card rounded-lg p-5"><div className="flex items-start justify-between"><div><p className="text-sm font-bold text-muted-foreground">{currency==="USD"?"Dólar americano":"Euro"}</p><p className="mt-1 font-display text-2xl font-bold">{new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(invested)}</p><p className="mt-1 text-xs text-muted-foreground">Valor investido em Real</p></div><Button variant="icon" size="icon" onClick={()=>editCurrency(currency)} aria-label={`Editar ${currency}`}><Edit3 size={17}/></Button></div><div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-lg bg-muted p-3"><span className="block text-xs text-muted-foreground">Rendimento em {currency==="USD"?"Dólar":"Euro"}</span><strong className="block">{converted===null?"Cotação indisponível":currencyValue(currency,converted)}</strong></div><Data label={manual!==null?"Cotação manual":"Cotação automática"} value={rate?`R$ ${rate.toFixed(4)}`:"Indisponível"}/></div></article>})}</div>
    <p className="mt-2 text-xs text-muted-foreground">Cotação automática atualizada em {rateDate}. Uma cotação manual substitui a automática até ser apagada na edição.</p>
    <ForeignExpensesSection items={foreignExpenses} money={money} usdRate={usdRate} eurRate={eurRate} change={changeForeignExpense} open={open}/>
  </section>;
}

function ForeignExpensesSection({items,money,usdRate,eurRate,change,open}:{items:ForeignExpense[];money:(n:number)=>string;usdRate:number|null;eurRate:number|null;change:(expense:ForeignExpense,action:"upsert"|"delete"|"pay",brlAmount?:number)=>Promise<void>;open:(v:ReactNode)=>void}) {
 const foreignMoney=(item:ForeignExpense)=>new Intl.NumberFormat("pt-BR",{style:"currency",currency:item.currency}).format(item.amount);const rateFor=(item:ForeignExpense)=>item.currency==="USD"?usdRate:eurRate;const brlValue=(item:ForeignExpense)=>item.amount*(rateFor(item)??0);
 const edit=(item?:ForeignExpense)=>open(<EditModal title={item?"Editar despesa do exterior":"Nova despesa do exterior"} fields={[{key:"name",label:"Descrição",value:item?.name??""},{key:"amount",label:"Valor",type:"number",value:item?.amount??0},{key:"currency",label:"Moeda",type:"select",value:item?.currency??"USD",options:["USD","EUR"]},{key:"date",label:"Data",type:"date",value:item?.date??new Date().toISOString().slice(0,10)}]} onClose={()=>open(null)} onSave={values=>{const next:ForeignExpense={id:item?.id??Date.now(),name:String(values["name"]).trim().slice(0,100)||"Despesa do exterior",amount:Math.max(0,Number(values["amount"])),currency:values["currency"] as "USD"|"EUR",date:String(values["date"]),paid:item?.paid??false,paidAt:item?.paidAt??null,paidBrlAmount:item?.paidBrlAmount??null};open(null);void change(next,"upsert")}}/>);
 const remove=(item:ForeignExpense)=>open(<ConfirmActionModal title="Excluir despesa do exterior?" text={`${item.name} será removida de todos os seus aparelhos.`} actionLabel="Excluir despesa" close={()=>open(null)} confirm={()=>{open(null);void change(item,"delete")}}/>);
 const pay=(item:ForeignExpense)=>{const rate=rateFor(item);if(!rate){void sendBrowserNotification("Cotação indisponível","Atualize a cotação antes de pagar esta despesa.");return}const converted=brlValue(item);open(<ConfirmActionModal title="Marcar como pago?" text={`${foreignMoney(item)} será descontado uma única vez do rendimento em ${item.currency==="USD"?"Dólar":"Euro"}, sem alterar o Total em conta.`} actionLabel="Confirmar pagamento" close={()=>open(null)} confirm={()=>{open(null);void change(item,"pay",converted)}}/>)};
 return <section className="mt-8"><PageTitle icon={<Globe2/>} title="Despesas do exterior" subtitle="Compras em Dólar e Euro descontadas da moeda correspondente" action={<Button onClick={()=>edit()}><Plus size={18}/> Despesa</Button>}/><div className="mb-5 grid grid-cols-2 gap-3">{(["USD","EUR"] as const).map(currency=>{const paid=items.filter(i=>i.paid&&i.currency===currency).reduce((sum,i)=>sum+i.amount,0);const pending=items.filter(i=>!i.paid&&i.currency===currency).reduce((sum,i)=>sum+i.amount,0);const fmt=(v:number)=>new Intl.NumberFormat("pt-BR",{style:"currency",currency}).format(v);return <div key={currency} className="money-card rounded-lg p-4"><p className="text-xs font-bold uppercase text-muted-foreground">{currency==="USD"?"Dólar":"Euro"}</p><p className="mt-2 text-xs text-muted-foreground">Reduzido do saldo em {currency==="USD"?"Dólar":"Euro"}</p><p className="font-display text-lg font-bold text-destructive">− {fmt(paid)}</p><p className="mt-1 text-xs text-muted-foreground">Pendente: {fmt(pending)}</p></div>})}</div><div className="grid gap-4 md:grid-cols-2">{items.length?items.map(item=><article key={item.id} className="money-card rounded-lg p-5"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h3 className="break-words font-bold">{item.name}</h3><span className={`rounded-full px-2 py-1 text-xs font-bold ${item.paid?"bg-primary text-primary-foreground":"bg-[var(--reports)] text-foreground"}`}>{item.paid?"Pago":"Pendente"}</span></div><p className="mt-2 font-display text-2xl font-bold">{foreignMoney(item)}</p><p className="mt-1 break-words text-sm font-bold text-primary">{numberInPortuguese(item.amount)} · {item.currency}</p><p className="text-sm text-muted-foreground">{item.paid&&item.paidBrlAmount!==null?`Reduziu ${foreignMoney(item)} somente do saldo em ${item.currency==="USD"?"Dólar":"Euro"}`:`${money(brlValue(item))} pela cotação atual`} · {item.date}</p></div><div className="flex"><Button variant="icon" size="icon" onClick={()=>edit(item)} aria-label="Editar despesa do exterior"><Edit3 size={16}/></Button><Button variant="icon" size="icon" onClick={()=>remove(item)} aria-label="Excluir despesa do exterior"><Trash2 size={16}/></Button></div></div><Button className="mt-5 w-full" variant={item.paid?"secondary":"primary"} disabled={item.paid||!rateFor(item)} onClick={()=>pay(item)}>{item.paid?<><Check size={18}/> Pago</>:<><Check size={18}/> Marcar como pago</>}</Button></article>):<EmptyState text="Nenhuma despesa do exterior cadastrada"/>}</div></section>;
}

function EditableMetric({label,value,onEdit}:{label:string;value:string;onEdit:()=>void}) { return <div className="money-card rounded-lg p-5"><div className="flex justify-between"><Settings2 className="text-primary"/><Button variant="icon" size="icon" onClick={onEdit} aria-label={`Editar ${label}`}><Edit3 size={17}/></Button></div><p className="mt-4 text-sm text-muted-foreground">{label}</p><p className="mt-1 font-display text-2xl font-bold">{value}</p></div>; }
function Data({label,value}:{label:string;value:string}) { return <div className="rounded-lg bg-muted p-3"><span className="block text-xs text-muted-foreground">{label}</span><strong>{value}</strong></div>; }

function CardsView({banks,records,money,saveCard,deleteCard,open}:{banks:Bank[];records:RecordItem[];money:(n:number)=>string;saveCard:(card:Bank)=>Promise<void>;deleteCard:(card:Bank)=>Promise<void>;open:(v:ReactNode)=>void}) {
  const colors:CardColor[]=["Verde","Azul","Preto","Roxo","Rosa","Vermelho","Dourado","Cinza metálico","Prateado","Laranjado"];
  const brands:CardBrand[]=["Visa","Mastercard","Elo","American Express","Nenhuma"];
  const statuses:CardStatus[]=["Ativo","Bloqueado","Arquivado"];
  const edit=(bank?:Bank)=>open(<EditModal title={bank?"Editar cartão":"Adicionar cartão"} fields={[{key:"name",label:"Banco",value:bank?.name??""},{key:"brand",label:"Bandeira",type:"select",value:bank?.brand??"Nenhuma",options:brands},{key:"color",label:"Cor do cartão",type:"select",value:bank?.color==="Branco"?"Verde":bank?.color??"Verde",options:colors},{key:"status",label:"Status",type:"select",value:bank?.status??"Ativo",options:statuses},{key:"primary",label:"Cartão principal",type:"select",value:bank?.primary?"Sim":"Não",options:["Não","Sim"]},{key:"invested",label:"Valor de investimento",type:"number",value:bank?.invested??0},{key:"creditLimit",label:"Saldo em crédito",type:"number",value:bank?getCardAvailableBalance(bank,records,"Crédito"):0},{key:"debitBalance",label:"Saldo em débito",type:"number",value:bank?getCardAvailableBalance(bank,records,"Débito"):0},{key:"dueDay",label:"Dia do vencimento",type:"number",value:bank?.dueDay??10}]} onClose={()=>open(null)} onSave={v=>{const primary=v["primary"]==="Sim";const next:Bank={...bank,id:bank?.id??Date.now(),desiredBalances:{creditLimit:Math.max(0,Number(v["creditLimit"])),debitBalance:Math.max(0,Number(v["debitBalance"]))},name:String(v["name"]).trim().slice(0,80)||"Novo banco",color:v["color"] as CardColor,brand:v["brand"] as CardBrand,status:v["status"] as CardStatus,primary,invested:Math.max(0,Number(v["invested"])),creditLimit:Math.max(0,Number(v["creditLimit"])),debitBalance:Math.max(0,Number(v["debitBalance"])),dueDay:Math.min(31,Math.max(1,Number(v["dueDay"])))};open(null);void (async()=>{if(primary){const others=banks.filter(b=>b.primary&&b.id!==next.id);for(const other of others.slice(1))await saveCard({...other,primary:false})}await saveCard(next)})()}}/>);
  const confirmDelete=(bank:Bank)=>open(<ConfirmDeleteModal name={bank.name} close={()=>open(null)} confirm={()=>{open(null);void deleteCard(bank)}}/>);
  const today=new Date();
  const daysUntilDue=(day:number)=>daysToCardDue(day,today);
  const sorted=[...banks].sort((a,b)=>Number(!!b.primary)-Number(!!a.primary)||Number(a.status==="Arquivado")-Number(b.status==="Arquivado"));
 return <div className="rise-in"><ActionBar action={<Button onClick={()=>edit()}><Plus size={18}/> Cartão</Button>}/><div className="bank-card-grid">{sorted.map((bank,index)=>{const credit=getCardAvailableBalance(bank,records,"Crédito");const debit=getCardAvailableBalance(bank,records,"Débito");const dueIn=daysUntilDue(bank.dueDay);const status=bank.status??"Ativo";return <div key={bank.id} className={`min-w-0 ${status==="Arquivado"?"opacity-60":""}`}>
  <article aria-label={`Cartão ${bank.name}`} className={`card-premium bank-card-portrait text-[var(--card-contrast-dark)] ${cardTone(bank.color,index)}`}>
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-1">
      <span aria-hidden className="card-chip bank-card-chip"/>
      <div className="flex flex-col items-end gap-2">
        <div className="bank-card-actions">
          <Button variant="icon" size="icon" className="bank-card-action" title="Editar cartão" onClick={()=>edit(bank)} aria-label={`Editar cartão ${bank.name}`}><Edit3 size={15}/></Button>
          <Button variant="icon" size="icon" className="bank-card-action" title="Excluir cartão" onClick={()=>confirmDelete(bank)} aria-label={`Excluir cartão ${bank.name}`}><Trash2 size={15}/></Button>
        </div>
        <div className="flex justify-end"><BrandMark brand={bank.brand}/></div>
      </div>
    </div>
    <div className="bank-card-identity min-w-0">
      <h2 className="bank-card-name font-display font-extrabold">{bank.name}</h2>
      <div className="mt-2 flex flex-wrap gap-1">
        {bank.primary&&<span className="bank-card-primary inline-flex items-center gap-1 rounded-full bg-background/25 px-2 py-1 font-extrabold ring-1 ring-current/30"><span className="text-[var(--reports)]">★</span> PRINCIPAL</span>}
        {status!=="Ativo"&&<span className="rounded-full bg-background/25 px-2 py-1 text-[10px] font-bold">{status}</span>}
      </div>
    </div>
    <div className="bank-card-balances min-w-0">
      <div className="bank-card-balance"><span className="bank-card-label">Crédito</span><strong className="bank-card-value font-display tabular-nums">{money(credit)}</strong></div>
      <div className="bank-card-balance"><span className="bank-card-label">Débito</span><strong className="bank-card-value font-display tabular-nums">{money(debit)}</strong></div>
      <div className="bank-card-balance"><span className="bank-card-label">Investimento</span><strong className="bank-card-value font-display tabular-nums">{money(bank.invested)}</strong></div>
    </div>
    <div className="bank-card-footer">
      <p className="text-[11px] font-semibold opacity-90">Vencimento: dia {bank.dueDay}</p>
    </div>
  </article>
  <div className="mt-3 space-y-2">
    {status==="Ativo"&&dueIn<=5&&<p className="flex items-start gap-1.5 rounded-lg border border-accent/20 bg-accent/15 px-2 py-2 text-[11px] font-bold text-accent sm:px-3 sm:text-xs"><Bell size={14} className="mt-0.5 shrink-0"/><span className="min-w-0">{dueIn===0?"Fatura vence hoje":`Fatura vence em ${dueIn} dia${dueIn>1?"s":""}`}</span></p>}
  </div>
 </div>})}</div></div>;
}

function BrandMark({brand}:{brand?:CardBrand|undefined}) {
  if(!brand||brand==="Nenhuma") return null;
  if(brand==="Mastercard") return <span className="flex shrink-0 items-center" aria-label="Mastercard" title="Mastercard"><svg width="44" height="28" viewBox="0 0 44 28" aria-hidden="true"><circle cx="16" cy="14" r="12" fill="#EB001B"/><circle cx="28" cy="14" r="12" fill="#F79E1B" fillOpacity="0.9"/><path d="M22 4.4a12 12 0 0 1 0 19.2a12 12 0 0 1 0-19.2z" fill="#FF5F00"/></svg></span>;
  if(brand==="Visa") return <span className="shrink-0 rounded bg-[#1A1F71] px-2 py-0.5 font-display text-lg font-black italic tracking-wide text-[#F7B600]" aria-label="Visa">VISA</span>;
  if(brand==="Elo") return <span className="flex shrink-0 items-center gap-1 rounded-full bg-[#000] px-2.5 py-0.5 font-display text-base font-black text-[#fff]" aria-label="Elo"><i className="size-2 rounded-full bg-[#FFCB05]"/><i className="size-2 rounded-full bg-[#00A4E0]"/><i className="size-2 rounded-full bg-[#EF4123]"/>elo</span>;
  return <span className="shrink-0 rounded bg-[#2E77BC] px-1.5 py-0.5 text-center font-display text-[10px] font-black leading-tight text-[#fff]" aria-label="American Express">AMERICAN<br/>EXPRESS</span>;
}

function ConfirmDeleteModal({name,close,confirm}:{name:string;close:()=>void;confirm:()=>void}) { return <div className="fixed inset-0 z-50 grid place-items-end bg-foreground/40 backdrop-blur-sm sm:place-items-center sm:p-4" onMouseDown={event=>{if(event.target===event.currentTarget)close()}}><div role="dialog" aria-modal="true" className="w-full max-w-md rounded-t-xl bg-card p-6 shadow-2xl sm:rounded-xl"><h2 className="text-xl font-bold">Excluir cartão?</h2><p className="mt-2 text-sm text-muted-foreground">O cartão {name} será removido em todos os seus aparelhos.</p><div className="mt-6 flex justify-end gap-2"><Button variant="secondary" onClick={close}>Cancelar</Button><Button variant="destructive" onClick={confirm}>Excluir cartão</Button></div></div></div>; }

function cardTone(color:CardColor|undefined,index:number) { const tones:Record<CardColor,string>={Verde:"card-green",Azul:"card-blue",Preto:"bg-[var(--surface-deep)]",Roxo:"card-purple",Rosa:"card-pink",Vermelho:"bg-[var(--card-red-dark)]",Dourado:"card-gold","Cinza metálico":"card-metallic text-[var(--card-contrast-light)]",Prateado:"card-silver text-[var(--card-contrast-light)]",Branco:"card-white text-[var(--card-contrast-light)]",Laranjado:"card-orange"};return color?tones[color]:(["card-green","card-blue","card-purple","card-pink","card-gold"][index%5]??"card-green"); }

function FinancialTasksView({store,saveTasks}:{store:Store;saveTasks:(tasks:TasksState)=>void}) {
 return <div className="rise-in space-y-8"><TasksManager value={store.tasks} onChange={saveTasks}/></div>;
}

function FrotaProView({ userId, onEscape }: { userId: string; onEscape: () => void }) {
  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || event.data?.["type"] !== "crall-frotapro-escape") return;
      onEscape();
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [onEscape]);
  return <div className="rise-in money-card mx-auto w-full overflow-hidden rounded-2xl border-2 border-border">
    <iframe title="FrotaPro — Controle de Frota" src={`/frotapro/index.html?user=${encodeURIComponent(userId)}`} className="h-[min(78dvh,920px)] w-full bg-background" />
  </div>;
}

function RecordsView({records,banks,money,change,open}:{records:RecordItem[];banks:Bank[];money:(n:number)=>string;change:(record:RecordItem,action:"upsert"|"delete")=>Promise<void>;open:(v:ReactNode)=>void}) {
 const categories=["Assinaturas","Dinheiro","Doações","Vestuários","Supermercados","Lazer","Saúde","Transportes","Despesas fixas","Impostos","Despesas aleatórias","Empréstimos","Troco"].sort((a,b)=>b.length-a.length||a.localeCompare(b,"pt-BR"));
 const paymentMethods=financialPaymentMethods;
 const cardOptions=["Nenhum",...banks.map(bank=>bank.name)];
  const primaryCard=banks.find(bank=>bank.primary&&bank.status!=="Arquivado");
  const edit=(r?:RecordItem,duplicate=false)=>open(<EditModal title={duplicate?"Repetir lançamento":r?"Editar lançamento":"Novo lançamento"} fields={[{key:"title",label:"Descrição",value:r?.title??""},{key:"category",label:"Categoria",type:"select",value:r?.category??categories[0]??"Dinheiro",options:categories},{key:"paymentMethod",label:"Forma de pagamento",type:"select",value:paymentLabel(r?.paymentMethod)??"Transferência",options:paymentMethods},{key:"cardName",label:"Banco ou cartão",type:"select",value:r?.cardName??primaryCard?.name??"Nenhum",options:cardOptions},{key:"accountType",label:"Aplicar em",type:"select",value:r?.accountType??"Nenhum",options:["Nenhum","Crédito","Débito"]},{key:"amount",label:"Valor",type:"number",value:r?.amount??0},{key:"date",label:"Data",type:"date",value:r?.date??new Date().toISOString().slice(0,10)},{key:"type",label:"Tipo",type:"select",value:(r?.type??"gasto")==="receita"?"RECEITA":"GASTO",options:["RECEITA","GASTO"]}]} onClose={()=>open(null)} onSave={v=>{const cardName=String(v["cardName"]);const paymentMethod=submittedPaymentMethod(String(v["paymentMethod"]),r?.paymentMethod);const selectedAccount=String(v["accountType"]);const paymentAccount=paymentMethod==="Cartão crédito"?"Crédito":paymentMethod==="Cartão débito"?"Débito":undefined;const accountType=String(v["type"])==="RECEITA"&&(paymentMethod==="Pix"||paymentMethod==="Transferência")&&banks.some(item=>/santander/i.test(item.name)&&item.status!=="Arquivado")?"Débito":paymentAccount??selectedAccount;const type=String(v["type"]).toLowerCase() as "receita"|"gasto";const santander=type==="receita"&&(paymentMethod==="Pix"||paymentMethod==="Transferência")?banks.find(item=>/santander/i.test(item.name)&&item.status!=="Arquivado"):undefined;const bank=santander??(cardName!=="Nenhum"?banks.find(item=>item.name===cardName):undefined);const amount=Math.max(0,Number(v["amount"]));if(type==="gasto"&&paymentAccount){if(!bank){open(<BalanceWarningModal title="Escolha um cartão" text={`Para pagar no ${paymentAccount}, escolha um cartão com saldo disponível.`} close={()=>edit(r,duplicate)}/>);return}const available=getCardAvailableBalance(bank,records,paymentAccount,duplicate?undefined:r?.id);if(amount>available){open(<BalanceWarningModal title={`Saldo em ${paymentAccount.toLowerCase()} insuficiente`} text={`${bank.name} possui ${money(available)} disponíveis. A compra de ${money(amount)} não foi lançada. Escolha outro cartão ou forma de pagamento.`} close={()=>edit(r,duplicate)}/>);return}}const next:RecordItem={id:(duplicate?undefined:r?.id)??Date.now(),title:String(v["title"]).trim().slice(0,100)||"Lançamento",category:String(v["category"]),paymentMethod,amount,type,date:String(v["date"]),...(!duplicate&&r?.fixedExpenseId?{fixedExpenseId:r.fixedExpenseId,...(r.paidAt?{paidAt:r.paidAt}:{})}:{}),...(accountType==="Crédito"||accountType==="Débito"?{accountType}:{}),...(bank?{cardId:bank.id,cardName:bank.name}:{})};open(null);void change(next,"upsert")}}/>);
 const filtered=records;const hasFilters=false;
 const ordered=newestRecordsFirst(filtered);
 const groups=ordered.reduce<{date:string;items:RecordItem[]}[]>((list,r)=>{const date=recordDisplayDate(r);const last=list[list.length-1];if(last&&last.date===date)last.items.push(r);else list.push({date,items:[r]});return list},[]);
 const todayKey=new Date().toISOString().slice(0,10);
 const dayLabel=(date:string)=>date===todayKey?"Hoje":new Intl.DateTimeFormat("pt-BR",{weekday:"long",day:"2-digit",month:"long",year:"numeric"}).format(new Date(`${date}T12:00:00`));
 const listen=()=>{const W=window as unknown as {SpeechRecognition?:new()=>{lang:string;onresult:((e:{results:ArrayLike<ArrayLike<{transcript:string}>>})=>void)|null;onerror:(()=>void)|null;start:()=>void};webkitSpeechRecognition?:new()=>never};const SR=W.SpeechRecognition??W.webkitSpeechRecognition;if(!SR){open(<BalanceWarningModal title="Voz indisponível" text="Este navegador não permite lançar por voz. Use o botão de lançamento." close={()=>open(null)}/>);return}const rec=new SR();rec.lang="pt-BR";rec.onresult=e=>{const said=e.results[0]?.[0]?.transcript??"";const draft=parseVoiceRecord(said);if(!draft){open(<BalanceWarningModal title="Não entendi o valor" text={`CRALL ouviu: "${said}". Diga, por exemplo: "gastei 50 reais no mercado".`} close={()=>open(null)}/>);return}edit({id:0,title:draft.title,amount:draft.amount,type:draft.type,category:draft.type==="receita"?"Dinheiro":"Despesas aleatórias",date:new Date().toISOString().slice(0,10)},true)};rec.onerror=()=>undefined;rec.start()};
 return <div className="rise-in"><ActionBar action={<div className="flex gap-2"><Button variant="secondary" className="md:hidden" onClick={listen} aria-label="Lançar por voz com CRALL"><Mic size={18}/> CRALL</Button><Button onClick={()=>edit()}><Plus size={18}/> <span className="hidden sm:inline">Lançamento</span></Button></div>}/>
  {groups.length?<div className="space-y-6">{groups.map(group=>{const dayIncome=group.items.filter(r=>r.type==="receita").reduce((s,r)=>s+r.amount,0);const daySpent=group.items.filter(r=>r.type==="gasto").reduce((s,r)=>s+r.amount,0);return <section key={group.date}><div className="mb-2 flex flex-wrap items-baseline justify-between gap-2 px-1"><h2 className="text-sm font-bold capitalize">{dayLabel(group.date)}</h2><span className="text-xs text-muted-foreground"><span className="text-primary">+ {money(dayIncome)}</span> · <span className="text-destructive">− {money(daySpent)}</span></span></div><div className="space-y-3">{group.items.map(r=>{const bankIndex=banks.findIndex(b=>b.id===r.cardId);const bank=bankIndex>=0?banks[bankIndex]:undefined;return <article key={r.id} className="money-card rounded-lg p-4"><div className="grid grid-cols-[auto_minmax(0,1fr)] items-start gap-3">{(()=>{const base=bank?<MiniCard bank={bank} index={bankIndex}/>:<RecordIcon type={r.type}/>;const thumb=cardThumbnail(r.cardName??bank?.name);return thumb?<><img src={thumb.image} alt={`Cartão ${thumb.label}`} loading="lazy" width={64} height={40} className="hidden h-10 w-16 shrink-0 rounded-md border border-border object-cover shadow-sm lg:block"/><span className="lg:hidden">{base}</span></>:base})()}<div className="min-w-0"><strong className="block break-words leading-snug">{r.type==="gasto"&&r.category==="Doações"&&<span aria-label="Doação">💝 </span>}{r.title}</strong><span className="mt-1 block break-words text-xs leading-relaxed text-muted-foreground">{r.category}<span aria-hidden="true"> · </span>{paymentLabel(r.paymentMethod)??"Dinheiro"}{r.cardName&&<><span aria-hidden="true"> · </span>{r.cardName}</>}</span></div></div><div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-border pt-3"><div className="flex min-w-0 flex-wrap items-center gap-2">{r.type==="gasto"&&r.category==="Doações"&&<span className="donation-label">[DOAÇÃO]</span>}<strong className={`break-words font-display text-xl ${r.type==="receita"?"text-primary":"text-destructive"}`}>{r.type==="receita"?"+":"−"} {money(r.amount)}</strong></div><div className="flex gap-1"><Button variant="icon" size="icon" onClick={()=>edit(r,true)} aria-label="Repetir lançamento" title="Repetir lançamento"><RefreshCw size={16}/></Button><Button variant="icon" size="icon" onClick={()=>edit(r)} aria-label="Editar"><Edit3 size={16}/></Button><Button variant="icon" size="icon" onClick={()=>void change(r,"delete")} aria-label="Excluir"><Trash2 size={16}/></Button></div></div></article>})}</div></section>})}</div>:<div className="money-card rounded-lg"><EmptyState text={hasFilters?"Nenhum lançamento encontrado com esses filtros":"Nenhum lançamento registrado"}/></div>}</div>;
}
function MiniCard({bank,index}:{bank:Bank;index:number}) { return <span className={`relative grid h-10 w-14 shrink-0 place-items-center overflow-hidden rounded-md text-[9px] font-bold text-[var(--card-contrast-dark)] shadow-md ${bank.color==="Preto"?"ring-1 ring-foreground/40":""} ${cardTone(bank.color,index)}`} title={bank.name}><span className="max-w-full truncate px-1">{bank.name}</span>{bank.brand&&bank.brand!=="Nenhuma"&&<span className="absolute bottom-0.5 right-1 text-[7px] font-black">{bank.brand==="American Express"?"AMEX":bank.brand.toUpperCase()}</span>}</span>; }
function RecordIcon({type}:{type:RecordItem["type"]}) { return <span className={`grid size-10 shrink-0 place-items-center rounded-lg ${type==="receita"?"bg-[var(--income)]":"bg-[var(--records)]"}`}>{type==="receita"?<ArrowDownLeft size={18}/>:<ArrowUpRight size={18}/>}</span>; }
async function sendBrowserNotification(title:string,body:string) {
 if (!("Notification" in window)) return;
 let permission=Notification.permission;
 if(permission==="default") permission=await Notification.requestPermission();
 if(permission==="granted") new Notification(title,{body,icon:"/icon-192.png"});
}

function InboxModal({userId,onClose,onSettings}:{userId:string;onClose:()=>void;onSettings:()=>void}) {
 const items=useInbox(userId);
 const [holding,setHolding]=useState<string|null>(null);
 const timer=useRef<number|null>(null);
 const cancelHold=()=>{if(timer.current){window.clearTimeout(timer.current);timer.current=null}setHolding(null)};
 const startHold=(id:string)=>{cancelHold();setHolding(id);timer.current=window.setTimeout(()=>{deleteInboxItem(userId,id);cancelHold();if(items.length===1)onClose()},1000)};
 useEffect(()=>()=>cancelHold(),[]);
 const dayLabel=(at:number)=>{const date=new Date(at);const today=new Date();if(date.toDateString()===today.toDateString())return "Hoje";const yesterday=new Date(today);yesterday.setDate(today.getDate()-1);if(date.toDateString()===yesterday.toDateString())return "Ontem";return new Intl.DateTimeFormat("pt-BR",{day:"2-digit",month:"short"}).format(date)};
 const timeLabel=(at:number)=>new Intl.DateTimeFormat("pt-BR",{hour:"2-digit",minute:"2-digit"}).format(new Date(at));
 return <div className="fixed inset-0 z-50 grid place-items-end bg-foreground/40 backdrop-blur-sm sm:place-items-center sm:p-4" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><div role="dialog" aria-modal="true" className="flex max-h-[85dvh] w-full max-w-lg flex-col rounded-t-xl bg-card p-6 shadow-2xl sm:rounded-xl"><div className="mb-4 flex items-start justify-between gap-2"><div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-lg bg-[var(--reports)]"><Bell/></span><div><h2 className="text-xl font-bold">Notificações</h2><p className="text-sm text-muted-foreground">Segure uma mensagem por 1 segundo para excluir</p></div></div><div className="flex shrink-0 gap-1"><Button variant="icon" size="icon" onClick={onSettings} aria-label="Configurar notificações"><Settings2/></Button><Button variant="icon" size="icon" onClick={onClose} aria-label="Fechar"><X/></Button></div></div><div className="min-h-0 flex-1 space-y-2 overflow-y-auto">{items.length?items.map(item=><div key={item.id} className={`select-none touch-none rounded-lg border p-3 transition-opacity ${item.read?"border-border bg-background opacity-70":"border-primary/50 bg-primary/10 shadow-[0_0_18px_var(--primary-glow)]"}`} onPointerDown={()=>startHold(item.id)} onPointerUp={cancelHold} onPointerLeave={cancelHold} onPointerCancel={cancelHold}><div className="flex items-start justify-between gap-2"><div className="min-w-0"><strong className="block break-words text-sm">{item.title}</strong><span className="mt-0.5 block break-words text-xs leading-relaxed text-muted-foreground">{financialMessage(item.body)}</span></div><span className="flex shrink-0 items-center gap-1.5 text-[10px] text-muted-foreground">{dayLabel(item.at)} · {timeLabel(item.at)}{!item.read&&<i className="size-2 rounded-full bg-primary" aria-label="Não lida"/>}</span></div><div className="mt-2 h-1 overflow-hidden rounded-full bg-muted" aria-hidden>{holding===item.id&&<div className="h-full rounded-full bg-destructive" style={{animation:"delete-hold 1s linear forwards"}}/>}</div></div>):<EmptyState text="Nenhuma mensagem"/>}</div><div className="mt-4 flex flex-wrap gap-2"><Button className="min-w-0 flex-1" variant="secondary" disabled={!items.length} onClick={()=>{cancelHold();deleteAllInboxItems(userId);onClose()}}><Trash2 size={16}/>Excluir todas</Button><Button className="min-w-0 flex-1" variant="secondary" onClick={onClose}>Fechar</Button></div></div></div>;
}

function SettingsNoticeModal({close}:{close:()=>void}) { return <div className="fixed inset-0 z-50 grid place-items-end bg-foreground/40 backdrop-blur-sm sm:place-items-center sm:p-4" onMouseDown={e=>{if(e.target===e.currentTarget)close()}}><div role="dialog" aria-modal="true" aria-label="Configurações" className="w-full max-w-lg rounded-t-xl bg-card p-5 shadow-2xl sm:rounded-xl"><div className="mb-4 flex items-center justify-between gap-3"><div className="flex items-center gap-3"><span className="grid size-11 shrink-0 place-items-center rounded-lg bg-primary/15 text-primary"><Bell/></span><h2 className="text-xl font-bold">Configurações</h2></div><Button variant="icon" size="icon" onClick={close} aria-label="Fechar"><X/></Button></div><p className="rounded-xl border-2 border-border bg-background p-4 text-sm font-semibold text-muted-foreground">Por enquanto as Configurações estão sem a escolha de mensagens. Mais adiante você decide quais avisos quer receber — seus alertas atuais continuam salvos.</p><Button className="mt-4 w-full" variant="secondary" onClick={close}>Fechar</Button></div></div>; }
// Escolha de mensagens das notificações reabre quando o proprietário decidir editar as Configurações.
const MESSAGE_CHOICES_OPEN: boolean = true;
function NotificationsModal({settings,save,close,isAdmin}:{settings:NotificationSettings;save:(settings:NotificationSettings)=>void;close:()=>void;isAdmin:boolean}) {
  if (!MESSAGE_CHOICES_OPEN) return <SettingsNoticeModal close={close}/>;
  const [values,setValues]=useState(settings);
 const options=notificationOptions.filter(option=>!option.admin||isAdmin);
 const selectAll=(checked:boolean)=>setValues(current=>({...current,...Object.fromEntries(options.map(option=>[option.key,checked]))}));
 const submit=async()=>{if(options.some(option=>values[option.key])&&"Notification" in window&&Notification.permission==="default")await Notification.requestPermission();save({...values,receitasGastos:false});close()};
 return <div className="fixed inset-0 z-50 grid place-items-end bg-foreground/40 backdrop-blur-sm sm:place-items-center sm:p-4" onMouseDown={e=>{if(e.target===e.currentTarget)close()}}><div role="dialog" aria-modal="true" aria-label="Escolhas de notificações" className="flex max-h-[85dvh] w-full max-w-lg flex-col rounded-t-xl bg-card p-5 shadow-2xl sm:rounded-xl"><div className="mb-4 flex shrink-0 items-center justify-between gap-3"><div className="flex items-center gap-3"><span className="grid size-11 shrink-0 place-items-center rounded-lg bg-primary/15 text-primary"><Bell/></span><h2 className="text-xl font-bold">Notificações</h2></div><Button variant="icon" size="icon" onClick={close} aria-label="Fechar"><X/></Button></div><div className="mb-3 flex shrink-0 flex-wrap gap-2"><Button size="sm" variant="secondary" onClick={()=>selectAll(true)}><Check size={16}/>Marcar todas</Button><Button size="sm" variant="secondary" onClick={()=>selectAll(false)}><X size={16}/>Desmarcar todas</Button></div><div className="min-h-0 flex-1 space-y-2 overflow-y-auto">{options.map(({key,label})=><label key={key} className={`grid cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-4 rounded-lg border-2 p-3 ${values[key]?"border-primary/60 bg-primary/10":"border-border bg-background"}`}><span className="min-w-0 text-sm font-semibold">{label}</span><input type="checkbox" checked={values[key]} onChange={e=>setValues(v=>({...v,[key]:e.target.checked}))} className="size-5 shrink-0 accent-primary"/></label>)}</div><Button className="mt-4 w-full shrink-0" onClick={()=>void submit()}>Salvar notificações</Button></div></div>;
}

function FixedExpensesView({items,banks,records,money,change,open}:{items:FixedExpense[];banks:Bank[];records:RecordItem[];money:(n:number)=>string;change:(expense:FixedExpense,action:"upsert"|"delete"|"pay",month?:string,payment?:FixedExpensePayment)=>Promise<void>;open:(v:ReactNode)=>void}) {
 const now=new Date();
 const currentMonth=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;
 const [month,setMonth]=useState(currentMonth);
 const [status,setStatus]=useState<"pending"|"paid"|"all">("pending");
 const monthLabel=new Intl.DateTimeFormat("pt-BR",{month:"long",year:"numeric"}).format(new Date(`${month}-01T12:00:00`));
 const paidItems=items.filter(item=>item.paidMonths.includes(month));
 const pendingItems=items.filter(item=>!item.paidMonths.includes(month));
 const visibleItems=status==="paid"?paidItems:status==="pending"?pendingItems:items;
 const pendingTotal=pendingItems.reduce((sum,item)=>sum+item.amount,0);
 const paidTotal=paidItems.reduce((sum,item)=>sum+item.amount,0);
 const edit=(item?:FixedExpense)=>open(<EditModal title={item?"Editar despesa fixa":"Nova despesa fixa"} fields={[{key:"name",label:"Descrição",value:item?.name??""},{key:"amount",label:"Valor mensal",type:"number",value:item?.amount??0},{key:"dueDay",label:"Dia do vencimento",type:"number",value:item?.dueDay??10}]} onClose={()=>open(null)} onSave={v=>{const next:FixedExpense={id:item?.id??Date.now(),name:String(v["name"]).trim().slice(0,100)||"Despesa fixa",amount:Math.max(0,Number(v["amount"])),dueDay:Math.min(31,Math.max(1,Number(v["dueDay"]))),paidMonths:item?.paidMonths??[]};open(null);void change(next,"upsert")}}/>);
 const remove=(item:FixedExpense)=>open(<ConfirmActionModal title="Excluir despesa fixa?" text={`${item.name} será removida de todos os seus aparelhos.`} actionLabel="Excluir despesa" close={()=>open(null)} confirm={()=>{open(null);void change(item,"delete")}}/>);
  const pay=(item:FixedExpense)=>{if(!banks.length){open(<ConfirmActionModal title="Cadastre um cartão" text="Adicione um cartão antes de pagar uma despesa fixa." actionLabel="Entendi" close={()=>open(null)} confirm={()=>open(null)}/>);return}const choosePayment=()=>open(<EditModal title="Pagar despesa fixa" fields={[{key:"cardName",label:"Qual cartão?",type:"select",value:banks[0]?.name??"",options:banks.map(bank=>bank.name)},{key:"accountType",label:"Qual modo?",type:"select",value:"Débito",options:fixedPaymentModes}]} onClose={()=>open(null)} onSave={values=>{const bank=banks.find(candidate=>candidate.name===String(values["cardName"]));const mode=String(values["accountType"]);if(!bank||(mode!=="Crédito"&&mode!=="Débito"))return;const accountType=mode==="Crédito"?"Crédito":"Débito";const available=getCardAvailableBalance(bank,records,accountType);if(item.amount>available){open(<BalanceWarningModal title={`Saldo em ${mode.toLowerCase()} insuficiente`} text={`${bank.name} possui ${money(available)} disponíveis. O pagamento não foi realizado. Escolha outro cartão ou modo.`} close={choosePayment}/>);return}open(<ConfirmActionModal title="Confirmar pagamento?" text={`${money(item.amount)} será pago com ${bank.name} no ${mode.toLowerCase()} e descontado uma única vez em ${monthLabel}.`} actionLabel="Confirmar pagamento" close={()=>open(null)} confirm={()=>{open(null);void change(item,"pay",month,{cardId:bank.id,cardName:bank.name,accountType})}}/>)}}/>);choosePayment()};
 return <div className="rise-in"><ActionBar action={<Button onClick={()=>edit()}><Plus size={18}/> Despesa</Button>}/><div className="fixed-expense-totals mb-6 grid grid-cols-2 gap-3"><Metric label="Pendente no mês" value={money(pendingTotal)} icon={<ReceiptText/>} tone="bg-[var(--records)]"/><Metric label="Pago no mês" value={money(paidTotal)} icon={<CalendarCheck/>} tone="bg-[var(--income)]"/></div><div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><label className="text-sm font-bold">Mês<input aria-label="Escolher mês das despesas fixas" type="month" value={month} onChange={event=>setMonth(event.target.value||currentMonth)} className="mt-2 block min-h-10 w-full rounded-lg border border-input bg-card px-4 py-2 font-normal sm:w-auto"/></label><div className="grid grid-cols-3 rounded-lg bg-muted p-1" aria-label="Filtrar despesas fixas">{([['pending',`Pendentes (${pendingItems.length})`],['paid',`Pagas (${paidItems.length})`],['all',`Todas (${items.length})`]] as const).map(([value,label])=><Button key={value} size="sm" variant={status===value?"primary":"ghost"} onClick={()=>setStatus(value)}>{label}</Button>)}</div></div><div className="grid gap-4 md:grid-cols-2">{visibleItems.length?visibleItems.map(item=>{const paid=item.paidMonths.includes(month);return <article key={item.id} className="money-card rounded-lg p-5"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h2 className="truncate font-bold">{item.name}</h2><span className={`rounded-full px-2 py-1 text-xs font-bold ${paid?"bg-primary text-primary-foreground":"bg-[var(--reports)] text-foreground"}`}>{paid?"Pago":"Pendente"}</span></div><p className="mt-2 font-display text-2xl font-bold">{money(item.amount)}</p><p className="text-sm text-muted-foreground">Vence no dia {item.dueDay}</p></div><div className="flex"><Button variant="icon" size="icon" onClick={()=>edit(item)} aria-label="Editar despesa fixa"><Edit3 size={16}/></Button><Button variant="icon" size="icon" onClick={()=>remove(item)} aria-label="Excluir despesa fixa"><Trash2 size={16}/></Button></div></div><Button className="mt-5 w-full" variant={paid?"secondary":"primary"} disabled={paid} onClick={()=>pay(item)}>{paid?<><Check size={18}/> Pago em {monthLabel}</>:<><Check size={18}/> Marcar como pago</>}</Button></article>}):<EmptyState text={status==="paid"?"Nenhuma despesa paga neste mês":status==="pending"?"Nenhuma despesa pendente neste mês":"Nenhuma despesa fixa cadastrada"}/>}</div></div>;
}

function ConfirmActionModal({title,text,actionLabel,close,confirm}:{title:string;text:string;actionLabel:string;close:()=>void;confirm:()=>void}) { return <div className="fixed inset-0 z-50 grid place-items-end bg-foreground/40 backdrop-blur-sm sm:place-items-center sm:p-4" onMouseDown={event=>{if(event.target===event.currentTarget)close()}}><div role="dialog" aria-modal="true" className="w-full max-w-md rounded-t-xl bg-card p-6 shadow-2xl sm:rounded-xl"><h2 className="text-xl font-bold">{title}</h2><p className="mt-2 text-sm text-muted-foreground">{text}</p><div className="mt-6 flex justify-end gap-2"><Button variant="secondary" onClick={close}>Cancelar</Button><Button variant="destructive" onClick={confirm}>{actionLabel}</Button></div></div></div>; }

function BalanceWarningModal({title,text,close}:{title:string;text:string;close:()=>void}) { return <div className="fixed inset-0 z-50 grid place-items-end bg-foreground/40 backdrop-blur-sm sm:place-items-center sm:p-4"><div role="alertdialog" aria-modal="true" className="w-full max-w-md rounded-t-xl border border-destructive/40 bg-card p-6 shadow-2xl sm:rounded-xl"><span className="grid size-11 place-items-center rounded-lg bg-destructive text-destructive-foreground"><Bell size={20}/></span><h2 className="mt-4 text-xl font-bold">{title}</h2><p className="mt-2 text-sm text-muted-foreground">{text}</p><Button className="mt-6 w-full" onClick={close}>Escolher outra opção</Button></div></div>; }

function BottomNav({view,onSelect}:{view:string;onSelect:()=>void}) {return <><nav className="fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] left-1/2 z-40 -translate-x-1/2 rounded-lg glass-nav p-1 md:hidden" aria-label="Início no celular"><Button asChild variant="ghost" className="min-h-12 gap-2 px-5 text-primary" aria-current={view==='home'?'page':undefined}><Link to="/dashboard" search={{tab:'home'}} onClick={onSelect}><Home size={22}/>Início</Link></Button></nav><nav className="finance-bottom-nav fixed bottom-4 z-40 hidden items-center gap-1 rounded-lg glass-nav p-1 md:flex" aria-label="Navegação principal">{bottomTabs.map(tab=><Button asChild key={tab.id} variant="ghost" aria-current={view===tab.id?"page":undefined} className={`min-h-11 gap-2 ${view===tab.id?"text-primary":"text-muted-foreground"}`}><Link to="/dashboard" search={{tab:tab.id}} onClick={onSelect}><tab.icon size={20}/>{tab.label}</Link></Button>)}</nav></>}

type Field = { key:string; label:string; value:string|number; type?:"text"|"number"|"select"|"date"; options?:string[] };
function EditModal({title,fields,onClose,onSave}:{title:string;fields:Field[];onClose:()=>void;onSave:(v:Record<string,string|number>)=>void}) {
 const [values,setValues]=useState<Record<string,string|number>>(()=>Object.fromEntries(fields.map(f=>[f.key,f.value])));
  return <div className="fixed inset-0 z-50 grid place-items-end bg-foreground/40 p-0 backdrop-blur-sm sm:place-items-center sm:p-4" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><div role="dialog" aria-modal="true" className="max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-t-xl bg-card p-6 shadow-2xl sm:rounded-xl"><div className="mb-6 flex items-center justify-between"><h2 className="text-xl font-bold">{title}</h2><Button variant="icon" size="icon" onClick={onClose} aria-label="Fechar"><X size={20}/></Button></div><div className="space-y-4">{fields.map(f=><label key={f.key} className="block text-sm font-bold">{f.label}{f.type==="select"?<select value={values[f.key]} onChange={e=>setValues(v=>({...v,[f.key]:e.target.value}))} className="mt-2 w-full rounded-lg border border-input bg-background px-3 py-3 font-normal">{f.options?.map(o=><option key={o}>{o}</option>)}</select>:<input type={f.type??"text"} step={f.type==="number"?"0.01":undefined} value={values[f.key]} onChange={e=>setValues(v=>({...v,[f.key]:e.target.value}))} className="mt-2 w-full rounded-lg border border-input bg-background px-3 py-3 font-normal outline-none focus:ring-2 focus:ring-ring"/>}</label>)}</div><div className="mt-7 flex justify-end gap-2"><Button variant="secondary" onClick={onClose}>Cancelar</Button><Button onClick={()=>onSave(values)}>Salvar</Button></div></div></div>;
}

function EmptyState({text}:{text:string}) { return <div className="col-span-full grid min-h-32 place-items-center p-6 text-center text-sm text-muted-foreground">{text}</div>; }

function ActionBar({ action }: { action: ReactNode }) {
  return <div className="mb-5 flex justify-end">{action}</div>;
}
