import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { useEscapeClose } from "@/hooks/use-escape-close";
import { getMyLicense } from "@/lib/license.functions";

const SHOPPING_APP_URL = "https://listadecompras-com.lovable.app";

export const Route = createFileRoute("/_authenticated/compras")({
  head: () => ({ meta: [
    { title: "Lista de Compras — CRALL GESTOR" },
    { name: "description", content: "Lista de compras e estoque do app Mercado Inteligente, aberto dentro do CRALL GESTOR." },
    { property: "og:title", content: "Lista de Compras — CRALL GESTOR" },
    { property: "og:description", content: "Lista de compras integrada ao CRALL GESTOR." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: ComprasPage,
});

function ComprasPage() {
  const loadLicense = useServerFn(getMyLicense);
  const [admin, setAdmin] = useState<boolean | null>(null);
  useEffect(() => { void loadLicense().then(r => setAdmin(r.isAdmin)).catch(() => setAdmin(false)); }, [loadLicense]);
  const navigate = useNavigate();
  useEscapeClose(() => { void navigate({ to: "/dashboard", search: { tab: "home" } }); }, true, 10);
  if (admin === null) return <main className="finance-dark grid min-h-dvh place-items-center text-foreground"><p className="text-sm text-muted-foreground">Verificando acesso…</p></main>;
  if (!admin) return <main className="finance-dark grid min-h-dvh place-items-center text-foreground"><p className="text-sm text-muted-foreground">Acesso restrito ao proprietário.</p></main>;

  return <main className="finance-dark flex h-dvh flex-col text-foreground">
    <header className="flex items-center gap-3 border-b border-border px-4 py-2">
      <Link to="/dashboard" search={{ tab: "home" }} className="grid size-10 place-items-center rounded-xl border border-border bg-card" aria-label="Voltar ao painel"><ArrowLeft size={18}/></Link>
      <h1 className="font-display text-xl font-bold">Lista de Compras</h1>
    </header>
    <iframe title="Lista de Compras" src={SHOPPING_APP_URL} className="min-h-0 w-full flex-1 bg-background" allow="clipboard-read; clipboard-write"/>
  </main>;
}
