import { describe, expect, it } from "vitest";
import { daysToCardDue, getMonthlyHomeValues } from "@/lib/home-month";
describe("Monthly home indicators", () => {
  it("resets only the displayed period without modifying records", () => {
    const records = [{ date: "2026-09-30", type: "receita" as const, amount: 200, accountType: "Crédito" as const }, { date: "2026-10-01", type: "receita" as const, amount: 100, paymentMethod: "Pix" }, { date: "2026-10-02", type: "gasto" as const, amount: 30, paymentMethod: "Pix", fixedExpenseId: 1 }];
    const snapshot = JSON.stringify(records);
    expect(getMonthlyHomeValues(records, new Date(2026, 9, 3))).toEqual({ credit: 0, debit: 70, fixedPaid: 30 });
    expect(getMonthlyHomeValues(records, new Date(2026, 10, 1))).toEqual({ credit: 0, debit: 0, fixedPaid: 0 });
    expect(JSON.stringify(records)).toBe(snapshot);
  });
  it("uses the actual last day of the month for due dates", () => {
    expect(daysToCardDue(31, new Date(2026, 9, 29))).toBe(2);
    expect(daysToCardDue(31, new Date(2026, 1, 27))).toBe(1);
  });
});