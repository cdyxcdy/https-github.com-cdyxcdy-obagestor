import { describe, expect, it } from "vitest";
import { capitalizeTyped } from "../lib/auto-capitalize";

describe("auto capitalization", () => {
  it("capitalizes the first letter typed", () => expect(capitalizeTyped("", "a")).toBe("A"));
  it("capitalizes after a period and space", () => expect(capitalizeTyped("Pago. ", "c")).toBe("C"));
  it("keeps lowercase in the middle of a sentence", () => expect(capitalizeTyped("Pago ", "c")).toBe("c"));
  it("does not capitalize right after a period without space", () => expect(capitalizeTyped("R$10.", "5")).toBe("5"));
});