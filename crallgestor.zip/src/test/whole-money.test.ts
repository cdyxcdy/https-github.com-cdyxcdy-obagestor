import { describe, expect, it } from "vitest";
import { wholeMoney } from "@/lib/whole-money";

describe("wholeMoney", () => {
  it("removes cents keeping thousands", () => expect(wholeMoney(1500000)).toBe("R$ 1.500.000"));
  it("rounds cents", () => expect(wholeMoney(150.65)).toBe("R$ 151"));
});
