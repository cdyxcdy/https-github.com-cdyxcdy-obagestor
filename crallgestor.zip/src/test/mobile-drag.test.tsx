import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { useMobileSwipe } from '@/hooks/use-mobile-swipe';

afterEach(() => { cleanup(); vi.restoreAllMocks(); });
function setup(width = 393) {
  vi.spyOn(window, 'innerWidth', 'get').mockReturnValue(width);
  const edit = vi.fn();
  const select = vi.fn();
  function Page() {
    const handlers = useMobileSwipe('cards', select);
    return <div {...handlers}><button onClick={edit}>Editar cartão</button></div>;
  }
  render(<Page />);
  const button = screen.getByRole('button');
  const pointer = (type: string, x: number, y = 0) => fireEvent(button, Object.assign(new Event(type, { bubbles: true }), { pointerId: 1, pointerType: 'touch', clientX: x, clientY: y }));
  const click = () => fireEvent.click(button, { detail: 1 });
  const swipe = (dx: number, dy = 0) => {
    fireEvent.touchStart(button, { touches: [{ clientX: 100, clientY: 100 }] });
    fireEvent.touchMove(button, { touches: [{ clientX: 100 + dx, clientY: 100 + dy }] });
    fireEvent.touchEnd(button, { touches: [], changedTouches: [{ clientX: 100 + dx, clientY: 100 + dy }] });
  };
  return { edit, pointer, click, select, swipe };
}
it('does not edit after a horizontal drag on a control', () => {
  const { edit, pointer, click } = setup();
  pointer('pointerdown', 200); pointer('pointermove', 80); pointer('pointerup', 80); click();
  expect(edit).not.toHaveBeenCalled();
});
it('does not edit after vertical scrolling or cancellation', () => {
  const { edit, pointer, click } = setup();
  pointer('pointerdown', 100); pointer('pointermove', 100, 100); pointer('pointercancel', 100, 100); click();
  expect(edit).not.toHaveBeenCalled();
});
it('allows an intentional tap after a drag with small finger jitter', () => {
  const { edit, pointer, click } = setup();
  pointer('pointerdown', 200); pointer('pointerup', 80); click();
  expect(edit).not.toHaveBeenCalled();
  pointer('pointerdown', 100); pointer('pointerup', 105, 5); click();
  expect(edit).toHaveBeenCalledTimes(1);
});
it('does not change tablet clicks', () => {
  const { edit, pointer, click } = setup(834);
  pointer('pointerdown', 200); pointer('pointerup', 80); click();
  expect(edit).toHaveBeenCalledTimes(1);
});
it('returns from Cards to Home when swiping right over an edit button without editing', () => {
  const { select, swipe, click, edit } = setup();
  swipe(120, 10); click();
  expect(select).toHaveBeenCalledExactlyOnceWith('home');
  expect(edit).not.toHaveBeenCalled();
});
it('advances left over a button without editing', () => {
  const { select, swipe, click, edit } = setup();
  swipe(-120, 10); click();
  expect(select).toHaveBeenCalledExactlyOnceWith('records');
  expect(edit).not.toHaveBeenCalled();
});
it('keeps vertical scrolling and tablet gestures from navigating', () => {
  const mobile = setup(); mobile.swipe(20, 120);
  expect(mobile.select).not.toHaveBeenCalled();
  cleanup();
  const tablet = setup(834); tablet.swipe(120);
  expect(tablet.select).not.toHaveBeenCalled();
});