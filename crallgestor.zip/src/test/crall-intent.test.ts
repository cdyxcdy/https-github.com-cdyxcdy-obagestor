import { describe, expect, it } from "vitest";
import { requestedScreens, splitComparison, wantsImage, wantsPanel } from "@/lib/crall-intent";

describe("CRALL intents", () => {
  it("generates images only when explicitly asked", () => {
    expect(wantsImage("CRALL, crie um banner da minha loja")).toBe(true);
    expect(wantsImage("quanto gastei este mês?")).toBe(false);
  });
  it("opens the panel only when asked to show", () => {
    expect(wantsPanel("mostre meus gastos")).toBe(true);
    expect(wantsPanel("qual meu saldo")).toBe(false);
  });
  it("splits a two-section comparison side by side", () => {
    expect(splitComparison("Intro\n## A\nx\n## B\ny")).toEqual(["## A\nx", "## B\ny"]);
    expect(splitComparison("## Só uma")).toBeNull();
  });
});

describe("CRALL screens", () => {
  it("finds up to two requested screens in spoken order", () => {
    expect(requestedScreens("me mostra cartões e despesas fixas")).toEqual(["cards", "fixedExpenses"]);
    expect(requestedScreens("abre minhas tarefas")).toEqual(["tasks"]);
    expect(requestedScreens("qual meu saldo")).toEqual([]);
  });
});
