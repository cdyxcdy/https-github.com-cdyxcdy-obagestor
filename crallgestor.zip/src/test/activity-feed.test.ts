import { describe, expect, it } from 'vitest';
import { receivedTransfers, notificationVisible, NOTIFICATION_ROTATION_MS, RECEIPT_ROTATION_MS } from '../lib/activity-feed';
import { defaultNotifications } from '../lib/notification-settings';

describe('Desktop activity feeds', () => {
  it('rotates sidebar notices every four seconds', () => expect(NOTIFICATION_ROTATION_MS).toBe(4000));
  it('rotates receipts within the requested three to four seconds', () => expect(RECEIPT_ROTATION_MS).toBe(4000));
  it('totals only incoming Pix and transfers without changing records', () => {
    const records = [{id:1,type:'receita',paymentMethod:'Pix',amount:120,title:'Ana'}, {id:2,type:'receita',paymentMethod:'Transferência',amount:230,title:'João'}, {id:3,type:'gasto',paymentMethod:'Pix',amount:40,title:'Saída'}, {id:4,type:'receita',paymentMethod:'Dinheiro',amount:80,title:'Dinheiro'}];
    expect(receivedTransfers(records).reduce((total, item) => total + item.amount, 0)).toBe(350);
    expect(records.map(item => item.id)).toEqual([1,2,3,4]);
  });
  it('hides saved messages immediately when their category is unchecked', () => {
    expect(notificationVisible('Receita adicionada', {...defaultNotifications,incomeMessages:true})).toBe(true);
    expect(notificationVisible('Receita adicionada', {...defaultNotifications,incomeMessages:false})).toBe(false);
    expect(notificationVisible('Vencimento da fatura', {...defaultNotifications,cardDue:false})).toBe(false);
  });
});