import { afterEach, describe, expect, it } from "vitest";
import { registerEscapeClose } from "@/lib/escape-close";

const press = (key: string) => window.dispatchEvent(new KeyboardEvent("keydown", { key, bubbles: true }));

describe("Tecla ESC fecha a aba aberta", () => {
  afterEach(() => { document.body.innerHTML = ""; });

  it("fecha a janela registrada e para de fechar depois de registrada como ausente", () => {
    let closed = 0;
    const unregister = registerEscapeClose(() => { closed += 1; }, 10);
    press("Escape");
    expect(closed).toBe(1);
    unregister();
    press("Escape");
    expect(closed).toBe(1);
  });

  it("fecha somente a janela da frente quando há duas abertas", () => {
    const order: string[] = [];
    const unregisterTab = registerEscapeClose(() => order.push("aba"), 10);
    const unregisterWindow = registerEscapeClose(() => order.push("janela"), 20);
    press("Escape");
    expect(order).toEqual(["janela"]);
    unregisterWindow();
    press("Escape");
    expect(order).toEqual(["janela", "aba"]);
    unregisterTab();
  });

  it("deixa o diálogo do sistema fechar primeiro", () => {
    let closed = 0;
    const unregister = registerEscapeClose(() => { closed += 1; }, 10);
    document.body.innerHTML = '<div role="dialog" data-state="open"></div>';
    press("Escape");
    expect(closed).toBe(0);
    document.body.innerHTML = "";
    press("Escape");
    expect(closed).toBe(1);
    unregister();
  });

  it("ignora outras teclas", () => {
    let closed = 0;
    const unregister = registerEscapeClose(() => { closed += 1; }, 10);
    press("Enter");
    expect(closed).toBe(0);
    unregister();
  });
});
