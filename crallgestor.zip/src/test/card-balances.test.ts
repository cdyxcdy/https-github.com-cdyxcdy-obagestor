import { describe, expect, it } from 'vitest';
import { getCardAvailableBalance, getHomeCardBalances, getTotalExpenses } from '@/lib/card-balances';

describe('Home synchronized card balances', () => {
  it('adds debit purchases and paid fixed expenses to total expenses once', () => {
    const records = [
      { id: 1, cardId: 1, type: 'gasto' as const, amount: 50.25, paymentMethod: 'Cartão débito' },
      { id: 2, cardId: 1, type: 'gasto' as const, amount: 100, paymentMethod: 'Cartão crédito', fixedExpenseId: 5 },
      { id: 3, type: 'receita' as const, amount: 1000 },
    ];
    expect(getTotalExpenses(records)).toBe(150.25);
  });
  it('subtracts credit purchases on any card from that card and the Home sum', () => {
    const cards = [{ id: 1, creditLimit: 1000 }, { id: 2, creditLimit: 2000 }];
    const records = [{ id: 1, cardId: 2, type: 'gasto' as const, amount: 125.75, paymentMethod: 'Cartão crédito' }];
    expect(getCardAvailableBalance(cards[0] ?? {id: 0, creditLimit: 0}, records, 'Crédito')).toBe(1000);
    expect(getCardAvailableBalance(cards[1] ?? {id: 0, creditLimit: 0}, records, 'Crédito')).toBe(1874.25);
    expect(getHomeCardBalances(cards, records).credit).toBe(2874.25);
  });
  it('reconciles an edited zero credit balance despite earlier income', () => {
    const card = { id: 1, creditLimit: 1000, creditAdjustment: -1100 };
    const records = [{ id: 1, cardId: 1, type: 'receita' as const, accountType: 'Crédito' as const, amount: 200 }, { id: 2, cardId: 1, type: 'gasto' as const, paymentMethod: 'Cartão crédito', amount: 100 }];
    expect(getCardAvailableBalance(card, records, 'Crédito')).toBe(0);
    expect(getTotalExpenses(records)).toBe(100);
  });
  it('reconciles an edited zero debit balance without deleting expenses', () => {
    const card = { id: 1, creditLimit: 0, debitBalance: 500, debitAdjustment: -400 };
    const records = [{ id: 1, cardId: 1, type: 'gasto' as const, amount: 100, paymentMethod: 'Cartão débito' }];
    expect(getCardAvailableBalance(card, records, 'Débito')).toBe(0);
    expect(getTotalExpenses(records)).toBe(100);
  });
  it('recalculates edits and deletion without double subtracting', () => {
    const card = { id: 1, creditLimit: 1000 };
    const record = { id: 1, cardId: 1, type: 'gasto' as const, amount: 100, paymentMethod: 'Cartão crédito' };
    expect(getCardAvailableBalance(card, [record], 'Crédito', 1)).toBe(1000);
    expect(getCardAvailableBalance(card, [{ ...record, amount: 150 }], 'Crédito')).toBe(850);
    expect(getCardAvailableBalance(card, [], 'Crédito')).toBe(1000);
  });
  const banks = [{ id: 1, creditLimit: 2000, debitBalance: 800 }];
  it('includes opening balances rather than monthly movement alone', () => {
    expect(getHomeCardBalances(banks, [])).toEqual({ credit: 2000, debit: 800 });
  });
  it('matches card balances after credit and debit expenses', () => {
    const records = [{ id: 1, cardId: 1, type: 'gasto' as const, amount: 100, paymentMethod: 'Cartão crédito' }, { id: 2, cardId: 1, type: 'gasto' as const, amount: 50, paymentMethod: 'Cartão débito' }];
    expect(getHomeCardBalances(banks, records)).toEqual({ credit: 1900, debit: 750 });
    const bank = banks[0];
    if (!bank) throw new Error('Missing test card');
    expect(getCardAvailableBalance(bank, records, 'Crédito')).toBe(1900);
  });
  it('counts linked Pix only once and adds unlinked transfer receipts', () => {
    const records = [{ id: 1, cardId: 1, type: 'receita' as const, amount: 100, accountType: 'Débito' as const, paymentMethod: 'Pix' }, { id: 2, type: 'receita' as const, amount: 40, paymentMethod: 'Transferência' }];
    expect(getHomeCardBalances(banks, records).debit).toBe(940);
  });
  it('subtracts fixed Pix payments from debit without changing input', () => {
    const records = [{ id: 1, cardId: 1, type: 'gasto' as const, amount: 100, accountType: 'Débito' as const, paymentMethod: 'Pix', fixedExpenseId: 1 }];
    const before = JSON.stringify({ banks, records });
    expect(getHomeCardBalances(banks, records).debit).toBe(700);
    expect(JSON.stringify({ banks, records })).toBe(before);
  });
});