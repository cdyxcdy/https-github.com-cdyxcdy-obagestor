import { expect, it } from "vitest";
import { confirmedDeviceName } from "../lib/device-confirmation";
it("requires CLAUDINEY to confirm a new device", () => {
  expect(confirmedDeviceName("CLAUDINEY")).toBe(true);
  expect(confirmedDeviceName(" Claudiney ")).toBe(true);
  expect(confirmedDeviceName("Claudinei")).toBe(false);
  expect(confirmedDeviceName("")).toBe(false);
});