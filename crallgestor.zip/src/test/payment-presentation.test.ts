import { expect, it } from "vitest";
import { financialPaymentMethods, fixedPaymentModes, submittedPaymentMethod } from "@/lib/payment-presentation";
import { getHomeCardBalances } from "@/lib/card-balances";

it("does not offer Pix for new financial payments", () => {
  expect(financialPaymentMethods.includes("Pix")).toBe(false);
  expect(fixedPaymentModes).toEqual(["Débito", "Crédito"]);
});

it("preserves a legacy payment when editing another record field", () => {
  expect(submittedPaymentMethod("Transferência", "Pix")).toBe("Pix");
  expect(submittedPaymentMethod("Cartão débito", "Pix")).toBe("Cartão débito");
});

it("keeps legacy receipts and payments in available debit", () => {
  const cards = [{ id: 1, creditLimit: 2000, debitBalance: 800 }];
  const records = [
    { id: 1, cardId: 1, amount: 100, type: "receita" as const, accountType: "Débito" as const, paymentMethod: "Pix" },
    { id: 2, cardId: 1, amount: 50, type: "gasto" as const, accountType: "Débito" as const, paymentMethod: submittedPaymentMethod("Transferência", "Pix") },
  ];
  expect(getHomeCardBalances(cards, records)).toEqual({ credit: 2000, debit: 850 });
});