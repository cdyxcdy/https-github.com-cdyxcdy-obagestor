import { describe, expect, it } from 'vitest';
import { validateVehiclePhoto } from '@/lib/vehicle-photos';
import { vehicleSchema, reactivateVehicle } from '@/lib/tasks-schema';
describe('private vehicle photos', () => {
  const vehicle = { id: 1, name: 'Carro', plate: 'ABC1234', kind: 'Carro de passeio', odometer: 10000, finalKm: 15000, driverId: null, active: false };
  it('preserves legacy vehicles without requiring a photo', () => expect(vehicleSchema.parse(vehicle).photoPath).toBeUndefined());
  it('persists the photo through reactivation without changing the opening reading', () => {
    const photoPath = 'abc-def/123-456.jpg';
    const result = reactivateVehicle(vehicleSchema.parse({ ...vehicle, photoPath }));
    expect(result.photoPath).toBe(photoPath); expect(result.odometer).toBe(10000); expect(result.finalKm).toBe(15000);
  });
  it('accepts photos but rejects executable files and oversized images', () => {
    expect(validateVehiclePhoto({ type: 'image/jpeg', size: 1024 })).toBeNull();
    expect(validateVehiclePhoto({ type: 'text/html', size: 1024 })).not.toBeNull();
    expect(validateVehiclePhoto({ type: 'image/png', size: 10 * 1024 * 1024 + 1 })).not.toBeNull();
  });
});