import { describe, expect, it } from "vitest";
import { PDFDocument } from "pdf-lib";
import { assignEmployeeNumbers, buildEmployeeFormPdf, formatEmployeeNumber, nextEmployeeNumber, paydayIsTomorrow, validateEmployeeNumber } from "@/lib/employees";

describe("employees", () => {
  it("alerts one day before payday", () => {
    expect(paydayIsTomorrow(10, new Date(2026, 9, 9))).toBe(true);
    expect(paydayIsTomorrow(10, new Date(2026, 9, 10))).toBe(false);
  });
  it("clamps payday 31 to the month's last day", () => {
    expect(paydayIsTomorrow(31, new Date(2026, 10, 29))).toBe(true);
  });
  it("form PDF omits salary even when provided", async () => {
    const bytes = await buildEmployeeFormPdf({ nome: "Ana", salario: "9876" });
    const doc = await PDFDocument.load(bytes);
    expect(doc.getPageCount()).toBe(1);
    expect(new TextDecoder("latin1").decode(bytes)).not.toContain("9876");
  });
  it("numera cadastros antigos em ordem de criação", () => {
    const rows = [
      { data: { nome: "B" }, created_at: "2026-10-02T10:00:00Z" },
      { data: { nome: "A" }, created_at: "2026-10-01T10:00:00Z" },
      { data: { nome: "C" }, created_at: "2026-10-03T10:00:00Z" },
    ];
    expect(assignEmployeeNumbers(rows)).toEqual([2, 1, 3]);
    expect(formatEmployeeNumber(1)).toBe("01");
    expect(formatEmployeeNumber(100)).toBe("100");
  });
  it("mantém o número já salvo e não reaproveita o de quem saiu", () => {
    const rows = [
      { data: { nome: "A", matricula: "7" }, created_at: "2026-10-01T10:00:00Z" },
      { data: { nome: "B" }, created_at: "2026-10-02T10:00:00Z" },
    ];
    expect(assignEmployeeNumbers(rows)).toEqual([7, 1]);
    expect(nextEmployeeNumber([7, 1])).toBe(8);
  });
  it("aceita o número escolhido pelo proprietário", () => {
    expect(validateEmployeeNumber("7", [1, 2])).toEqual({ ok: true, number: 7 });
    expect(validateEmployeeNumber("007", [])).toEqual({ ok: true, number: 7 });
    expect(validateEmployeeNumber(" 12 ", [])).toEqual({ ok: true, number: 12 });
  });
  it("recusa número repetido, vazio, com letras ou acima de 4 dígitos", () => {
    const repeated = validateEmployeeNumber("7", [7, 3]);
    expect(repeated.ok).toBe(false);
    if (!repeated.ok) expect(repeated.message).toContain("já está em uso");
    expect(validateEmployeeNumber("", []).ok).toBe(false);
    expect(validateEmployeeNumber("abc", []).ok).toBe(false);
    expect(validateEmployeeNumber("0", []).ok).toBe(false);
    expect(validateEmployeeNumber("12345", []).ok).toBe(false);
  });
});
