import { expect, it } from 'vitest';
import { getDisplayedHomeCredit, getHomeCardBalances } from '@/lib/card-balances';

it('ignores legacy visual resets without changing card balances', () => {
  const cards = [{ id: 1, creditLimit: 2000, debitBalance: 500 }];
  const before = JSON.stringify(cards);
  const balances = getHomeCardBalances(cards, []);
  expect(getDisplayedHomeCredit(balances.credit, balances.credit)).toBe(2000);
  expect(getHomeCardBalances(cards, [])).toEqual({ credit: 2000, debit: 500 });
  expect(JSON.stringify(cards)).toBe(before);
});

it('shows full credit rather than differences above the reset baseline', () => {
  expect(getDisplayedHomeCredit(2300, 2000)).toBe(2300);
});

it('shows the real credit balance when no reset baseline exists', () => {
  expect(getDisplayedHomeCredit(2000)).toBe(2000);
});