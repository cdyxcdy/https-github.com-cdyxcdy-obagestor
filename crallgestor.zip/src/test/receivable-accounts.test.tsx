import { useState } from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import { TasksManager } from '@/components/tasks/TasksManager';
import { emptyTasks, type TasksState } from '@/lib/tasks-schema';

it('creates a receivable without changing payable accounts or other task sections', () => {
  const payable = { id: 1, title: 'Aluguel', kind: 'Pagar' as const, amount: 500, dueDate: '2026-10-10', person: '', settled: false };
  const onChange = vi.fn();
  render(<TasksManager value={{ ...emptyTasks, accounts: [payable] }} onChange={onChange} />);
  fireEvent.click(screen.getByRole('button', { name: 'Ver contas a receber' }));
  fireEvent.click(screen.getByRole('button', { name: 'Adicionar conta' }));
  fireEvent.change(screen.getByLabelText('Descrição'), { target: { value: 'Serviço prestado' } });
  fireEvent.change(screen.getByLabelText('Valor (R$)'), { target: { value: '250' } });
  fireEvent.click(screen.getByRole('button', { name: 'Salvar' }));
  expect(onChange).toHaveBeenCalledTimes(1);
  expect(onChange.mock.calls[0]?.[0]).toEqual({ ...emptyTasks, accounts: [payable, expect.objectContaining({ title: 'Serviço prestado', kind: 'Receber', amount: 250, settled: false })] });
});

it('moves only the selected receivable between pending and received groups and can reopen it', () => {
  const pending = { id: 2, title: 'Cliente pendente', kind: 'Receber' as const, amount: 250, dueDate: '2026-10-10', person: '', settled: false };
  const received = { ...pending, id: 3, title: 'Cliente recebido', amount: 80, settled: true };
  const payable = { ...pending, id: 1, title: 'Aluguel', kind: 'Pagar' as const, amount: 500 };
  const changes = vi.fn();
  function Harness() {
    const [tasks, setTasks] = useState<TasksState>({ ...emptyTasks, accounts: [payable, pending, received] });
    return <TasksManager value={tasks} onChange={next => { changes(next); setTasks(next); }} />;
  }
  render(<Harness />);
  fireEvent.click(screen.getByRole('button', { name: 'Ver contas a receber' }));
  expect(screen.queryByRole('heading', { name: payable.title })).toBeNull();
  expect(screen.queryByRole('heading', { name: received.title })).toBeNull();
  fireEvent.click(screen.getByRole('button', { name: 'Marcar como recebida' }));
  expect(changes.mock.calls[0]?.[0].accounts).toEqual([payable, { ...pending, settled: true }, received]);
  fireEvent.click(screen.getByRole('button', { name: 'Fechar A receber' }));
  fireEvent.click(screen.getByRole('button', { name: 'Ver contas recebidas' }));
  expect(screen.getByRole('heading', { name: pending.title })).toBeTruthy();
  const reopen = screen.getAllByRole('button', { name: 'Reabrir' })[0];
  if (!reopen) throw new Error('Missing receivable reopen action');
  fireEvent.click(reopen);
  expect(changes.mock.calls[1]?.[0].accounts).toEqual([payable, pending, received]);
});