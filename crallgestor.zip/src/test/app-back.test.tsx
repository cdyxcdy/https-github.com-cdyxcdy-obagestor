import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import { useState } from 'react';
import { it, expect } from 'vitest';
import { TasksWindow } from '@/components/tasks/TasksWindow';

it('native Back closes the nested window before its parent', async () => {
 function Harness(){const [child,setChild]=useState(false);const [parent,setParent]=useState(true);return parent?<TasksWindow title="Veículos" onClose={()=>setParent(false)}><button onClick={()=>setChild(true)}>Abrir edição</button>{child&&<TasksWindow title="Editar veículo" onClose={()=>setChild(false)}>Registro</TasksWindow>}</TasksWindow>:<p>Minhas Tarefas</p>}
 render(<Harness/>);
 await act(async()=>{await Promise.resolve()});
 fireEvent.click(screen.getByRole('button',{name:'Abrir edição'}));
 await act(async()=>{await Promise.resolve()});
 window.history.back();
 await waitFor(()=>expect(screen.queryByRole('heading',{name:'Editar veículo'})).toBeNull());
 expect(screen.getByRole('heading',{name:'Veículos'})).toBeTruthy();
 window.history.back();
 await waitFor(()=>expect(screen.queryByRole('heading',{name:'Veículos'})).toBeNull());
 expect(screen.getByText('Minhas Tarefas')).toBeTruthy();
});