import { describe, expect, it } from "vitest";
import { buildContractPdf, isValidDonee } from "@/lib/donation-contract";

describe("donation contract", () => {
  it("rejects donee without positive amount", () => {
    expect(isValidDonee({ name: "Ana", amount: 0, date: "2026-10-17" })).toBe(false);
  });
  it("accepts complete donee", () => {
    expect(isValidDonee({ id: "1", name: "Ana", document: "", amount: 50, date: "2026-10-17", status: "Pendente" })).toBe(true);
  });
  it("builds a PDF file", () => {
    expect(buildContractPdf(["CONTRATO"]).type).toBe("application/pdf");
  });
});
