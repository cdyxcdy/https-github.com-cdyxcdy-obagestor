import { describe, expect, it } from 'vitest';
import { emptyTasks, tasksSchema, fuelSchema, fuelMetrics, maintenanceStatus, vehicleSchema, addVehicleKm, reactivateVehicle, vehiclesActiveFirst, purchaseSchema } from '@/lib/tasks-schema';
describe('Private tasks and fleet',()=>{
 it('keeps old tasks readable with an empty shopping list',()=>{const {purchases,...legacy}=emptyTasks;expect(tasksSchema.parse(legacy).purchases).toEqual([])});
 it('stores the requested product choices, vehicle and separate costs',()=>{const item={id:1,product:'Pastilha de freio',condition:'Usado',origin:'Paralelo',vehicleId:2,partCost:250.50,laborCost:80};expect(purchaseSchema.parse(item)).toEqual(item);expect(purchaseSchema.safeParse({...item,condition:'Recondicionado'}).success).toBe(false);expect(purchaseSchema.safeParse({...item,origin:'Outro'}).success).toBe(false)});
 it('preserves shopping records in private tasks without changing account values',()=>{const purchase={id:1,product:'Filtro',condition:'Novo',origin:'Original',vehicleId:2,partCost:90,laborCost:30};const state=tasksSchema.parse({...emptyTasks,purchases:[purchase]});expect(state.purchases).toEqual([purchase]);expect(state.accounts).toEqual([])});

 it('shows active vehicles first without mutating stored order and updates after reactivation',()=>{
  const vehicles=[false,true,false,true].map((active,index)=>vehicleSchema.parse({id:index+1,name:`Veículo ${index+1}`,plate:`ABC${index}`,kind:'Carro de passeio',odometer:10000,driverId:null,active}));
  expect(vehiclesActiveFirst(vehicles).map(vehicle=>vehicle.id)).toEqual([2,4,1,3]);
  expect(vehicles.map(vehicle=>vehicle.id)).toEqual([1,2,3,4]);
  expect(vehiclesActiveFirst(vehicles.map(vehicle=>vehicle.id===1?{...vehicle,active:true}:vehicle)).map(vehicle=>vehicle.id)).toEqual([1,2,4,3]);
 });
 it('adds submitted kilometers to the odometer without multiplying',()=>{
  const vehicle=vehicleSchema.parse({id:1,name:'Carro',plate:'ABC1234',kind:'Carro de passeio',odometer:10000,driverId:null,active:true});
  const updated=addVehicleKm(vehicle,15000);
  expect(updated.odometer).toBe(25000);
  expect(addVehicleKm(updated,100).odometer).toBe(25100);
  expect(addVehicleKm(updated,0).odometer).toBe(25000);
  expect(()=>addVehicleKm(vehicle,-1)).toThrow();
  expect(()=>addVehicleKm({...vehicle,odometer:1_000_000_000},1)).toThrow();
 });
 it('never accumulates stored distances on reactivation or parsing',()=>{
  const vehicle=vehicleSchema.parse({id:1,name:'Carro',plate:'ABC1234',kind:'Carro de passeio',odometer:10000,finalKm:15000,driverId:null,active:false});
  const active=reactivateVehicle(vehicle);
  expect(active.finalKm).toBe(15000);
  expect(active.odometer).toBe(10000);
  expect(reactivateVehicle(active).odometer).toBe(10000);
  expect(reactivateVehicle({...active,active:false,finalKm:30000}).odometer).toBe(10000);
  expect(vehicleSchema.parse(active).odometer).toBe(10000);
 });
 it('preserves legacy vehicles without a final reading',()=>{const vehicle={id:1,name:'Carro',plate:'ABC1234',kind:'Carro de passeio',odometer:10000,driverId:null,active:false};expect(vehicleSchema.safeParse(vehicle).success).toBe(true);expect(reactivateVehicle(vehicleSchema.parse(vehicle)).odometer).toBe(10000)});
 it('starts without example records',()=>expect(tasksSchema.parse(emptyTasks)).toEqual({accounts:[],drivers:[],vehicles:[],maintenance:[],fuel:[],purchases:[]}));
 it('calculates consumption, distance and cost',()=>expect(fuelMetrics({startKm:100,endKm:400,liters:30,price:6})).toEqual({distance:300,cost:180,kmPerLiter:10,costPerKm:0.6}));
 it('rejects reversed kilometers and zero liters',()=>{expect(fuelSchema.safeParse({id:1,vehicleId:1,driverId:null,date:'2026-10-08',startKm:200,endKm:100,liters:10,price:6}).success).toBe(false);expect(fuelSchema.safeParse({id:1,vehicleId:1,driverId:null,date:'2026-10-08',startKm:100,endKm:200,liters:0,price:6}).success).toBe(false)});
 it('checks maintenance by date and kilometers',()=>{const v={id:1,vehicleId:1,title:'Óleo',dueDate:'2026-10-10',dueKm:1000,cost:200,completed:false};expect(maintenanceStatus(v,1000,'2026-10-08')).toBe('Vencida');expect(maintenanceStatus(v,500,'2026-10-11')).toBe('Vencida');expect(maintenanceStatus(v,500,'2026-10-10')).toBe('Vence hoje');expect(maintenanceStatus({...v,completed:true},1000,'2026-10-11')).toBe('Concluída')});
});