import { describe, it, expect } from 'vitest';
import { agendaSchema, appointmentSchema, appointmentsOnDay } from '@/lib/agenda';
import { collectReminders, defaultNotifications } from '@/lib/notification-settings';
import { emptyTasks } from '@/lib/tasks-schema';
const item={id:'a260f5a6-2fce-44e8-9d49-28ca9183aee1',title:'Consulta',date:'2026-10-15',time:'09:00',notes:'Particular',color:'cyan'};
describe('agenda particular',()=>{
  it('avisa somente um dia antes e respeita a escolha salva',()=>{const data={banks:[],fixedExpenses:[],tasks:emptyTasks,agenda:agendaSchema.parse([item])};expect(collectReminders(defaultNotifications,data,new Date(2026,9,14,12))).toHaveLength(1);expect(collectReminders(defaultNotifications,data,new Date(2026,9,13,12))).toHaveLength(0);expect(collectReminders(defaultNotifications,data,new Date(2026,9,15,12))).toHaveLength(0);expect(collectReminders({...defaultNotifications,agendaDue:false},data,new Date(2026,9,14,12))).toHaveLength(0);});
  it('preserva a cor escolhida e detalhes',()=>{expect(appointmentSchema.parse({...item,color:'coral'})).toMatchObject({color:'coral',notes:'Particular',time:'09:00'});});
  it('separa compromissos por dia e ordena horário sem alterar dados',()=>{const items=agendaSchema.parse([{...item,time:'14:00'},{...item,id:'0de94976-1749-47d8-ad24-d5fc37e5e166'},{...item,date:'2026-10-16'}]);expect(appointmentsOnDay(items,'2026-10-15').map(i=>i.time)).toEqual(['09:00','14:00']);expect(items[0]?.time).toBe('14:00');});
  it('rejeita datas inexistentes e horários inválidos',()=>{expect(appointmentSchema.safeParse({...item,date:'2026-02-30'}).success).toBe(false);expect(appointmentSchema.safeParse({...item,time:'25:00'}).success).toBe(false);});
});