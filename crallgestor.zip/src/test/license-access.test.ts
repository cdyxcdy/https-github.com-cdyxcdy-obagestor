import { describe, expect, it } from 'vitest';
import { ACCESS_PRICE_BRL, ACCESS_PERIOD_MS, TRIAL_PERIOD_MS, licenseAccess } from '../lib/license-access';
describe('Acesso por 30 dias', () => {
  it('cobra R$ 30 por período', () => { expect(ACCESS_PRICE_BRL).toBe(30); });
  it('usa exatamente 30 dias desde a liberação', () => { expect(ACCESS_PERIOD_MS).toBe(2592000000); });
  it('bloqueia no instante do vencimento', () => {
    const expiry = '2026-11-09T11:35:00Z';
    const license = { suspended_at: null, expires_at: expiry };
    expect(licenseAccess(license, false, Date.parse(expiry)-1).licensed).toBe(true);
    expect(licenseAccess(license, false, Date.parse(expiry)).licensed).toBe(false);
    expect(licenseAccess(license, false, Date.parse(expiry)).expired).toBe(true);
  });
  it('administrador não vence', () => { expect(licenseAccess({ suspended_at: '2026-10-01', expires_at: '2026-10-01' }, true).licensed).toBe(true); });
  it('suspensão manual bloqueia antes do vencimento', () => { expect(licenseAccess({ suspended_at: '2026-10-01', expires_at: '2026-12-01' }, false, Date.parse('2026-10-10')).licensed).toBe(false); });
  it('não libera licença ausente ou sem vencimento', () => {
    expect(licenseAccess(null, false).licensed).toBe(false);
    expect(licenseAccess({ suspended_at: null, expires_at: null }, false).licensed).toBe(false);
  });
});
describe('Teste único de 1 hora', () => {
  it('dura exatamente uma hora', () => { expect(TRIAL_PERIOD_MS).toBe(3600000); });
  it('oferece teste apenas para contas sem licença, nunca administradores', () => {
    expect(licenseAccess(null, false).trialAvailable).toBe(true);
    expect(licenseAccess(null, true).trialAvailable).toBe(false);
    expect(licenseAccess({ suspended_at: null, expires_at: '2026-10-10T13:00:00Z', access_kind: 'trial' }, false).trialAvailable).toBe(false);
  });
  it('bloqueia no fim da hora sem permitir outro teste', () => {
    const start = Date.parse('2026-10-10T12:00:00Z');
    const license = { suspended_at: null, expires_at: '2026-10-10T13:00:00Z', access_kind: 'trial' };
    expect(licenseAccess(license, false, start + 3599999).licensed).toBe(true);
    expect(licenseAccess(license, false, start + 3600000)).toMatchObject({ licensed: false, expired: true, trialAvailable: false, isTrial: true });
  });
  it('mantém trinta dias pagos após o teste', () => {
    const now = Date.parse('2026-10-10T13:00:00Z');
    const license = { suspended_at: null, expires_at: '2026-11-09T13:00:00Z', access_kind: 'paid', trial_started_at: '2026-10-10T12:00:00Z' };
    expect(Date.parse(license.expires_at) - now).toBe(2592000000);
    expect(licenseAccess(license, false, now)).toMatchObject({ licensed: true, isTrial: false, trialAvailable: false });
  });
});