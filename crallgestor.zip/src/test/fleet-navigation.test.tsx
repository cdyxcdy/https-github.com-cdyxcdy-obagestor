import { render, fireEvent, screen } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import { TasksManager } from '@/components/tasks/TasksManager';
import { emptyTasks } from '@/lib/tasks-schema';

it('opens shopping from a legacy task snapshot and preserves existing vehicles when saving', () => {
  const {purchases,...legacy}=emptyTasks;
  const vehicle={id:15,name:'Veículo existente',plate:'ABC1234',kind:'Moto' as const,odometer:12000,driverId:null,active:true};
  const onChange=vi.fn();
  render(<TasksManager value={{...legacy,vehicles:[vehicle]}} onChange={onChange}/>);
  fireEvent.click(screen.getByRole('button',{name:'Orçamentos de peças'}));
  fireEvent.click(screen.getByRole('button',{name:'Adicionar produto'}));
  fireEvent.change(screen.getByLabelText('Nome do produto'),{target:{value:'Filtro'}});
  fireEvent.change(screen.getByLabelText('Valor da peça (R$)'),{target:{value:'90'}});
  fireEvent.change(screen.getByLabelText('Valor da mão de obra (R$)'),{target:{value:'30'}});
  fireEvent.click(screen.getByRole('button',{name:'Salvar'}));
  expect(onChange).toHaveBeenCalledTimes(1);
  expect(onChange.mock.calls[0]?.[0].vehicles).toEqual([vehicle]);
  expect(onChange.mock.calls[0]?.[0].purchases).toEqual([expect.objectContaining({product:'Filtro',vehicleId:15,partCost:90,laborCost:30})]);
  expect(legacy).not.toHaveProperty('purchases');
});

it('does not scroll to top for any fleet selection, including repeated clicks', () => {
  const scroll = vi.spyOn(window, 'scrollTo').mockImplementation(() => {});
  const onChange = vi.fn();
  render(<TasksManager value={emptyTasks} onChange={onChange} />);
  scroll.mockClear();
  for (const name of ['Motoristas', 'Veículos', 'Manutenção']) {
    for (let opening = 0; opening < 2; opening++) {
      fireEvent.click(screen.getByRole('button', { name }));
      expect(scroll).not.toHaveBeenCalled();
      fireEvent.click(screen.getByRole('button', { name: `Fechar ${name}` }));
      expect(scroll).not.toHaveBeenCalled();
    }
  }
  expect(onChange).not.toHaveBeenCalled();
  scroll.mockRestore();
});

for (const name of ['Ver contas a pagar', 'Ver contas pagas']) {
  it(`preserves page position when selecting ${name}, including repeated selections`, () => {
    const scroll = vi.spyOn(window, 'scrollTo').mockImplementation(() => {});
    const onChange = vi.fn();
    render(<TasksManager value={emptyTasks} onChange={onChange} />);
    scroll.mockClear();
    fireEvent.click(screen.getByRole('button', { name }));
    fireEvent.click(screen.getByRole('button', { name: `Fechar ${name.includes('pagas') || name === 'Pagas' ? 'Pagas' : 'A pagar'}` }));
    fireEvent.click(screen.getByRole('button', { name }));
    expect(scroll).not.toHaveBeenCalled();
    expect(onChange).not.toHaveBeenCalled();
    scroll.mockRestore();
  });
}

it('keeps account details hidden until the matching group opens', () => {
  render(<TasksManager value={{...emptyTasks, accounts: [
    {id: 1, title: 'Aluguel pendente', kind: 'Pagar', amount: 500, dueDate: '2026-10-10', person: '', settled: false},
    {id: 2, title: 'Conta concluída', kind: 'Pagar', amount: 100, dueDate: '2026-10-10', person: '', settled: true},
  ]}} onChange={vi.fn()} />);
  expect(screen.queryByRole('heading', {name: 'Aluguel pendente'})).toBeNull();
  expect(screen.queryByRole('heading', {name: 'Conta concluída'})).toBeNull();
  fireEvent.click(screen.getByRole('button', {name: 'Ver contas a pagar'}));
  expect(screen.getByRole('heading', {name: 'Aluguel pendente'})).toBeTruthy();
  expect(screen.queryByRole('heading', {name: 'Conta concluída'})).toBeNull();
  fireEvent.click(screen.getByRole('button', {name: 'Fechar A pagar'}));
  fireEvent.click(screen.getByRole('button', {name: 'Ver contas pagas'}));
  expect(screen.getByRole('heading', {name: 'Conta concluída'})).toBeTruthy();
  expect(screen.queryByRole('heading', {name: 'Aluguel pendente'})).toBeNull();
});