import { describe, expect, it } from "vitest";
import { PDFDocument } from "pdf-lib";
import { createFinanceReport } from "../lib/report-pdf";

const input = {
  records: [{ title: "IPTU", category: "Impostos", amount: 100, type: "gasto" as const, date: "2026-10-06" }],
  categories: [["Impostos", 100]] as [string, number][],
  income: 500, expenses: 100, periodLabel: "Outubro de 2026", periodKey: "2026-10", currency: "BRL" as const,
  foreignExpenses: [], expensesByCurrency: { BRL: 100, USD: 0, EUR: 0 },
  dashboard: { balance: 400, totalInvested: 0, totalYield: 0, usdInvested: 0, eurInvested: 0, cardUsage: [], investmentYields: [] },
};

describe("Relatório financeiro PDF", () => {
  it("gera documento privado com metadados sem alterar os valores", async () => {
    const before = JSON.stringify(input);
    const document = await PDFDocument.load(await createFinanceReport(input));
    expect(document.getTitle()).toContain("Outubro de 2026");
    expect(document.getPageCount()).toBeGreaterThanOrEqual(3);
    expect(JSON.stringify(input)).toBe(before);
  });

  it("gera relatório vazio e pagina textos longos sem falhar com símbolos", async () => {
    const empty = await PDFDocument.load(await createFinanceReport({ ...input, records: [], categories: [], income: 0, expenses: 0 }));
    expect(empty.getPageCount()).toBeGreaterThan(0);
    const records = Array.from({ length: 65 }, (_, i) => ({ category: "Impostos", amount: 100, type: "gasto" as const, date: "2026-10-06", title: `Imposto ${i} 😀 - descrição detalhada de pagamento municipal e comprovante`, paymentMethod: "Transferência", cardName: "Banco com nome comprido para conferir a quebra de linhas" }));
    const document = await PDFDocument.load(await createFinanceReport({ ...input, records }));
    expect(document.getPageCount()).toBeGreaterThan(3);
  });
});