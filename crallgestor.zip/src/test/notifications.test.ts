import { describe, it, expect } from 'vitest';
import { collectReminders, defaultNotifications, notificationSettingsSchema } from '@/lib/notification-settings';
import { emptyTasks } from '@/lib/tasks-schema';

describe('Notification choices',()=>{
  it('keeps old income/expense choices and allows independent overrides',()=>{
    expect(notificationSettingsSchema.parse({receitasGastos:true}).incomeMessages).toBe(true);
    expect(notificationSettingsSchema.parse({receitasGastos:true,incomeMessages:false}).incomeMessages).toBe(false);
  });
  it('does not send deselected reminders',()=>{
    expect(collectReminders({...defaultNotifications,cardDue:false},{banks:[{id:1,name:'Banco',dueDay:8}],fixedExpenses:[],tasks:emptyTasks},new Date(2026,9,8))).toEqual([]);
  });
  it('includes due obligations and excludes settled accounts and completed maintenance',()=>{
    const tasks={...emptyTasks,accounts:[{id:1,title:'Conta',kind:'Pagar' as const,amount:100,dueDate:'2026-10-08',person:'',settled:false},{id:2,title:'Recebida',kind:'Receber' as const,amount:100,dueDate:'2026-10-08',person:'',settled:true}],maintenance:[{id:3,vehicleId:1,title:'Óleo',dueDate:'2026-11-08',dueKm:100,cost:100,completed:false}],vehicles:[{id:1,name:'Carro',plate:'ABC',kind:'Carro de passeio' as const,odometer:200,driverId:null,active:true}]};
    const reminders=collectReminders({...defaultNotifications,accountsPayDue:true,maintenanceDue:true},{banks:[],fixedExpenses:[],tasks},new Date(2026,9,8));
    expect(reminders.map(v=>v.id)).toEqual(['account-1','maintenance-3']);
    expect(reminders[0]?.body).toContain('vence hoje');
  });
  it('never generates upcoming or overdue receivable reminders even with the legacy choice enabled',()=>{
    const settings=notificationSettingsSchema.parse({cardDue:false,accountsPayDue:true,accountsReceiveDue:true});
    const tasks={...emptyTasks,accounts:[
      {id:1,title:'Próxima',kind:'Receber' as const,amount:100,dueDate:'2026-10-10',person:'',settled:false},
      {id:2,title:'Vencida',kind:'Receber' as const,amount:200,dueDate:'2026-10-01',person:'',settled:false},
      {id:3,title:'A pagar',kind:'Pagar' as const,amount:300,dueDate:'2026-10-08',person:'',settled:false},
    ]};
    expect(collectReminders(settings,{banks:[],fixedExpenses:[],tasks},new Date(2026,9,8)).map(item=>item.id)).toEqual(['account-3']);
  });
  it('discards the legacy fuel notification choice while preserving other choices',()=>{
    const settings=notificationSettingsSchema.parse({fuelRecords:true,maintenanceDue:true});
    expect(settings).not.toHaveProperty('fuelRecords');
    expect(settings.maintenanceDue).toBe(true);
  });
});