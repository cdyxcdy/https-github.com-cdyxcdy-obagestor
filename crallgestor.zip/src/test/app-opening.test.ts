import { describe, expect, it } from 'vitest';
import { createAppOpeningGuard } from '@/lib/app-opening';

describe('Default app opening', () => {
  it.each(['cards', 'records', 'tasks', 'fixedExpenses', 'dashboard'])('opens Home instead of a restored %s section', tab => {
    const guard = createAppOpeningGuard();
    expect(guard('enter', tab)).toBe(true);
    expect(guard('enter', tab)).toBe(false);
  });
  it('keeps navigation and Back available after opening Home', () => {
    const guard = createAppOpeningGuard();
    expect(guard('enter', undefined)).toBe(false);
    expect(guard('stay', 'tasks')).toBe(false);
    expect(guard('enter', 'cards')).toBe(false);
  });
  it('does not consume opening during preloading', () => {
    const guard = createAppOpeningGuard();
    expect(guard('preload', 'tasks')).toBe(false);
    expect(guard('enter', 'tasks')).toBe(true);
  });
});