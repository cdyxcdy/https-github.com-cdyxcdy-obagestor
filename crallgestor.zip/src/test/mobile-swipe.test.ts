import { describe, expect, it } from 'vitest';
import { swipeSection } from '@/lib/mobile-swipe';

describe('mobile section navigation', () => {
  it('only moves between Home and records', () => {
    expect(swipeSection('home', -100, 5, 393)).toBe('records');
    expect(swipeSection('records', -100, 5, 393)).toBeUndefined();
    expect(swipeSection('records', 100, 5, 393)).toBe('home');
    expect(swipeSection('home', 100, 5, 393)).toBeUndefined();
    expect(swipeSection('cards', -100, 5, 393)).toBeUndefined();
  });
  it('does not navigate on tablets or computers', () => {
    expect(swipeSection('home', -100, 0, 768)).toBeUndefined();
  });
  it('preserves vertical scrolling and ignores small movements', () => {
    expect(swipeSection('home', -100, 150, 393)).toBeUndefined();
    expect(swipeSection('home', -30, 0, 393)).toBeUndefined();
  });
});
