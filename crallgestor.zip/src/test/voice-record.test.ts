import { describe, expect, it } from 'vitest';
import { parseVoiceRecord } from '@/lib/voice-record';

describe('voice record parsing', () => {
  it('reads expenses with description', () => {
    expect(parseVoiceRecord('gastei 50 reais no mercado')).toEqual({ title: 'Mercado', amount: 50, type: 'gasto' });
  });
  it('reads income and cents', () => {
    expect(parseVoiceRecord('recebi 1.250,5 de salário')).toEqual({ title: 'Salário', amount: 1250.5, type: 'receita' });
  });
  it('rejects phrases without value', () => {
    expect(parseVoiceRecord('mercado')).toBeNull();
  });
});
