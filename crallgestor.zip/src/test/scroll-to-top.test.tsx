import { act, renderHook } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { useScrollToTop } from '@/hooks/use-scroll-to-top';

describe('section opening scroll', () => {
  it('opens at the top and resets on every opening, including repeated clicks', () => {
    const scroll = vi.spyOn(window, 'scrollTo');
    const { result, rerender } = renderHook(() => useScrollToTop());
    expect(scroll).toHaveBeenLastCalledWith({ top: 0, left: 0, behavior: 'instant' });
    scroll.mockClear();
    act(() => result.current());
    act(() => result.current());
    expect(scroll).toHaveBeenCalledTimes(2);
    rerender();
    expect(scroll).toHaveBeenCalledTimes(2);
    scroll.mockRestore();
  });
  it('returns to zero after navigation restores an old position and on repeated Home selections', () => {
    const frames = new Map<number, FrameRequestCallback>();
    let nextId = 0;
    let position = 500;
    const request = vi.spyOn(window, 'requestAnimationFrame').mockImplementation(callback => {
      const id = ++nextId; frames.set(id, callback); return id;
    });
    const cancel = vi.spyOn(window, 'cancelAnimationFrame').mockImplementation(id => { frames.delete(id); });
    const scroll = vi.spyOn(window, 'scrollTo').mockImplementation(options => {
      const value: unknown = options;
      if (typeof value === 'object' && value !== null && 'top' in value && typeof value.top === 'number') position = value.top;
    });
    const flushFrame = () => { const pending = [...frames.values()]; frames.clear(); act(() => pending.forEach(callback => callback(0))); };
    const { result, unmount } = renderHook(() => useScrollToTop());
    for (let click = 0; click < 3; click++) {
      position = 700;
      act(() => result.current());
      expect(position).toBe(0);
      position = 500; // Router restores a previously visited page position.
      flushFrame();
      expect(position).toBe(0);
      position = 300;
      flushFrame();
      expect(position).toBe(0);
    }
    act(() => result.current());
    unmount();
    expect(frames.size).toBe(0);
    scroll.mockRestore(); request.mockRestore(); cancel.mockRestore();
  });
});