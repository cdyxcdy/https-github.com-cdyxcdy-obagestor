import { useState } from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import { TasksManager } from '@/components/tasks/TasksManager';
import { emptyTasks, vehicleKmWarning, type TasksState } from '@/lib/tasks-schema';

it('adds final distance once on deactivation and never on reactivation',()=>{
 const onChange=vi.fn();
 function Harness(){const [value,setValue]=useState<TasksState>({...emptyTasks,vehicles:[{id:1,name:'Carro teste',plate:'ABC1234',kind:'Carro de passeio',odometer:10000,driverId:null,active:true}]});return <TasksManager value={value} onChange={next=>{onChange(next);setValue(next)}}/>}
 render(<Harness/>);
 fireEvent.click(screen.getByRole('button',{name:'Veículos'}));
 fireEvent.click(screen.getByRole('button',{name:'Ativo'}));
 expect(onChange).not.toHaveBeenCalled();
 fireEvent.submit(screen.getByRole('button',{name:'Salvar e desativar'}).closest('form') as HTMLFormElement);
 expect(onChange).not.toHaveBeenCalled();
 fireEvent.change(screen.getByLabelText('KM final'),{target:{value:'15000'}});
 fireEvent.click(screen.getByRole('button',{name:'Salvar e desativar'}));
 expect(onChange.mock.lastCall?.[0].vehicles[0]).toEqual(expect.objectContaining({odometer:25000,finalKm:15000,active:false}));
 fireEvent.click(screen.getByRole('button',{name:'Inativo'}));
 expect(onChange.mock.lastCall?.[0].vehicles[0]).toEqual(expect.objectContaining({odometer:25000,finalKm:15000,active:true}));
});

it('accepts distances below the odometer and rejects an overflowing sum',()=>{
 expect(vehicleKmWarning({odometer:10000,finalKm:9999})).toBeNull();
 expect(vehicleKmWarning({odometer:1_000_000_000,finalKm:1})).not.toBeNull();
 expect(vehicleKmWarning({odometer:10000,finalKm:10000})).toBeNull();
 expect(vehicleKmWarning({odometer:10000,finalKm:15000})).toBeNull();
});

it('edits odometer directly and adds each submitted final distance exactly once',()=>{
 const onChange=vi.fn();
 function Harness(){const [value,setValue]=useState<TasksState>({...emptyTasks,vehicles:[{id:1,name:'Carro edição',plate:'ABC1234',kind:'Carro de passeio',odometer:10000,finalKm:null,driverId:null,active:true}]});return <TasksManager value={value} onChange={next=>{onChange(next);setValue(next)}}/>}
 render(<Harness/>);
 fireEvent.click(screen.getByRole('button',{name:'Veículos'}));
 fireEvent.click(screen.getByRole('button',{name:'Editar odômetro de Carro edição'}));
 fireEvent.change(screen.getByLabelText('Odômetro'),{target:{value:'12000'}});
 fireEvent.click(screen.getByRole('button',{name:'Salvar'}));
 expect(onChange.mock.lastCall?.[0].vehicles[0]).toEqual(expect.objectContaining({odometer:12000,finalKm:null,active:true}));
 fireEvent.click(screen.getByRole('button',{name:'Editar KM final de Carro edição'}));
 fireEvent.change(screen.getByLabelText('KM final'),{target:{value:'15000'}});
 fireEvent.click(screen.getByRole('button',{name:'Salvar'}));
 expect(onChange.mock.lastCall?.[0].vehicles[0]).toEqual(expect.objectContaining({id:1,name:'Carro edição',plate:'ABC1234',kind:'Carro de passeio',driverId:null,odometer:27000,finalKm:15000,active:true}));
 fireEvent.click(screen.getByRole('button',{name:'Editar KM final de Carro edição'}));
 expect((screen.getByLabelText('KM final') as HTMLInputElement).value).toBe('');
 fireEvent.change(screen.getByLabelText('KM final'),{target:{value:'100'}});
 fireEvent.click(screen.getByRole('button',{name:'Salvar'}));
 expect(onChange.mock.lastCall?.[0].vehicles[0].odometer).toBe(27100);
 fireEvent.click(screen.getByRole('button',{name:'Editar KM final de Carro edição'}));
 fireEvent.click(screen.getByRole('button',{name:'Salvar'}));
 expect(onChange.mock.lastCall?.[0].vehicles[0].odometer).toBe(27100);
});

it('toggles driver status directly without affecting vehicles or accounts',()=>{
 const onChange=vi.fn();
 function Harness(){const [value,setValue]=useState<TasksState>({...emptyTasks,drivers:[{id:1,name:'Motorista teste',phone:'',license:'',licenseDue:'',active:true}]});return <TasksManager value={value} onChange={next=>{onChange(next);setValue(next)}}/>}
 render(<Harness/>);
 fireEvent.click(screen.getByRole('button',{name:'Motoristas'}));
 fireEvent.click(screen.getByRole('button',{name:'Ativo'}));
 expect(onChange.mock.lastCall?.[0].drivers[0].active).toBe(false);
 fireEvent.click(screen.getByRole('button',{name:'Inativo'}));
 expect(onChange.mock.lastCall?.[0].drivers[0].active).toBe(true);
 expect(onChange.mock.lastCall?.[0].vehicles).toEqual([]);
 expect(onChange.mock.lastCall?.[0].accounts).toEqual([]);
});

 it('completes and reopens maintenance by clicking its status without affecting other records',()=>{
 const onChange=vi.fn();
 function Harness(){const [value,setValue]=useState<TasksState>({...emptyTasks,maintenance:[{id:1,vehicleId:1,title:'Revisão teste',dueDate:'2099-01-01',dueKm:null,cost:100,completed:false}]});return <TasksManager value={value} onChange={next=>{onChange(next);setValue(next)}}/>}
 render(<Harness/>);
 fireEvent.click(screen.getByRole('button',{name:'Manutenção'}));
 fireEvent.click(screen.getByRole('button',{name:'Agendada'}));
 expect(onChange.mock.lastCall?.[0].maintenance[0].completed).toBe(true);
 fireEvent.click(screen.getByRole('button',{name:'Concluída'}));
 expect(onChange.mock.lastCall?.[0].maintenance[0].completed).toBe(false);
 expect(onChange.mock.lastCall?.[0].accounts).toEqual([]);
 expect(onChange.mock.lastCall?.[0].vehicles).toEqual([]);
 });
