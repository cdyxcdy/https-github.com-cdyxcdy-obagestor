import { describe, expect, it } from "vitest";
import { centsBalance } from "@/lib/cents-balance";

describe("centsBalance", () => {
  it("separates income and expense cents with net", () => {
    expect(centsBalance([{ type: "gasto", amount: 150.65 }, { type: "receita", amount: 200.4 }, { type: "receita", amount: 10 }]))
      .toEqual({ income: 0.4, expense: 0.65, net: -0.25 });
  });
});
