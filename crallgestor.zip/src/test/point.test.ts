import { describe, expect, it } from "vitest";
import { countPunchesOfDay, formatPunchTime, groupPunchesByDay, isPunchKind, punchDayLabel, punchLabel, type PunchLike } from "@/lib/point";

const at = (iso: string): PunchLike => ({ punched_at: iso });
const local = (y: number, m: number, d: number, h = 0, mi = 0) => new Date(y, m, d, h, mi).toISOString();

describe("point", () => {
  it("knows only the four punch kinds", () => {
    expect(isPunchKind("entrada")).toBe(true);
    expect(isPunchKind("saida")).toBe(true);
    expect(isPunchKind("intervalo")).toBe(true);
    expect(isPunchKind("retorno")).toBe(true);
    expect(isPunchKind("festa")).toBe(false);
    expect(punchLabel("festa")).toBe("Batida");
    expect(punchLabel("saida")).toBe("Saída");
  });

  it("shows punch time in pt-BR", () => {
    expect(formatPunchTime(local(2026, 9, 13, 8, 5))).toBe("08:05");
    expect(formatPunchTime("sem-data")).toBe("--:--");
  });

  it("groups punches newest day first and newest punch first", () => {
    const rows = [
      at(local(2026, 9, 12, 11, 0)),
      at(local(2026, 9, 13, 10, 30)),
      at(local(2026, 9, 13, 8, 0)),
    ];
    const groups = groupPunchesByDay(rows, new Date(2026, 9, 13, 9, 0, 0));
    expect(groups.map(g => g.items.length)).toEqual([2, 1]);
    expect(groups[0]?.label).toBe("Hoje");
    expect(groups[0]?.items.map(i => i.punched_at)).toEqual([local(2026, 9, 13, 10, 30), local(2026, 9, 13, 8, 0)]);
    expect(groups[1]?.label).toBe("Ontem");
  });

  it("names older days with the weekday and the date", () => {
    const now = new Date(2026, 9, 13, 9, 0, 0);
    expect(punchDayLabel("2026-10-10", now)).toBe("sábado, 10/10");
    expect(punchDayLabel("", now)).toBe("Sem data");
  });

  it("counts only today's punches", () => {
    const now = new Date(2026, 9, 13, 9, 0, 0);
    expect(countPunchesOfDay([at(local(2026, 9, 13, 7, 0)), at(local(2026, 9, 12, 7, 0))], now)).toBe(1);
  });
});
