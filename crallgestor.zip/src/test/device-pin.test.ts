import { describe, expect, it } from "vitest";
import { createDevicePin, failedPin, matchesDevicePin, pinStorageKey, validPin } from "../lib/device-pin";
describe("authorized device PIN", () => {
  it("requires exactly four numeric digits", () => {
    expect(validPin("1234")).toBe(true);
    for (const value of ["123", "12345", "abcd", "12 4"]) expect(validPin(value)).toBe(false);
  });
  it("scopes registration to the account", () => { expect(pinStorageKey("user-a")).not.toBe(pinStorageKey("user-b")); });
  it("verifies a salted PIN without storing plaintext", async () => {
    const record = await createDevicePin("1947");
    expect(record.hash).not.toContain("1947");
    expect(await matchesDevicePin("1947", record)).toBe(true);
    expect(await matchesDevicePin("1948", record)).toBe(false);
  });
  it("blocks after five failures for one minute", () => {
    let record = { salt: "", hash: "", failures: 0, blockedUntil: 0 };
    for (let i = 0; i < 4; i++) record = failedPin(record, 1000);
    expect(record.blockedUntil).toBe(0);
    record = failedPin(record, 1000);
    expect(record.blockedUntil).toBe(61000);
    expect(failedPin(record, 61000).failures).toBe(1);
  });
});