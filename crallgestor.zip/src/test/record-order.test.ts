import { describe, expect, it } from "vitest";
import { newestRecordsFirst, recordDisplayDate } from "../lib/record-order";

describe("Receitas e gastos: atuais de cima para baixo", () => {
  it("coloca a data mais atual primeiro sem mudar a lista armazenada", () => {
    const records = [{ id: 1, date: "2026-10-08" }, { id: 2, date: "2026-10-09" }, { id: 3, date: "2026-10-07" }];
    expect(newestRecordsFirst(records).map(record => record.id)).toEqual([2, 1, 3]);
    expect(records.map(record => record.id)).toEqual([1, 2, 3]);
  });

  it("coloca o último adicionado no topo dentro do mesmo dia", () => {
    expect(newestRecordsFirst([{ id: 100, date: "2026-10-09" }, { id: 300, date: "2026-10-09" }, { id: 200, date: "2026-10-09" }]).map(record => record.id)).toEqual([300, 200, 100]);
  });

  it("intercala despesas fixas pela data e hora pagas, não pelo vencimento ou ID sintético", () => {
    const fixed = { id: 900000000000001, fixedExpenseId: 1, date: "2026-10-28", paidAt: "2026-10-08T15:00:00.000Z" };
    const records = [fixed, { id: Date.parse("2026-10-08T16:00:00Z"), date: "2026-10-08" }, { id: Date.parse("2026-10-09T10:00:00Z"), date: "2026-10-09" }];
    expect(newestRecordsFirst(records).map(r => r.id)).toEqual([records[2]?.id, records[1]?.id, fixed.id]);
    expect(recordDisplayDate(fixed)).toBe("2026-10-08");
    expect(fixed.date).toBe("2026-10-28");
  });

  it("não fixa pagamentos antigos sem horário no topo por causa do ID elevado", () => {
    const records = [{ id: 900000000000001, fixedExpenseId: 1, date: "2026-10-08" }, { id: 100, date: "2026-10-08" }];
    expect(newestRecordsFirst(records).map(r => r.id)).toEqual([100, 900000000000001]);
    expect(records[0]?.id).toBe(900000000000001);
  });
});