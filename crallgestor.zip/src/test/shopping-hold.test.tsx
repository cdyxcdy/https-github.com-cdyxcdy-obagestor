import { act, fireEvent, render, screen, cleanup } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { ShoppingRecords } from '@/components/tasks/ShoppingRecords';
import { purchaseSchema } from '@/lib/tasks-schema';

const row = purchaseSchema.parse({id:1,product:'Filtro',condition:'Novo',origin:'Original',vehicleId:2,partCost:90,laborCost:30});
afterEach(() => {cleanup();vi.useRealTimers();vi.restoreAllMocks();});
const setup = () => {
  vi.useFakeTimers();
  const onToggle = vi.fn();
  render(<ShoppingRecords rows={[row]} vehicleName={()=>'Moto'} onEdit={vi.fn()} onRemove={vi.fn()} onToggle={onToggle}/>);
  const record=screen.getByRole('row',{name:'Filtro: Pendente'});
  const start=(target:Element=record)=>fireEvent(target,Object.assign(new Event('pointerdown',{bubbles:true}),{isPrimary:true,button:0,clientX:0,clientY:0}));
  return {onToggle,record,start};
};
it('marks the piece only after exactly one second',()=>{
  const {start,onToggle}=setup();start();
  act(()=>vi.advanceTimersByTime(999));expect(onToggle).not.toHaveBeenCalled();
  act(()=>vi.advanceTimersByTime(1));expect(onToggle).toHaveBeenCalledExactlyOnceWith(row);
});
it('does not mark a piece on a short press',()=>{
  const {start,onToggle,record}=setup();start();act(()=>vi.advanceTimersByTime(500));
  fireEvent.pointerUp(record);act(()=>vi.advanceTimersByTime(1000));expect(onToggle).not.toHaveBeenCalled();
});
it('keeps the one-second hold through small finger movements',()=>{
  const {start,onToggle,record}=setup();start();
  act(()=>vi.advanceTimersByTime(600));
  fireEvent(record,Object.assign(new Event('pointermove',{bubbles:true}),{clientX:12,clientY:0}));
  act(()=>vi.advanceTimersByTime(399));expect(onToggle).not.toHaveBeenCalled();
  act(()=>vi.advanceTimersByTime(1));expect(onToggle).toHaveBeenCalledExactlyOnceWith(row);
});
it('cancels the hold when the browser starts scrolling',()=>{
  const {start,onToggle,record}=setup();start();
  act(()=>vi.advanceTimersByTime(600));fireEvent.pointerCancel(record);
  act(()=>vi.advanceTimersByTime(1000));expect(onToggle).not.toHaveBeenCalled();
});
it('cancels when scrolling or holding an action button',()=>{
  const {start,onToggle,record}=setup();start();
  fireEvent(record,Object.assign(new Event('pointermove',{bubbles:true}),{clientX:20,clientY:0}));
  act(()=>vi.advanceTimersByTime(1000));expect(onToggle).not.toHaveBeenCalled();
  start(screen.getByRole('button',{name:'Editar Filtro'}));act(()=>vi.advanceTimersByTime(1000));expect(onToggle).not.toHaveBeenCalled();
});
it('retains completion and costs through validation without requiring completion on old records',()=>{
  expect(purchaseSchema.parse({...row,purchased:true})).toEqual({...row,purchased:true});
  expect(purchaseSchema.parse(row)).toEqual(row);
});
it('uses a checkbox instead of a hold on desktop and supports unchecking',()=>{
  vi.spyOn(window, 'matchMedia').mockImplementation(query => ({matches:true,media:query,onchange:null,addListener:vi.fn(),removeListener:vi.fn(),addEventListener:vi.fn(),removeEventListener:vi.fn(),dispatchEvent:()=>false}));
  const {start,onToggle}=setup();
  start();act(()=>vi.advanceTimersByTime(1000));expect(onToggle).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('checkbox'));
  expect(onToggle).toHaveBeenCalledExactlyOnceWith(row);
  cleanup();
  const purchased={...row,purchased:true};
  render(<ShoppingRecords rows={[purchased]} vehicleName={()=>'Moto'} onEdit={vi.fn()} onRemove={vi.fn()} onToggle={onToggle}/>);
  fireEvent.click(screen.getByRole('checkbox'));
  expect(onToggle).toHaveBeenLastCalledWith(purchased);
});