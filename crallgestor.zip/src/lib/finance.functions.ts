import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { financeCardSchema, financeStatePatchSchema, financeStateSchema, fixedExpenseSchema, foreignExpenseSchema } from "./finance-schema";

export const getFinanceState = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("finance_states")
      .select("state, updated_at")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) throw new Error("Não foi possível carregar seus dados.");
    if (!data) return null;
    const parsed = financeStateSchema.safeParse(data.state);
    return parsed.success ? { state: parsed.data, updatedAt: data.updated_at } : null;
  });

export const getExchangeRates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    try {
      const response = await fetch("https://api.frankfurter.app/latest?from=BRL&to=USD,EUR", {
        headers: { Accept: "application/json" },
      });
      if (!response.ok) return { rates: null, date: null };
      const payload = await response.json() as { date?: unknown; rates?: { USD?: unknown; EUR?: unknown } };
      const usdPerReal = Number(payload.rates?.USD);
      const eurPerReal = Number(payload.rates?.EUR);
      if (!(usdPerReal > 0) || !(eurPerReal > 0)) return { rates: null, date: null };
      return {
        rates: { USD: 1 / usdPerReal, EUR: 1 / eurPerReal },
        date: typeof payload.date === "string" ? payload.date : null,
      };
    } catch {
      return { rates: null, date: null };
    }
  });

export const getSelicRate = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    try {
      const response = await fetch("https://api.bcb.gov.br/dados/serie/bcdata.sgs.1178/dados/ultimos/1?formato=json", { headers: { Accept: "application/json" } });
      if (!response.ok) return { rate: null, date: null };
      const payload = await response.json() as Array<{ data?: unknown; valor?: unknown }>;
      const latest = payload[0];
      const rate = Number(String(latest?.valor ?? "").replace(",", "."));
      return Number.isFinite(rate) ? { rate, date: typeof latest?.data === "string" ? latest.data : null } : { rate: null, date: null };
    } catch { return { rate: null, date: null }; }
  });

export const saveFinanceState = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => financeStateSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: saved, error } = await context.supabase.from("finance_states").upsert({
      user_id: context.userId,
      state: data,
    }).select("updated_at").single();
    if (error) throw new Error("Não foi possível sincronizar seus dados.");
    return { ok: true, updatedAt: saved.updated_at };
  });

export const patchFinanceState = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => financeStatePatchSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: saved, error } = await context.supabase.rpc("patch_finance_state", {
      _patch: data,
    }).single();
    if (error) throw new Error("Não foi possível sincronizar esta alteração.");
    const parsed = financeStateSchema.safeParse(saved.state);
    if (!parsed.success) throw new Error("Os dados sincronizados são inválidos.");
    return { state: parsed.data, updatedAt: saved.updated_at };
  });

export const mutateFinanceCard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ card: financeCardSchema.extend({ desiredBalances: z.object({ creditLimit: z.number().finite().min(0).max(1_000_000_000_000), debitBalance: z.number().finite().min(0).max(1_000_000_000_000) }).optional() }), delete: z.boolean().default(false) }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: saved, error } = await context.supabase.rpc("mutate_finance_card", {
      _card: data.card,
      _delete: data.delete,
    }).single();
    if (error) throw new Error("Não foi possível sincronizar o cartão.");
    const parsed = financeStateSchema.safeParse(saved.state);
    if (!parsed.success) throw new Error("Os cartões sincronizados são inválidos.");
    return { banks: parsed.data.banks, updatedAt: saved.updated_at };
  });

export const mutateFixedExpense = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({
    expense: fixedExpenseSchema,
    action: z.enum(["upsert", "delete", "pay"]),
    month: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/).optional(),
    payment: z.object({
      cardId: z.number().int().positive(),
      cardName: z.string().trim().min(1).max(80),
      accountType: z.enum(["Crédito", "Débito", "Pix"]),
      method: z.enum(["Pix"]).optional(),
    }).optional(),
  }).parse(input))
  .handler(async ({ data, context }) => {
    const args = {
      _expense: data.payment ? {
        ...data.expense,
        paymentCardId: data.payment.cardId,
        paymentCardName: data.payment.cardName,
        paymentAccountType: data.payment.accountType === "Pix" ? "Débito" : data.payment.accountType,
        ...(data.payment.accountType === "Pix" || data.payment.method === "Pix" ? { paymentMethod: "Pix" } : {}),
      } : data.expense,
      _action: data.action,
      ...(data.month ? { _month: data.month } : {}),
    };
    const { data: saved, error } = await context.supabase.rpc("mutate_fixed_expense", args).single();
    if (error?.message.includes("INSUFFICIENT_CARD_BALANCE")) throw new Error("INSUFFICIENT_CARD_BALANCE");
    if (error) throw new Error("Não foi possível sincronizar a despesa fixa.");
    const parsed = financeStateSchema.safeParse(saved.state);
    if (!parsed.success) throw new Error("As despesas sincronizadas são inválidas.");
    return { fixedExpenses: parsed.data.fixedExpenses, records: parsed.data.records, balance: parsed.data.balance, updatedAt: saved.updated_at };
  });

export const mutateFinanceRecord = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({
    record: financeStateSchema.shape.records.element,
    action: z.enum(["upsert", "delete"]),
  }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: saved, error } = await context.supabase.rpc("mutate_finance_record", {
      _record: data.record,
      _action: data.action,
    }).single();
    if (error?.message.includes("INSUFFICIENT_CARD_BALANCE")) throw new Error("INSUFFICIENT_CARD_BALANCE");
    if (error?.message.includes("CARD_REQUIRED")) throw new Error("CARD_REQUIRED");
    if (error) throw new Error("Não foi possível sincronizar o lançamento.");
    const parsed = financeStateSchema.safeParse(saved.state);
    if (!parsed.success) throw new Error("Os lançamentos sincronizados são inválidos.");
    return { records: parsed.data.records, balance: parsed.data.balance, updatedAt: saved.updated_at };
  });

export const mutateForeignExpense = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({
    expense: foreignExpenseSchema,
    action: z.enum(["upsert", "delete", "pay"]),
    brlAmount: z.number().finite().min(0).max(1_000_000_000_000).optional(),
  }).parse(input))
  .handler(async ({ data, context }) => {
    const args = {
      _expense: data.expense,
      _action: data.action,
      ...(data.brlAmount !== undefined ? { _brl_amount: data.brlAmount } : {}),
    };
    const { data: saved, error } = await context.supabase.rpc("mutate_foreign_expense", args).single();
    if (error) throw new Error("Não foi possível sincronizar a despesa do exterior.");
    const parsed = financeStateSchema.safeParse(saved.state);
    if (!parsed.success) throw new Error("As despesas do exterior sincronizadas são inválidas.");
    return { foreignExpenses: parsed.data.foreignExpenses, currencyAssets: parsed.data.currencyAssets, updatedAt: saved.updated_at };
  });
