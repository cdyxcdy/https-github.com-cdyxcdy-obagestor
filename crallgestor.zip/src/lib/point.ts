// Browser-safe punch-clock helpers: kinds, ordering and formatting for the Crall Point screen.

export type PunchKind = "entrada" | "intervalo" | "retorno" | "saida";

export const punchKinds: { key: PunchKind; label: string }[] = [
  { key: "entrada", label: "Entrada" },
  { key: "intervalo", label: "Intervalo" },
  { key: "retorno", label: "Retorno" },
  { key: "saida", label: "Saída" },
];

/** True only for a punch kind the system knows. */
export function isPunchKind(value: string): value is PunchKind {
  return punchKinds.some(k => k.key === value);
}

/** Kind as shown on screen; unknown kinds read as a plain "Batida". */
export function punchLabel(value: string): string {
  return punchKinds.find(k => k.key === value)?.label ?? "Batida";
}

/** Punch time as shown on screen: 08:12. */
export function formatPunchTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "--:--";
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

function dayKey(year: number, month: number, day: number) {
  return `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

/** Day the punch belongs to in the viewer's own calendar: 2026-10-13. */
export function punchDayKey(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return dayKey(d.getFullYear(), d.getMonth(), d.getDate());
}

/** Heading for a day: Hoje, Ontem, or the weekday with the date. */
export function punchDayLabel(key: string, now = new Date()): string {
  if (!key) return "Sem data";
  const today = dayKey(now.getFullYear(), now.getMonth(), now.getDate());
  const back = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  const yesterday = dayKey(back.getFullYear(), back.getMonth(), back.getDate());
  if (key === today) return "Hoje";
  if (key === yesterday) return "Ontem";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return "Sem data";
  const [year = 1970, month = 1, day = 1] = key.split("-").map(n => Number.parseInt(n, 10));
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "2-digit" });
}

export type PunchLike = { punched_at: string };

/** Punches grouped by day, newest day first, newest punch first inside each day. */
export function groupPunchesByDay<T extends PunchLike>(rows: T[], now = new Date()): { key: string; label: string; items: T[] }[] {
  const buckets = new Map<string, T[]>();
  for (const row of rows) {
    const key = punchDayKey(row.punched_at);
    const bucket = buckets.get(key);
    if (bucket) bucket.push(row); else buckets.set(key, [row]);
  }
  return [...buckets.entries()]
    .sort((a, b) => b[0].localeCompare(a[0]))
    .map(([key, items]) => ({
      key,
      label: punchDayLabel(key, now),
      items: [...items].sort((a, b) => b.punched_at.localeCompare(a.punched_at)),
    }));
}

/** How many punches belong to a day, used as the day's short summary. */
export function countPunchesOfDay<T extends PunchLike>(rows: T[], now = new Date()): number {
  const today = punchDayKey(now.toISOString());
  return rows.filter(r => punchDayKey(r.punched_at) === today).length;
}
