import type { NotificationSettings } from './notification-settings';

export const RECEIPT_ROTATION_MS = 4000;
export const NOTIFICATION_ROTATION_MS = 4000;

type ReceiptRecord = { id: number; type: string; paymentMethod?: string; amount: number; title: string };
export function receivedTransfers<T extends ReceiptRecord>(records: T[]): T[] {
  return records.filter(record => record.type === 'receita' && (record.paymentMethod === 'Pix' || record.paymentMethod === 'Transferência'));
}

const notificationKinds: Record<string, keyof NotificationSettings> = {
  'Compromisso amanhã': 'agendaDue', 'Vencimento da fatura': 'cardDue',
  'Despesa fixa pendente': 'fixedDue', 'Conta a pagar': 'accountsPayDue',
  'Manutenção do veículo': 'maintenanceDue', 'Vencimento da CNH': 'licenseDue',
  'Novo cliente aguardando liberação': 'clientsPending', 'Total em conta': 'dailyBalance',
  'Cartão removido': 'cardMovements', 'Cartão atualizado': 'cardMovements',
  'Movimentação no cartão': 'cardMovements', 'Receita adicionada': 'incomeMessages',
  'Gasto adicionado': 'expenseMessages', 'Lançamento excluído': 'expenseMessages',
  'Despesa fixa paga': 'fixedExpensePayments', 'Despesa do exterior paga': 'foreignExpensePayments',
  'Conta paga': 'taskSettlements', 'Conta recebida': 'taskSettlements', 'Conta reaberta': 'taskSettlements',
};
export function notificationVisible(title: string, settings: NotificationSettings): boolean {
  const kind = notificationKinds[title];
  return kind ? settings[kind] === true : false;
}