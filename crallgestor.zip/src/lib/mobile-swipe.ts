export const mobileSections = ['home', 'records'] as const;

export function swipeSection(current: string, dx: number, dy: number, width: number) {
  if (width >= 768 || Math.abs(dx) < 64 || Math.abs(dx) < Math.abs(dy) * 1.8) return undefined;
  const index = mobileSections.findIndex(section => section === current);
  if (index < 0) return undefined;
  return mobileSections[index + (dx < 0 ? 1 : -1)];
}
