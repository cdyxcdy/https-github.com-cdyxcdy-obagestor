import { useEffect, useState } from "react";

export type InboxItem = { id: string; title: string; body: string; at: number; read: boolean };

const listeners = new Set<() => void>();
const emit = () => listeners.forEach(listener => listener());
const keyOf = (userId: string) => `app-inbox-${userId}`;

export const readInbox = (userId: string): InboxItem[] => {
  try {
    const raw = JSON.parse(localStorage.getItem(keyOf(userId)) ?? "[]") as unknown;
    return Array.isArray(raw) ? (raw as InboxItem[]).filter(item => typeof item?.id === "string" && typeof item?.title === "string") : [];
  } catch { return []; }
};

const writeInbox = (userId: string, items: InboxItem[]) => {
  localStorage.setItem(keyOf(userId), JSON.stringify(items.slice(0, 50)));
  emit();
};

export const pushInbox = (userId: string, title: string, body: string) => {
  const items = readInbox(userId);
  items.unshift({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, title, body, at: Date.now(), read: false });
  writeInbox(userId, items);
};

export const markAllRead = (userId: string) => {
  writeInbox(userId, readInbox(userId).map(item => ({ ...item, read: true })));
};

export const deleteInboxItem = (userId: string, id: string) => {
  writeInbox(userId, readInbox(userId).filter(item => item.id !== id));
};

export const deleteAllInboxItems = (userId: string) => {
  writeInbox(userId, []);
};

export const useInbox = (userId: string) => {
  const [items, setItems] = useState<InboxItem[]>(() => readInbox(userId));
  useEffect(() => {
    const sync = () => setItems(readInbox(userId));
    sync();
    listeners.add(sync);
    window.addEventListener("storage", sync);
    return () => { listeners.delete(sync); window.removeEventListener("storage", sync); };
  }, [userId]);
  return items;
};
