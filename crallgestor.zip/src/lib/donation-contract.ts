// Browser-safe donation contract helpers: data shape, validation and a tiny one-page PDF builder.
export type Donee = { id: string; name: string; document: string; amount: number; date: string; status: "Pendente" | "Assinado" | "Arquivado" };

export const REQUIRED_DOCUMENTS = [
  "RG ou CNH do donatário",
  "CPF do donatário",
  "Comprovante de residência atualizado",
  "Termo de doação assinado",
  "Comprovante do Pix / transferência",
] as const;

export function isValidDonee(d: Partial<Donee>): d is Donee {
  return !!d.name?.trim() && typeof d.amount === "number" && Number.isFinite(d.amount) && d.amount > 0 && /^\d{4}-\d{2}-\d{2}$/.test(d.date ?? "");
}

export function contractText(d: Donee, donor: string): string[] {
  const value = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(d.amount);
  return [
    "CONTRATO DE DOACAO",
    "",
    `Doador: ${donor}`,
    `Donatario: ${d.name}`,
    `Documento: ${d.document || "-"}`,
    `Valor doado: ${value}`,
    `Data: ${d.date.split("-").reverse().join("/")}`,
    "",
    "O doador transfere ao donatario, por livre e espontanea vontade,",
    "o valor acima descrito, sem qualquer contrapartida.",
    "",
    "",
    "______________________________          ______________________________",
    "           Doador                                   Donatario",
  ];
}

const latin = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[()\\]/g, m => `\\${m}`);

/** Builds a minimal one-page A4 PDF with Helvetica text lines. */
export function buildContractPdf(lines: string[]): Blob {
  const body = ["BT", "/F1 12 Tf", "16 TL", "60 780 Td", ...lines.map((l, i) => `${i === 0 ? "/F1 16 Tf " : i === 1 ? "/F1 12 Tf " : ""}(${latin(l)}) Tj T*`), "ET"].join("\n");
  const objs = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
    `<< /Length ${body.length} >>\nstream\n${body}\nendstream`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  ];
  let out = "%PDF-1.4\n"; const offsets: number[] = [];
  objs.forEach((o, i) => { offsets.push(out.length); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n${offsets.map(n => `${String(n).padStart(10, "0")} 00000 n \n`).join("")}`;
  out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new Blob([out], { type: "application/pdf" });
}
