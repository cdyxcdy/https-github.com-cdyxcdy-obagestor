/** Parses a spoken phrase ("gastei 50 reais no mercado") into a record draft. Browser-safe, no state changes. */
export type VoiceDraft = { title: string; amount: number; type: "receita" | "gasto" };

const NUMBER = /(\d{1,3}(?:\.\d{3})+|\d+)(?:[,](\d{1,2}))?/;

export function parseVoiceRecord(text: string): VoiceDraft | null {
  const spoken = text.trim().toLowerCase();
  const match = spoken.match(NUMBER);
  if (!match) return null;
  const amount = Number(match[1]!.replace(/\./g, "")) + (match[2] ? Number(match[2].padEnd(2, "0")) / 100 : 0);
  if (!(amount > 0)) return null;
  const type = /\b(recebi|receita|ganhei|entrada|entrou|pix recebido)\b/.test(spoken) ? "receita" : "gasto";
  const rest = spoken.slice((match.index ?? 0) + match[0].length)
    .replace(/^\s*(reais|real|r\$)\b/, "")
    .replace(/^\s*(com|no|na|em|de|do|da|para|pra)\s+/, "")
    .trim();
  const title = rest ? rest.charAt(0).toUpperCase() + rest.slice(1, 100) : type === "receita" ? "Receita por voz" : "Gasto por voz";
  return { title, amount, type };
}
