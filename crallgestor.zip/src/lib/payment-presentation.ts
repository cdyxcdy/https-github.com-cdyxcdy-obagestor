export const financialPaymentMethods = ["Cartão crédito", "Cartão débito", "Transferência", "Empréstimo", "Doação", "Nenhum"];
export const fixedPaymentModes = ["Débito", "Crédito"];

// Legacy methods remain stored unchanged so hiding an option never changes balances.
export function paymentLabel(method?: string) {
  return method === "Pix" ? "Transferência" : method;
}

export function submittedPaymentMethod(selected: string, previous?: string) {
  return previous === "Pix" && selected === paymentLabel(previous) ? previous : selected;
}

export function financialMessage(text: string) {
  return text.replace(/\bpix\b/gi, "transferência");
}