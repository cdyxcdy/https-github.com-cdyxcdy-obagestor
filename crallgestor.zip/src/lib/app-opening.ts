/** One guard per loaded app: internal navigation and native Back remain intact. */
export function createAppOpeningGuard() {
  let opened = false;
  return (cause: string, tab: string | undefined): boolean => {
    if (cause === 'preload' || opened) return false;
    opened = true;
    return tab !== undefined && tab !== 'home';
  };
}