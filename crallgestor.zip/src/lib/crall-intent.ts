// Browser-safe intent detection for the CRALL assistant: images and the visual panel open only on explicit request.
const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

export function wantsImage(text: string) {
  return /\b(gere|gerar|crie|criar|faca|fazer|desenhe|formule)\b.*\b(imagem|foto|banner|arte|logo|ilustracao)\b/.test(norm(text));
}
export function wantsPanel(text: string) {
  return /\b(mostre|mostrar|mostra|me mostra|exiba|exibir|abra|abrir|abre|compare|comparar|comparacao|na tela)\b/.test(norm(text));
}

export const SCREENS = [
  { tab: "fixedExpenses", label: "Despesas fixas", re: /despesas? fixas?|contas? fixas?/ },
  { tab: "cards", label: "Cartões", re: /cart(ao|oes)/ },
  { tab: "records", label: "Receitas e gastos", re: /receitas?|gastos?|lancamentos?/ },
  { tab: "tasks", label: "Minhas Tarefas", re: /tarefas?|frota/ },
  { tab: "home", label: "Início", re: /\binicio\b|tela inicial/ },
] as const;
export type ScreenTab = (typeof SCREENS)[number]["tab"];

/** App screens named in a request, in the order spoken, at most two. */
export function requestedScreens(text: string): ScreenTab[] {
  let t = norm(text);
  const found: { tab: ScreenTab; at: number }[] = [];
  for (const s of SCREENS) {
    const m = t.match(s.re);
    if (m && m.index !== undefined) { found.push({ tab: s.tab, at: m.index }); t = t.replace(s.re, " ".repeat(m[0].length)); }
  }
  return found.sort((a, b) => a.at - b.at).slice(0, 2).map(f => f.tab);
}

/** Splits a markdown answer into two columns when it has exactly two "## " sections. */
export function splitComparison(md: string): [string, string] | null {
  const parts = md.split(/\n(?=## )/).filter(p => p.trim().startsWith("## "));
  return parts.length === 2 ? [parts[0]!, parts[1]!] : null;
}
