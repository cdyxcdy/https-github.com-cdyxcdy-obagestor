import { paymentLabel } from "./payment-presentation";
import { cardThumbnail } from "./card-thumbnails";

type ReportRecord = {
  title: string;
  category: string;
  amount: number;
  type: "receita" | "gasto";
  date: string;
  paymentMethod?: string;
  cardName?: string;
};

type ReportCategory = [string, number];

type ReportForeignExpense = {
  name: string;
  amount: number;
  currency: "USD" | "EUR";
  date: string;
  paid: boolean;
};

type DownloadReportInput = {
  records: ReportRecord[];
  categories: ReportCategory[];
  income: number;
  expenses: number;
  periodLabel: string;
  periodKey: string;
  currency: "BRL" | "USD" | "EUR";
  foreignExpenses: ReportForeignExpense[];
  expensesByCurrency: {
    BRL: number;
    USD: number;
    EUR: number;
  };
  dashboard: {
    balance: number;
    totalInvested: number;
    totalYield: number;
    usdInvested: number;
    eurInvested: number;
    cardUsage: Array<{ name: string; count: number; amount: number }>;
    investmentYields: Array<{ name: string; yield: number }>;
  };
};

const cleanText = (value: string) => value
  .normalize("NFC")
  .replace(/[–—]/g, "-")
  .replace(/\u00a0/g, " ");

const formatMoney = (value: number, currency: DownloadReportInput["currency"]) => cleanText(
  new Intl.NumberFormat("pt-BR", { style: "currency", currency }).format(value),
);

const formatDate = (value: string) => {
  const [year, month, day] = value.split("-");
  return day && month && year ? `${day}/${month}/${year}` : value;
};

export async function createFinanceReport(input: DownloadReportInput) {
  const { PDFDocument, StandardFonts, rgb } = await import("pdf-lib");
  const pdf = await PDFDocument.create();
  pdf.setTitle(`Oba Financeiro | Relatório financeiro | ${input.periodLabel}`);
  pdf.setAuthor("Oba Financeiro");
  pdf.setSubject("Resumo financeiro, impostos e lançamentos separados por moeda");
  pdf.setLanguage("pt-BR");
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const width = 595.28, height = 841.89, margin = 44, bottom = 60;
  const contentWidth = width - margin * 2;
  // Print-specific semantic palette: white paper, ocean accent and coral expenses.
  const colors = {
    ink: rgb(0.10, 0.16, 0.19), muted: rgb(0.36, 0.42, 0.45),
    line: rgb(0.84, 0.89, 0.90), paper: rgb(1, 1, 1),
    ocean: rgb(0.02, 0.39, 0.45), oceanSoft: rgb(0.92, 0.97, 0.98),
    coral: rgb(0.72, 0.23, 0.21), coralSoft: rgb(0.99, 0.94, 0.93),
    neutral: rgb(0.96, 0.97, 0.98),
  };
  const safeText = (value: string) => Array.from(cleanText(value)).map(char => {
    try { regular.encodeText(char); return char; } catch { return "?"; }
  }).join("");
  let page = pdf.addPage([width, height]);
  let y = height - margin;
  const text = (value: string, x: number, baseline: number, size = 10, strong = false, color = colors.ink) => {
    page.drawText(safeText(value), { x, y: baseline, size, font: strong ? bold : regular, color });
  };
  const fitSize = (value: string, available: number, size: number, strong = false) => {
    const font = strong ? bold : regular;
    return Math.min(size, size * available / Math.max(1, font.widthOfTextAtSize(safeText(value), size)));
  };
  const right = (value: string, baseline: number, size = 10, color = colors.ink, available = 155) => {
    const fitted = fitSize(value, available, size, true);
    text(value, width - margin - bold.widthOfTextAtSize(safeText(value), fitted), baseline, fitted, true, color);
  };
  const rule = (baseline: number) => page.drawLine({ start: { x: margin, y: baseline }, end: { x: width - margin, y: baseline }, thickness: 0.6, color: colors.line });
  const newPage = () => {
    page = pdf.addPage([width, height]);
    text("Oba Financeiro", margin, height - margin, 10, true, colors.ocean);
    right(input.periodLabel, height - margin, 9, colors.muted, 300);
    rule(height - margin - 14);
    y = height - margin - 42;
  };
  const ensure = (space: number) => { if (y - space < bottom) newPage(); };
  const section = (number: string, title: string, space = 80) => {
    ensure(space);
    text(number, margin, y, 10, true, colors.ocean);
    text(title, margin + 26, y - 1, 15, true);
    y -= 14; rule(y); y -= 24;
  };
  const wrap = (value: string, available: number, size = 9, strong = false) => {
    const font = strong ? bold : regular;
    const lines: string[] = [];
    let line = "";
    for (const word of safeText(value).split(/\s+/)) {
      const candidate = line ? `${line} ${word}` : word;
      if (font.widthOfTextAtSize(candidate, size) <= available) { line = candidate; continue; }
      if (line) lines.push(line);
      line = "";
      for (const char of word) {
        if (font.widthOfTextAtSize(line + char, size) > available && line) { lines.push(line); line = ""; }
        line += char;
      }
    }
    if (line) lines.push(line);
    return lines.length ? lines : [""];
  };
  const metric = (x: number, label: string, value: string, fill: typeof colors.ink, accent: typeof colors.ink) => {
    const boxWidth = (contentWidth - 20) / 3;
    page.drawRectangle({ x, y: y - 76, width: boxWidth, height: 76, color: fill });
    page.drawRectangle({ x, y: y - 76, width: 3, height: 76, color: accent });
    text(label, x + 13, y - 22, 9, false, colors.muted);
    text(value, x + 13, y - 52, fitSize(value, boxWidth - 26, 18, true), true, accent);
  };
  const summaryRow = (label: string, value: string, color = colors.ink) => {
    const lines = wrap(label, contentWidth - 170, 10);
    const rowHeight = Math.max(29, lines.length * 13 + 12);
    ensure(rowHeight);
    lines.forEach((line, i) => text(line, margin, y - i * 13, 10));
    right(value, y, 10, color);
    y -= rowHeight - 8; rule(y); y -= 8;
  };
  const isTax = (category: string) => category.trim().toLocaleLowerCase("pt-BR") === "impostos";
  const taxRecords = input.records.filter(record => record.type === "gasto" && isTax(record.category));
  const taxTotal = taxRecords.reduce((sum, record) => sum + record.amount, 0);
  const nonTaxCategories = input.categories.filter(([category]) => !isTax(category));

  page.drawRectangle({ x: 0, y: height - 7, width, height: 7, color: colors.ocean });
  text("Oba Financeiro", margin, y - 5, 11, true, colors.ocean);
  text("RELATÓRIO GERAL", margin, y - 30, 9, false, colors.muted);
  text("Relatório financeiro", margin, y - 64, 28, true);
  const periodLines = wrap(input.periodLabel, contentWidth, 11);
  periodLines.forEach((line, i) => text(line, margin, y - 88 - i * 14, 11, false, colors.muted));
  y -= 117 + (periodLines.length - 1) * 14;
  const metricWidth = (contentWidth - 20) / 3;
  metric(margin, "Receitas em Real", formatMoney(input.income, "BRL"), colors.oceanSoft, colors.ocean);
  metric(margin + metricWidth + 10, "Gastos em Real", formatMoney(input.expenses, "BRL"), colors.coralSoft, colors.coral);
  metric(margin + (metricWidth + 10) * 2, "Resultado em Real", formatMoney(input.income - input.expenses, "BRL"), colors.neutral, colors.ink);
  y -= 106;
  section("01", "Gastos por moeda");
  (["BRL"] as const).forEach(currency => {
    summaryRow(currency === "BRL" ? "Real · BRL" : currency === "USD" ? "Dólar · USD" : "Euro · EUR", formatMoney(input.expensesByCurrency[currency], currency), colors.coral);
  });
  text("Valores em Real.", margin, y - 1, 9, false, colors.muted);
  y -= 31;
  section("02", "Impostos do período", 115);
  summaryRow(`Impostos em Real · ${taxRecords.length} lançamento${taxRecords.length === 1 ? "" : "s"}`, formatMoney(taxTotal, "BRL"), colors.coral);
  text("Já incluídos nos gastos em Real; não são somados novamente.", margin, y, 9, false, colors.muted);
  y -= 28;
  section("03", "Demais gastos por categoria");
  if (nonTaxCategories.length) nonTaxCategories.forEach(([name, value]) => summaryRow(name, formatMoney(value, "BRL")));
  else { text("Nenhum outro gasto no período.", margin, y, 10, false, colors.muted); y -= 26; }

  newPage();
  section("04", "Posição financeira atual");
  text("Saldos atuais; os lançamentos abaixo seguem o período selecionado.", margin, y, 9, false, colors.muted);
  y -= 27;
  [
    ["Total em conta", input.dashboard.balance], ["Total investido", input.dashboard.totalInvested],
    ["Rendimento mensal", input.dashboard.totalYield],
  ].forEach(([label, value]) => summaryRow(String(label), formatMoney(Number(value), "BRL")));
  y -= 14;
  section("05", "Cartões usados no período");
  if (input.dashboard.cardUsage.length) input.dashboard.cardUsage.forEach(card => summaryRow(`${card.name} · ${card.count} uso${card.count === 1 ? "" : "s"}`, formatMoney(card.amount, "BRL")));
  else { text("Nenhum cartão identificado no período.", margin, y, 10, false, colors.muted); y -= 28; }
  y -= 14;
  section("", "Formas de pagamento no período");
  for (const method of ["Cartão débito", "Cartão crédito", "Transferência"]) summaryRow(method, formatMoney(input.records.filter(r => r.type === "gasto" && paymentLabel(r.paymentMethod) === method).reduce((sum, r) => sum + r.amount, 0), "BRL"));
  section("06", "Rendimentos dos investimentos");
  if (input.dashboard.investmentYields.length) input.dashboard.investmentYields.forEach(item => summaryRow(item.name, formatMoney(item.yield, "BRL"), colors.ocean));
  else { text("Nenhum investimento cadastrado.", margin, y, 10, false, colors.muted); y -= 28; }

  type TableRow = { date: string; title: string; detail: string; amount: number; income?: boolean; thumb?: string };
  const thumbCache = new Map<string, Awaited<ReturnType<typeof pdf.embedPng>>>();
  const loadThumb = async (cardName: string) => {
    if (thumbCache.has(cardName)) return;
    const found = cardThumbnail(cardName);
    if (!found) return;
    try {
      const response = await fetch(found.image);
      const bytes = await response.arrayBuffer();
      thumbCache.set(cardName, await pdf.embedPng(bytes));
    } catch { /* miniatura indisponível: segue sem imagem */ }
  };
  await Promise.all(input.records.filter(record => record.type === "gasto" && record.cardName).map(record => loadThumb(record.cardName as string)));
  const table = (title: string, rows: TableRow[], currency: DownloadReportInput["currency"]) => {
    const heading = (continued = false) => {
      const titleLines = wrap(`${title}${continued ? " (continuação)" : ""}`, contentWidth, 12, true);
      ensure(titleLines.length * 15 + 100);
      titleLines.forEach(line => { text(line, margin, y, 12, true, colors.ocean); y -= 15; });
      y -= 7;
      page.drawRectangle({ x: margin, y: y - 26, width: contentWidth, height: 26, color: colors.oceanSoft });
      text("DATA", margin + 8, y - 17, 8, true, colors.ocean);
      text("DESCRIÇÃO", margin + 69, y - 17, 8, true, colors.ocean);
      text("PAGAMENTO / STATUS", margin + 258, y - 17, 8, true, colors.ocean);
      text("VALOR", width - margin - 40, y - 17, 8, true, colors.ocean);
      y -= 42;
    };
    heading();
    rows.slice().sort((a, b) => b.date.localeCompare(a.date)).forEach((row, index) => {
      const titleLines = wrap(row.title, 174, 9, true), detailLines = wrap(row.detail, 118, 8);
      const rowHeight = Math.max(31, Math.max(titleLines.length, detailLines.length) * 12 + 16);
      if (y - rowHeight < bottom) { newPage(); heading(true); }
      if (index % 2 === 0) page.drawRectangle({ x: margin, y: y - rowHeight + 12, width: contentWidth, height: rowHeight, color: colors.neutral });
      text(formatDate(row.date), margin + 8, y, 8, false, colors.muted);
      const thumb = row.thumb ? thumbCache.get(row.thumb) : undefined;
      if (thumb) page.drawImage(thumb, { x: margin + 43, y: y - 7, width: 24, height: 15 });
      titleLines.forEach((line, i) => text(line, margin + 69, y - i * 12, 9, true));
      detailLines.forEach((line, i) => text(line, margin + 258, y - i * 12, 8, false, colors.muted));
      const amount = `${row.income ? "+" : "-"} ${formatMoney(row.amount, currency)}`;
      const size = fitSize(amount, 108, 9, true);
      text(amount, width - margin - 8 - bold.widthOfTextAtSize(safeText(amount), size), y, size, true, row.income ? colors.ocean : colors.coral);
      y -= rowHeight;
    });
    if (!rows.length) { text("Nenhum lançamento de impostos no período.", margin + 8, y, 10, false, colors.muted); y -= 28; }
    ensure(35);
    summaryRow("Subtotal", formatMoney(rows.reduce((sum, row) => sum + row.amount, 0), currency), colors.ocean);
    y -= 21;
  };
  const recordRow = (record: ReportRecord): TableRow => ({
    date: record.date, title: record.title, amount: record.amount, income: record.type === "receita",
    detail: record.cardName ? `${paymentLabel(record.paymentMethod) ?? "Cartão"} · ${record.cardName}` : paymentLabel(record.paymentMethod) ?? "Dinheiro",
    ...(record.type === "gasto" && record.cardName ? { thumb: record.cardName } : {}),
  });
  newPage();
  section("07", "Detalhamento de impostos");
  table("Impostos · Real", taxRecords.map(recordRow), "BRL");
  section("08", "Demais lançamentos");
  const incomes = input.records.filter(record => record.type === "receita");
  if (incomes.length) table("Receitas · Real", incomes.map(recordRow), "BRL");
  const groups = input.records.filter(record => record.type === "gasto" && !isTax(record.category)).reduce<Record<string, ReportRecord[]>>((result, record) => {
    (result[record.category] ??= []).push(record); return result;
  }, {});
  Object.entries(groups).sort(([a], [b]) => a.localeCompare(b, "pt-BR")).forEach(([category, records]) => table(`${category} · Real`, records.map(recordRow), "BRL"));
  (["USD", "EUR"] as const).forEach(currency => {
    const expenses = input.foreignExpenses.filter(expense => expense.currency === currency);
    if (expenses.length) table(`Despesas do exterior · ${currency === "USD" ? "Dólar" : "Euro"}`, expenses.map(expense => ({ date: expense.date, title: expense.name, detail: expense.paid ? "Pago" : "Pendente", amount: expense.amount })), currency);
  });
  if (!input.records.length && !input.foreignExpenses.length) { ensure(30); text("Nenhum lançamento no período selecionado.", margin, y, 10, false, colors.muted); }
  const pages = pdf.getPages();
  pages.forEach((current, index) => {
    current.drawLine({ start: { x: margin, y: 42 }, end: { x: width - margin, y: 42 }, thickness: 0.6, color: colors.line });
    current.drawText("Oba Financeiro · Relatório privado", { x: margin, y: 27, size: 8, font: regular, color: colors.muted });
    const footer = `Página ${index + 1} de ${pages.length}`;
    current.drawText(footer, { x: width - margin - regular.widthOfTextAtSize(footer, 8), y: 27, size: 8, font: regular, color: colors.muted });
  });
  return pdf.save();
}

export async function downloadFinanceReport(input: DownloadReportInput, mode: "download" | "email" = "download") {
  const bytes = await createFinanceReport(input);
  const blob = new Blob([new Uint8Array(bytes)], { type: "application/pdf" });
  const fileName = `relatorio-financeiro-${input.periodKey}.pdf`;
  if (mode === "email") {
    const file = new File([blob], fileName, { type: "application/pdf" });
    const subject = `Relatório financeiro - ${input.periodLabel}`;
    const body = `Relatório financeiro (${input.periodLabel})\nReceitas: ${formatMoney(input.income, "BRL")}\nGastos: ${formatMoney(input.expenses, "BRL")}\nResultado: ${formatMoney(input.income - input.expenses, "BRL")}`;
    const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
    if (nav.share && nav.canShare?.({ files: [file] })) {
      try { await nav.share({ files: [file], title: subject, text: body }); } catch { /* cancelado */ }
      return;
    }
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    return;
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
