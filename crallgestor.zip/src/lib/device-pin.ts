export const PIN_LENGTH = 4;
export const MAX_PIN_ATTEMPTS = 5;
export const PIN_COOLDOWN_MS = 60_000;
export const PIN_ITERATIONS = 600_000;
export interface DevicePin { salt: string; hash: string; failures: number; blockedUntil: number }
export function validPin(pin: string): boolean { return /^\d{4}$/.test(pin); }
export function pinStorageKey(userId: string): string { return `crall-device-pin-v1:${userId}`; }
function hex(bytes: Uint8Array): string { return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join(""); }
async function derive(pin: string, salt: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: new TextEncoder().encode(salt), iterations: PIN_ITERATIONS }, key, 256);
  return hex(new Uint8Array(bits));
}
export async function createDevicePin(pin: string): Promise<DevicePin> {
  if (!validPin(pin)) throw new Error("Digite quatro números.");
  const salt = hex(crypto.getRandomValues(new Uint8Array(32)));
  return { salt, hash: await derive(pin, salt), failures: 0, blockedUntil: 0 };
}
export async function matchesDevicePin(pin: string, record: DevicePin): Promise<boolean> {
  if (!validPin(pin)) return false;
  const actual = await derive(pin, record.salt);
  let difference = actual.length ^ record.hash.length;
  for (let i = 0; i < actual.length; i++) difference |= actual.charCodeAt(i) ^ record.hash.charCodeAt(i);
  return difference === 0;
}
export function failedPin(record: DevicePin, now: number): DevicePin {
  const failures = (record.blockedUntil && record.blockedUntil <= now ? 0 : record.failures) + 1;
  return { ...record, failures, blockedUntil: failures >= MAX_PIN_ATTEMPTS ? now + PIN_COOLDOWN_MS : 0 };
}
export function readDevicePin(userId: string): DevicePin | null {
  try {
    const value = JSON.parse(localStorage.getItem(pinStorageKey(userId)) || "null");
    if (value && /^[a-f0-9]{64}$/.test(value.salt) && /^[a-f0-9]{64}$/.test(value.hash) && Number.isFinite(value.failures) && Number.isFinite(value.blockedUntil)) return value;
  } catch { /* Treat unavailable or malformed storage as an unregistered device. */ }
  return null;
}