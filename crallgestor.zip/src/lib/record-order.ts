type ChronologicalRecord = { date: string; id: number; fixedExpenseId?: number; paidAt?: string };

export function recordDisplayDate(record: ChronologicalRecord): string {
  return record.fixedExpenseId && record.paidAt ? record.paidAt.slice(0, 10) : record.date;
}

export function newestRecordsFirst<T extends ChronologicalRecord>(records: readonly T[]): T[] {
  const legacyDays = new Set(records.filter(r => r.fixedExpenseId && !r.paidAt).map(recordDisplayDate));
  return records.map((record, index) => ({ record, index })).sort((a, b) => {
    const day = recordDisplayDate(a.record);
    const dayOrder = recordDisplayDate(b.record).localeCompare(day);
    if (dayOrder) return dayOrder;
    // Legacy fixed IDs are synthetic: use saved insertion order when no payment time exists.
    if (legacyDays.has(day)) return b.index - a.index;
    const time = (record: ChronologicalRecord) => record.fixedExpenseId && record.paidAt ? Date.parse(record.paidAt) : record.id;
    return time(b.record) - time(a.record) || b.index - a.index;
  }).map(({ record }) => record);
}