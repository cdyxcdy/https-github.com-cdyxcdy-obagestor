import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { licenseAccess } from './license-access';

export const getMyLicense = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const [licenseResult, adminResult, anyAdminResult] = await Promise.all([
      context.supabase.from("app_licenses").select("user_id, suspended_at, expires_at, access_kind, trial_started_at").eq("user_id", context.userId).maybeSingle(),
      context.supabase.from("app_admins").select("user_id").eq("user_id", context.userId).maybeSingle(),
      context.supabase.from("app_admins").select("user_id").limit(1).maybeSingle(),
    ]);
    if (licenseResult.error || adminResult.error || anyAdminResult.error) throw new Error('Não foi possível verificar o acesso.');
    const isAdmin = Boolean(adminResult.data);
    const email = String((context.claims as { email?: string })?.email ?? "").toLowerCase();
    const isOwner = email === "cdyxcdy@gmail.com";
    // adminsExist=true hides the owner button for everyone except the owner email.
    return { ...licenseAccess(licenseResult.data, isAdmin), serverNow: Date.now(), isAdmin, adminsExist: Boolean(anyAdminResult.data) || isAdmin || !isOwner };
  });

export const bootstrapAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.rpc("bootstrap_admin");
    if (error) throw new Error("Não foi possível configurar o administrador.");
    return { isAdmin: Boolean(data) };
  });

export const listUsersForLicense = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await context.supabase.rpc("is_admin");
    if (!isAdmin) throw new Error("Apenas o administrador pode ver as contas.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.auth.admin.listUsers({ perPage: 200 });
    if (error) throw new Error("Não foi possível listar as contas.");
    const [{ data: licenses, error: licenseError }, { data: admins, error: adminError }] = await Promise.all([
      context.supabase.from("app_licenses").select("user_id, suspended_at, expires_at, access_kind, trial_started_at"),
      context.supabase.from("app_admins").select("user_id"),
    ]);
    if (licenseError || adminError) throw new Error("Não foi possível consultar os acessos.");
    const licenseMap = new Map((licenses ?? []).map(row => [row.user_id, row]));
    const adminIds = new Set((admins ?? []).map(row => row.user_id));
    return data.users
      .map(user => {
        const license = licenseMap.get(user.id);
        const isAdmin = adminIds.has(user.id);
        return { id: user.id, email: user.email ?? "", createdAt: user.created_at, ...licenseAccess(license, isAdmin), isAdmin };
      })
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  });

export const setClientAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ userId: z.string().uuid(), active: z.boolean() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("set_client_access", { _user: data.userId, _active: data.active });
    if (error) throw new Error("Não foi possível alterar o acesso desta conta.");
    return { ok: true };
  });

export const grantLicense = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ userId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("grant_license", { _user: data.userId });
    if (error) throw new Error("Não foi possível liberar esta conta.");
    return { ok: true };
  });

export const deleteClient = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ userId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: isAdmin, error: roleError } = await context.supabase.rpc('is_admin');
    if (roleError || !isAdmin) throw new Error('Apenas o administrador pode excluir clientes.');
    const { data: adminRow, error: adminError } = await context.supabase.from('app_admins').select('user_id').eq('user_id', data.userId).maybeSingle();
    if (adminError || adminRow || data.userId === context.userId) throw new Error('Administrador protegido.');
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const { data: target, error: targetError } = await supabaseAdmin.auth.admin.getUserById(data.userId);
    if (targetError || target.user?.email?.toLowerCase() === 'cdyxcdy@gmail.com') throw new Error('Conta protegida ou não encontrada.');
    const bucket = supabaseAdmin.storage.from('vehicle-photos');
    const paths: string[] = [];
    const collect = async (prefix: string) => {
      for (let offset = 0; ; offset += 100) {
        const { data: items, error } = await bucket.list(prefix, { limit: 100, offset });
        if (error) throw new Error('Não foi possível consultar as fotos da conta.');
        for (const item of items ?? []) {
          const path = `${prefix}/${item.name}`;
          if (item.id) paths.push(path); else await collect(path);
        }
        if ((items?.length ?? 0) < 100) break;
      }
    };
    await collect(data.userId);
    for (let index = 0; index < paths.length; index += 100) {
      const { error } = await bucket.remove(paths.slice(index, index + 100));
      if (error) throw new Error('Não foi possível excluir as fotos da conta.');
    }
    const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
    if (deleteError) throw new Error('Não foi possível excluir a conta.');
    for (const table of ['finance_states', 'app_licenses'] as const) {
      const { error } = await supabaseAdmin.from(table).delete().eq('user_id', data.userId);
      if (error) throw new Error('Conta excluída; não foi possível remover todos os registros.');
    }
    return { ok: true };
  });

export const startAccountTrial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { error } = await context.supabase.rpc("start_account_trial");
    if (error) throw new Error("O teste não está disponível para esta conta. Cada conta pode testar uma única vez.");
    return { ok: true };
  });
