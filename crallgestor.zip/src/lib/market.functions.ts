import { createServerFn } from "@tanstack/react-start";

export type MarketQuote = { value: number | null; change: number | null };
export type MarketData = { ibov: MarketQuote; usd: MarketQuote; selic: number | null; updatedAt: string };

async function getJson(url: string): Promise<any> {
  const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0", Accept: "application/json" } });
  if (!res.ok) throw new Error(String(res.status));
  return res.json();
}

export const getMarketData = createServerFn({ method: "GET" }).handler(async (): Promise<MarketData> => {
  const [ibov, usd, selic] = await Promise.allSettled([
    getJson("https://query1.finance.yahoo.com/v8/finance/chart/%5EBVSP?interval=1d&range=5d"),
    getJson("https://economia.awesomeapi.com.br/json/last/USD-BRL"),
    getJson("https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1?formato=json"),
  ]);
  let ibovQ: MarketQuote = { value: null, change: null };
  if (ibov.status === "fulfilled") {
    const m = ibov.value?.chart?.result?.[0]?.meta;
    const price = Number(m?.regularMarketPrice);
    const prev = Number(m?.chartPreviousClose ?? m?.previousClose);
    if (Number.isFinite(price)) ibovQ = { value: price, change: Number.isFinite(prev) && prev ? ((price - prev) / prev) * 100 : null };
  }
  let usdQ: MarketQuote = { value: null, change: null };
  if (usd.status === "fulfilled") {
    const d = usd.value?.USDBRL;
    const bid = Number(d?.bid);
    if (Number.isFinite(bid)) usdQ = { value: bid, change: Number.isFinite(Number(d?.pctChange)) ? Number(d.pctChange) : null };
  }
  if (usdQ.value === null) {
    try {
      const m = (await getJson("https://query1.finance.yahoo.com/v8/finance/chart/BRL%3DX?interval=1d&range=5d"))?.chart?.result?.[0]?.meta;
      const price = Number(m?.regularMarketPrice); const prev = Number(m?.chartPreviousClose);
      if (Number.isFinite(price)) usdQ = { value: price, change: prev ? ((price - prev) / prev) * 100 : null };
    } catch { /* keep empty */ }
  }
  let selicV: number | null = null;
  if (selic.status === "fulfilled") {
    const v = Number(String(selic.value?.[0]?.valor ?? "").replace(",", "."));
    if (Number.isFinite(v)) selicV = v;
  }
  return { ibov: ibovQ, usd: usdQ, selic: selicV, updatedAt: new Date().toISOString() };
});
