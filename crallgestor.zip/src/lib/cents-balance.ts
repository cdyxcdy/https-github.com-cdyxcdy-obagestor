// Cents hidden by whole-real display: fractional part of each record, grouped by direction.
type Movement = { type: "receita" | "gasto"; amount: number };
const centsOf = (amount: number) => Math.round(amount * 100) % 100;
export function centsBalance(records: Movement[]) {
  const income = records.filter(r => r.type === "receita").reduce((s, r) => s + centsOf(r.amount), 0) / 100;
  const expense = records.filter(r => r.type === "gasto").reduce((s, r) => s + centsOf(r.amount), 0) / 100;
  return { income, expense, net: Math.round((income - expense) * 100) / 100 };
}
