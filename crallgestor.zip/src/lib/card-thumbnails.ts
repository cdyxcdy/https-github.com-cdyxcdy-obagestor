import santanderSxVisa from "@/assets/cards/santander-sx-visa.png";
import safraVisa from "@/assets/cards/safra-visa.png";
import picpayBlackMastercard from "@/assets/cards/picpay-black-mastercard.png";
import caixaElo from "@/assets/cards/caixa-elo.png";
import bancoDoBrasil from "@/assets/cards/bb-ouro.webp.asset.json";
import mercadoPago from "@/assets/cards/mercado-pago.png";
import c6Mastercard from "@/assets/cards/c6-mastercard.png";
import nubank from "@/assets/cards/nubank.jpg.asset.json";
import sicoob from "@/assets/cards/sicoob.jpg.asset.json";
import itau from "@/assets/cards/itau.png.asset.json";
import inter from "@/assets/cards/inter.png.asset.json";

const thumbnails: { match: RegExp; image: string; label: string }[] = [
  { match: /santander|\bsx\b/i, image: santanderSxVisa, label: "Santander SX Visa" },
  { match: /safra/i, image: safraVisa, label: "Banco Safra Visa" },
  { match: /pic\s?pay/i, image: picpayBlackMastercard, label: "PicPay Black Mastercard" },
  { match: /caixa/i, image: caixaElo, label: "Caixa Elo Mais" },
  { match: /mercado\s?pago/i, image: mercadoPago, label: "Mercado Pago" },
  { match: /\bc6\b/i, image: c6Mastercard, label: "C6 Bank Mastercard" },
  { match: /nu\s?bank|\bnu\b/i, image: nubank.url, label: "Nubank" },
  { match: /sic+o+b|socoob/i, image: sicoob.url, label: "Sicoob" },
  { match: /ita[uú]/i, image: itau.url, label: "Itaú" },
  { match: /\binter\b/i, image: inter.url, label: "Banco Inter" },
  { match: /brasil|\bbb\b/i, image: bancoDoBrasil.url, label: "Banco do Brasil" },
];

export function cardThumbnail(cardName: string | undefined | null): { image: string; label: string } | null {
  if (!cardName) return null;
  const found = thumbnails.find(entry => entry.match.test(cardName));
  return found ? { image: found.image, label: found.label } : null;
}
