import { z } from 'zod';
import { daysToCardDue } from './home-month';
import { type TasksState } from './tasks-schema';
import { type Appointment } from './agenda';

export const notificationSettingsSchema = z.object({
  yield: z.boolean().default(false), budget: z.boolean().default(false), goals: z.boolean().default(false),
  dailyBalance: z.boolean().default(false), fixedExpensePayments: z.boolean().default(false),
  foreignExpensePayments: z.boolean().default(false), receitasGastos: z.boolean().default(false),
  cardMovements: z.boolean().default(false), incomeMessages: z.boolean().optional(), expenseMessages: z.boolean().optional(),
  cardDue: z.boolean().default(true), fixedDue: z.boolean().default(false),
  accountsPayDue: z.boolean().default(false),
  taskSettlements: z.boolean().default(false), maintenanceDue: z.boolean().default(false),
  licenseDue: z.boolean().default(false),
  clientsPending: z.boolean().default(true),
  agendaDue: z.boolean().default(true),
}).transform(v => ({ ...v, incomeMessages: v.incomeMessages ?? v.receitasGastos, expenseMessages: v.expenseMessages ?? v.receitasGastos }));

export type NotificationSettings = z.infer<typeof notificationSettingsSchema>;
export const defaultNotifications = notificationSettingsSchema.parse({});
export const notificationOptions: { key: keyof NotificationSettings; label: string; admin?: boolean }[] = [
  { key: 'agendaDue', label: 'Agenda: compromissos amanhã' },
  { key: 'incomeMessages', label: 'Receitas recebidas' },
  { key: 'expenseMessages', label: 'Gastos e exclusões de gastos' },
  { key: 'cardMovements', label: 'Movimentações e alterações dos cartões' },
  { key: 'cardDue', label: 'Vencimento das faturas dos cartões' },
  { key: 'fixedExpensePayments', label: 'Pagamentos de despesas fixas' },
  { key: 'fixedDue', label: 'Vencimento de despesas fixas' },
  { key: 'dailyBalance', label: 'Resumo diário do saldo' },
  { key: 'accountsPayDue', label: 'Contas a pagar: próximas e vencidas' },
  { key: 'taskSettlements', label: 'Contas pagas, recebidas ou reabertas' },
  { key: 'maintenanceDue', label: 'Manutenção: vencimento por data ou KM' },
  { key: 'licenseDue', label: 'Vencimento da CNH dos motoristas' },
  { key: 'clientsPending', label: 'Clientes aguardando liberação', admin: true },
];

type Reminder = { id: string; title: string; body: string };
export function collectReminders(settings: NotificationSettings, data: {
  banks: {id:number;name:string;dueDay:number;status?:string}[];
  fixedExpenses: {id:number;name:string;dueDay:number;paidMonths:string[]}[];
  tasks: TasksState;
  agenda?: Appointment[];
}, now = new Date()): Reminder[] {
  const reminders: Reminder[] = [];
  const month = now.toLocaleDateString('sv-SE').slice(0,7);
  const dateDays = (date:string) => Math.round((Date.parse(`${date}T12:00:00`) - new Date(now.getFullYear(),now.getMonth(),now.getDate(),12).getTime()) / 86400000);
  const when = (days:number) => days < 0 ? `vencido há ${-days} dia(s)` : days === 0 ? 'vence hoje' : `vence em ${days} dia(s)`;
  if(settings.agendaDue) for(const item of data.agenda??[]) {
    if(dateDays(item.date)===1)reminders.push({id:`agenda-${item.id}-${item.date}-${item.time}`,title:'Compromisso amanhã',body:`${item.title} · amanhã às ${item.time}.`});
  }
  if(settings.cardDue) for(const bank of data.banks) {
    if(bank.status==='Arquivado'||bank.status==='Bloqueado')continue;
    const days=daysToCardDue(bank.dueDay,now);
    if(days<=5)reminders.push({id:`card-${bank.id}`,title:'Vencimento da fatura',body:`${bank.name}: ${when(days)}.`});
  }
  if(settings.fixedDue) for(const item of data.fixedExpenses) {
    if(item.paidMonths.includes(month))continue;
    const due=new Date(now.getFullYear(),now.getMonth(),Math.min(item.dueDay,new Date(now.getFullYear(),now.getMonth()+1,0).getDate()),12);
    const days=dateDays(due.toLocaleDateString('sv-SE'));
    if(days<=5)reminders.push({id:`fixed-${item.id}`,title:'Despesa fixa pendente',body:`${item.name}: ${when(days)}.`});
  }
  for(const item of data.tasks.accounts) {
    if(item.settled || item.kind!=='Pagar' || !settings.accountsPayDue)continue;
    const days=dateDays(item.dueDate);
    if(days<=5)reminders.push({id:`account-${item.id}`,title:'Conta a pagar',body:`${item.title}: ${when(days)}.`});
  }
  if(settings.maintenanceDue) for(const item of data.tasks.maintenance) {
    if(item.completed)continue;
    const vehicle=data.tasks.vehicles.find(v=>v.id===item.vehicleId);
    const kmDue=item.dueKm!==null && (vehicle?.odometer??0)>=item.dueKm;
    const days=dateDays(item.dueDate);
    if(days<=5||kmDue)reminders.push({id:`maintenance-${item.id}`,title:'Manutenção do veículo',body:`${vehicle?.name??'Veículo'} · ${item.title}: ${kmDue?'quilometragem de manutenção atingida':when(days)}.`});
  }
  if(settings.licenseDue) for(const item of data.tasks.drivers) {
    if(!item.active||!item.licenseDue)continue;
    const days=dateDays(item.licenseDue);
    if(days<=30)reminders.push({id:`license-${item.id}`,title:'Vencimento da CNH',body:`${item.name}: ${when(days)}.`});
  }
  return reminders;
}