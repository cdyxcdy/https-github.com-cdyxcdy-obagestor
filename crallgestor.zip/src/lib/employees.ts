// Browser-safe employee helpers: field lists, payday alert and the blank A4 form PDF.
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

export type EmployeeData = { nome?: string; telefone?: string; diaPagamento?: string; [key: string]: string | undefined };
export type Field = { key: string; label: string; type?: "text" | "number" | "date" | "tel" };
export type Section = { title: string; fields: Field[]; private?: boolean };

export const employeeSections: Section[] = [
  { title: "Dados pessoais", fields: [
    { key: "nome", label: "Nome completo" }, { key: "telefone", label: "Telefone", type: "tel" }, { key: "idade", label: "Idade", type: "number" }, { key: "filhos", label: "Filhos" },
    { key: "estadoCivil", label: "Estado civil" }, { key: "cpf", label: "CPF" }, { key: "rg", label: "RG" }, { key: "cor", label: "Cor" } ] },
  { title: "Contato e endereço", fields: [ { key: "endereco", label: "Endereço completo" } ] },
  { title: "Medidas", fields: [ { key: "calcado", label: "Calçado" }, { key: "roupa", label: "Tamanho de roupa" }, { key: "altura", label: "Altura" }, { key: "peso", label: "Peso" } ] },
  { title: "Dados bancários", fields: [ { key: "banco", label: "Banco" }, { key: "tipoConta", label: "Tipo de conta" }, { key: "agencia", label: "Agência" }, { key: "conta", label: "Número da conta" }, { key: "pixTipo", label: "Tipo da chave Pix" }, { key: "pix", label: "Chave Pix" }, { key: "titular", label: "Titular da conta" } ] },
  { title: "Contrato (somente você vê)", private: true, fields: [ { key: "admissao", label: "Data de contratação", type: "date" }, { key: "salario", label: "Salário (R$)", type: "number" }, { key: "bonus", label: "Bônus" }, { key: "licencas", label: "Licenças" }, { key: "diaPagamento", label: "Dia do pagamento (1–31)", type: "number" } ] },
];

/** Returns true when tomorrow is the employee's payday (day clamped to the month's last day). */
export function paydayIsTomorrow(day: number, now = new Date()) {
  if (!Number.isInteger(day) || day < 1 || day > 31) return false;
  const t = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  const last = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
  return t.getDate() === Math.min(day, last);
}

/** Blank A4 form for the employee to fill in: no photo, salary or contract data. */
export async function buildEmployeeFormPdf(prefill: EmployeeData = {}) {
  const doc = await PDFDocument.create();
  const page = doc.addPage([595.28, 841.89]);
  const font = await doc.embedFont(StandardFonts.Helvetica), bold = await doc.embedFont(StandardFonts.HelveticaBold);
  let y = 800;
  page.drawText("CRALL GESTOR — Ficha cadastral do funcionário", { x: 40, y, size: 15, font: bold }); y -= 18;
  page.drawText("Preencha com letra legível, assine e devolva em PDF ou foto.", { x: 40, y, size: 9, font, color: rgb(0.35, 0.35, 0.35) }); y -= 22;
  for (const s of employeeSections.filter(s => !s.private)) {
    page.drawText(s.title.toUpperCase(), { x: 40, y, size: 10, font: bold, color: rgb(0.05, 0.4, 0.5) }); y -= 18;
    for (const f of s.fields) {
      page.drawText(`${f.label}:`, { x: 40, y, size: 9.5, font });
      const v = (prefill[f.key] ?? "").replace(/[^\x20-\xFF]/g, "");
      if (v) page.drawText(v.slice(0, 70), { x: 170, y: y + 1, size: 9.5, font });
      page.drawLine({ start: { x: 165, y: y - 3 }, end: { x: 555, y: y - 3 }, thickness: 0.5, color: rgb(0.6, 0.6, 0.6) });
      y -= 20;
    }
    y -= 6;
  }
  y -= 20;
  page.drawLine({ start: { x: 40, y }, end: { x: 300, y }, thickness: 0.7 });
  page.drawLine({ start: { x: 360, y }, end: { x: 555, y }, thickness: 0.7 });
  page.drawText("Assinatura do funcionário", { x: 40, y: y - 12, size: 9, font });
  page.drawText("Data", { x: 360, y: y - 12, size: 9, font });
  return doc.save();
}

/** Registration number saved with the record (0 when the record predates numbering). */
export function employeeNumber(data: EmployeeData): number {
  const value = Number.parseInt(String(data["matricula"] ?? ""), 10);
  return Number.isInteger(value) && value > 0 ? value : 0;
}

/** Number for every record: stored numbers win, older records get the next free number in creation order. */
export function assignEmployeeNumbers(rows: { data: EmployeeData; created_at: string }[]): number[] {
  const used = new Set(rows.map(row => employeeNumber(row.data)).filter(n => n > 0));
  const order = rows.map((_, index) => index).sort((a, b) => (rows[a]?.created_at ?? "").localeCompare(rows[b]?.created_at ?? "") || a - b);
  const numbers: number[] = new Array(rows.length).fill(0);
  let next = 1;
  for (const index of order) {
    const stored = employeeNumber(rows[index]?.data ?? {});
    if (stored) { numbers[index] = stored; continue; }
    while (used.has(next)) next += 1;
    numbers[index] = next;
    used.add(next);
    next += 1;
  }
  return numbers;
}

/** Next registration number: one past the highest already used, so removed numbers are never reused. */
export function nextEmployeeNumber(numbers: number[]): number {
  return numbers.reduce((highest, n) => Math.max(highest, n), 0) + 1;
}

/** Registration number as shown on screen: 01, 02, 100. */
export function formatEmployeeNumber(value: number): string {
  return String(value).padStart(2, "0");
}

/** Checks a registration number typed by the owner: 1–4 digits, above zero, and not already used by another employee. */
export function validateEmployeeNumber(value: string, taken: number[] = []): { ok: true; number: number } | { ok: false; message: string } {
  const digits = value.trim();
  if (!/^\d{1,4}$/.test(digits)) return { ok: false, message: "O número de cadastro deve ter de 1 a 4 dígitos." };
  const number = Number.parseInt(digits, 10);
  if (number < 1) return { ok: false, message: "O número de cadastro deve ser maior que zero." };
  if (taken.includes(number)) return { ok: false, message: `O número ${formatEmployeeNumber(number)} já está em uso por outro funcionário.` };
  return { ok: true, number };
}
