type Movement = { date: string; type: "receita" | "gasto"; amount: number; accountType?: "Crédito" | "Débito"; paymentMethod?: string; fixedExpenseId?: number };
export function getMonthlyHomeValues(records: Movement[], now = new Date()) {
  const month = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const current = records.filter(r => r.date.slice(0, 7) === month);
  const net = (mode: "Crédito" | "Débito") => Math.max(0, current.reduce((sum, r) => {
    const matches = r.accountType === mode || r.paymentMethod === `Cartão ${mode.toLowerCase()}` || (mode === "Débito" && ["Pix", "Transferência"].includes(r.paymentMethod ?? ""));
    return matches ? sum + (r.type === "receita" ? r.amount : -r.amount) : sum;
  }, 0));
  return { credit: net("Crédito"), debit: net("Débito"), fixedPaid: current.filter(r => r.type === "gasto" && r.fixedExpenseId !== undefined).reduce((s, r) => s + r.amount, 0) };
}
export function daysToCardDue(day: number, today = new Date()) {
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const make = (month: number) => new Date(today.getFullYear(), month, Math.min(day, new Date(today.getFullYear(), month + 1, 0).getDate()));
  let due = make(today.getMonth());
  if (due < start) due = make(today.getMonth() + 1);
  return Math.round((due.getTime() - start.getTime()) / 86400000);
}