import { z } from 'zod';
const id = z.number().int().positive();
const text = z.string().trim().min(1).max(120);
const optionalText = z.string().trim().max(120);
const number = z.number().finite().min(0).max(1_000_000_000);
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
export const taskAccountSchema = z.object({ id, title: text, kind: z.enum(['Pagar','Receber']), amount: number, dueDate: date, person: optionalText, settled: z.boolean() });
export const driverSchema = z.object({ id, name: text, phone: optionalText, license: optionalText, licenseDue: z.union([date,z.literal('')]), active: z.boolean() });
export const vehicleSchema = z.object({ id, name: text, plate: text, kind: z.enum(['Carro de passeio','Caminhonete','Moto']), odometer: number, finalKm: number.nullable().optional(), driverId: id.nullable(), active: z.boolean(), photoPath: z.string().max(200).regex(/^[0-9a-f-]+\/[0-9a-f-]+\.(jpg|png|webp)$/).nullable().optional() });
export const maintenanceSchema = z.object({ id, vehicleId: id, title: text, dueDate: date, dueKm: number.nullable(), cost: number, completed: z.boolean() });
export const purchaseSchema = z.object({ id, product: text, condition: z.enum(['Novo','Usado']), origin: z.enum(['Original','Paralelo']), vehicleId: id, partCost: number, laborCost: number, purchased: z.boolean().optional() });
export const fuelSchema = z.object({ id, vehicleId: id, driverId: id.nullable(), date, startKm: number, endKm: number, liters: number.positive(), price: number.positive() }).refine(v => v.endKm > v.startKm, { message: 'O KM final deve ser maior que o KM inicial.', path: ['endKm'] });
export const tasksSchema = z.object({ accounts: z.array(taskAccountSchema).max(2000), drivers: z.array(driverSchema).max(500), vehicles: z.array(vehicleSchema).max(500), maintenance: z.array(maintenanceSchema).max(5000), fuel: z.array(fuelSchema).max(10000), purchases: z.array(purchaseSchema).max(5000).default([]) });
export type TasksState = z.infer<typeof tasksSchema>;
export const emptyTasks: TasksState = { accounts: [], drivers: [], vehicles: [], maintenance: [], fuel: [], purchases: [] };
export const vehiclesActiveFirst = (vehicles: TasksState['vehicles']) => [...vehicles].sort((a, b) => Number(b.active) - Number(a.active));
export const fuelMetrics = (v: Pick<z.infer<typeof fuelSchema>, 'startKm'|'endKm'|'liters'|'price'>) => { const distance = Math.max(0, v.endKm-v.startKm); const cost = v.liters*v.price; return { distance, cost, kmPerLiter: v.liters>0?distance/v.liters:0, costPerKm: distance>0?cost/distance:0 }; };
export const maintenanceStatus = (v: z.infer<typeof maintenanceSchema>, odometer: number, today: string) => v.completed?'Concluída':v.dueDate<today||(v.dueKm!==null&&odometer>=v.dueKm)?'Vencida':v.dueDate===today?'Vence hoje':'Agendada';

export const vehicleKmWarning = (vehicle: Pick<z.infer<typeof vehicleSchema>, 'odometer' | 'finalKm'>) => {
 if (vehicle.finalKm == null) return null;
 if (!number.safeParse(vehicle.finalKm).success) return 'Informe um KM final válido, entre 0 e 1.000.000.000.';
 return number.safeParse(vehicle.odometer + vehicle.finalKm).success ? null : 'A soma do odômetro excede o limite de 1.000.000.000 km.';
};

export const addVehicleKm = (vehicle: z.infer<typeof vehicleSchema>, distance: number) => {
 const warning = vehicleKmWarning({...vehicle, finalKm: distance});
 if (warning) throw new Error(warning);
 return vehicleSchema.parse({...vehicle, odometer: vehicle.odometer + distance, finalKm: distance});
};

export const reactivateVehicle = (vehicle: z.infer<typeof vehicleSchema>) => vehicle.active ? vehicle : vehicleSchema.parse({...vehicle, active: true});
