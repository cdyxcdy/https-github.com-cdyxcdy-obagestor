export function confirmedDeviceName(value: string): boolean {
  return value.trim().toLocaleUpperCase("pt-BR") === "CLAUDINEY";
}