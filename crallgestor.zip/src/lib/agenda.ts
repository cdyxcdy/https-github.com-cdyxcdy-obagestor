import { z } from 'zod';
export const agendaColors = ['cyan', 'coral', 'green', 'gold'] as const;
export const appointmentSchema = z.object({
  id: z.string().uuid(),
  title: z.string().trim().min(1).max(120),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(value => {
    const date = new Date(`${value}T12:00:00`);
    return Number.isFinite(date.getTime()) && localDate(date) === value;
  }, 'Data inválida'),
  time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  notes: z.string().trim().max(4000).default(''),
  color: z.enum(agendaColors),
});
export const agendaSchema = z.array(appointmentSchema).max(2000);
export type Appointment = z.infer<typeof appointmentSchema>;
export function localDate(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
}
export function appointmentsOnDay(items: Appointment[], date: string) {
  return items.filter(item => item.date === date).sort((a,b) => a.time.localeCompare(b.time));
}