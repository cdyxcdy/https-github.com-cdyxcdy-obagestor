export const ACCESS_PRICE_BRL = 30;
export const ACCESS_DAYS = 30;
export const ACCESS_PERIOD_MS = ACCESS_DAYS * 24 * 60 * 60 * 1000;
export const TRIAL_PERIOD_MS = 3600000;
export function licenseAccess(license: { suspended_at: string | null; expires_at: string | null; access_kind?: string; trial_started_at?: string | null } | null | undefined, isAdmin: boolean, now = Date.now()) {
  const expiresAt = license?.expires_at ?? null;
  const suspended = !isAdmin && Boolean(license?.suspended_at);
  const expired = !isAdmin && Boolean(license) && (!expiresAt || !Number.isFinite(Date.parse(expiresAt)) || Date.parse(expiresAt) <= now);
  return { licensed: isAdmin || (Boolean(license) && !suspended && !expired), suspended, expired, expiresAt: isAdmin ? null : expiresAt, trialAvailable: !isAdmin && !license, isTrial: !isAdmin && license?.access_kind === "trial" };
}