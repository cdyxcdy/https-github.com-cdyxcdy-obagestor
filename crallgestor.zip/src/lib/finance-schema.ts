import { z } from "zod";
import { notificationSettingsSchema } from "./notification-settings";
import { tasksSchema, emptyTasks } from './tasks-schema';
import { agendaSchema } from './agenda';

const safeNumber = z.number().finite().min(0).max(1_000_000_000_000);
const id = z.number().int().positive();
export const financeCardSchema = z.object({
  id, name: z.string().trim().min(1).max(80), invested: safeNumber,
  creditLimit: safeNumber, debitBalance: safeNumber.default(0), dueDay: z.number().int().min(1).max(31),
  creditAdjustment: z.number().finite().min(-100_000_000_000_000_000).max(100_000_000_000_000_000).optional(),
  debitAdjustment: z.number().finite().min(-100_000_000_000_000_000).max(100_000_000_000_000_000).optional(),
  color: z.enum(["Verde", "Azul", "Preto", "Roxo", "Rosa", "Vermelho", "Dourado", "Cinza metálico", "Prateado", "Branco", "Laranjado"]).optional(),
  brand: z.enum(["Visa", "Mastercard", "Elo", "American Express", "Nenhuma"]).optional(),
  status: z.enum(["Ativo", "Bloqueado", "Arquivado"]).optional(),
  primary: z.boolean().optional(),
});

export const fixedExpenseSchema = z.object({
  id, name: z.string().trim().min(1).max(100), amount: safeNumber,
  dueDay: z.number().int().min(1).max(31),
  paidMonths: z.array(z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/)).max(1_200).default([]),
});

export const foreignExpenseSchema = z.object({
  id, name: z.string().trim().min(1).max(100), amount: safeNumber,
  currency: z.enum(["USD", "EUR"]), date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  paid: z.boolean().default(false), paidAt: z.string().max(40).nullable().default(null),
  paidBrlAmount: safeNumber.nullable().default(null),
});

const currencyAssetsSchema = z.object({
  usdInvested: safeNumber.default(0),
  eurInvested: safeNumber.default(0),
  manualUsdRate: safeNumber.nullable().default(null),
  manualEurRate: safeNumber.nullable().default(null),
  autoUsdRate: safeNumber.nullable().default(null),
  autoEurRate: safeNumber.nullable().default(null),
  ratesUpdatedAt: z.string().max(40).nullable().default(null),
}).default({
  usdInvested: 0,
  eurInvested: 0,
  manualUsdRate: null,
  manualEurRate: null,
  autoUsdRate: null,
  autoEurRate: null,
  ratesUpdatedAt: null,
});

export const financeStateSchema = z.object({
  currency: z.enum(["BRL", "USD", "EUR"]),
  name: z.string().trim().min(1).max(80),
  discount: safeNumber,
  balance: z.number().finite().min(-1_000_000_000_000).max(1_000_000_000_000),
  banks: z.array(financeCardSchema).max(100),
  investments: z.array(z.object({
    id, bank: z.string().trim().min(1).max(80), percentage: z.number().finite().min(0).max(10_000),
    value: safeNumber, withdrawal: safeNumber, invested: safeNumber,
    applicationDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  })).max(1_000),
  records: z.array(z.object({
    id, title: z.string().trim().min(1).max(100), category: z.string().trim().min(1).max(80),
    amount: safeNumber, type: z.enum(["receita", "gasto"]), date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    paymentMethod: z.string().trim().max(80).optional(),
    cardId: id.optional(), cardName: z.string().trim().max(80).optional(),
    accountType: z.enum(["Crédito", "Débito"]).optional(), fixedExpenseId: id.optional(),
    paidAt: z.string().datetime().optional(),
  })).max(10_000),
  budgets: z.array(z.object({ id, name: z.string().trim().min(1).max(100), value: safeNumber, extra: safeNumber.optional(), image: z.string().max(5_000_000).optional() })).max(1_000),
  accounts: z.array(z.object({ id, name: z.string().trim().min(1).max(100), value: safeNumber, extra: safeNumber.optional(), image: z.string().max(5_000_000).optional() })).max(1_000),
  fixedExpenses: z.array(fixedExpenseSchema).max(1_000).default([]),
  foreignExpenses: z.array(foreignExpenseSchema).max(1_000).default([]),
  goals: z.array(z.object({ id, name: z.string().trim().min(1).max(100), value: safeNumber, extra: safeNumber.optional(), image: z.string().max(5_000_000).optional() })).max(1_000),
  notifications: notificationSettingsSchema,
  currencyAssets: currencyAssetsSchema,
  homeResets: z.object({ credit: safeNumber.default(0), expenses: safeNumber.default(0) }).default({ credit: 0, expenses: 0 }),
  tasks: tasksSchema.default(emptyTasks),
  agenda: agendaSchema.default([]),
});

export const financeStatePatchSchema = financeStateSchema.partial().refine(
  (value) => Object.keys(value).length > 0,
  "Informe ao menos uma seção para sincronizar.",
);

export type FinanceState = z.infer<typeof financeStateSchema>;
export type FinanceStatePatch = z.infer<typeof financeStatePatchSchema>;