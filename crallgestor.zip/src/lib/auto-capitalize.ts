/** Returns the uppercase letter when typing at the start of a text or of a sentence after a period. */
export function capitalizeTyped(before: string, typed: string): string {
  if (typed.length !== 1 || typed.toLocaleUpperCase("pt-BR") === typed) return typed;
  return /(^|[.!?]\s+)$/.test(before) || before.trim() === "" ? typed.toLocaleUpperCase("pt-BR") : typed;
}

const textTypes = new Set(["", "text", "search"]);
export function acceptsAutoCapital(target: EventTarget | null): target is HTMLInputElement | HTMLTextAreaElement {
  if (target instanceof HTMLTextAreaElement) return !target.readOnly;
  if (!(target instanceof HTMLInputElement) || target.readOnly) return false;
  const hint = `${target.name} ${target.id} ${target.autocomplete}`.toLowerCase();
  return textTypes.has(target.type === "text" ? target.getAttribute("type") ?? "" : target.type) && !/mail|senha|password|url|user/.test(hint);
}

/** Installs sentence capitalization for every typing field; React state receives the corrected text normally. */
export function installAutoCapitalize(doc: Document): () => void {
  const focus = (event: FocusEvent) => { if (acceptsAutoCapital(event.target)) event.target.setAttribute("autocapitalize", "sentences"); };
  const before = (event: InputEvent) => {
    const field = event.target;
    if (event.inputType !== "insertText" || !event.data || !acceptsAutoCapital(field) || field.selectionStart === null) return;
    const start = field.selectionStart; const end = field.selectionEnd ?? start;
    const next = capitalizeTyped(field.value.slice(0, start), event.data);
    if (next === event.data) return;
    event.preventDefault();
    const proto = field instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(field, field.value.slice(0, start) + next + field.value.slice(end));
    field.setSelectionRange(start + 1, start + 1);
    field.dispatchEvent(new Event("input", { bubbles: true }));
  };
  doc.addEventListener("focusin", focus);
  doc.addEventListener("beforeinput", before);
  return () => { doc.removeEventListener("focusin", focus); doc.removeEventListener("beforeinput", before); };
}