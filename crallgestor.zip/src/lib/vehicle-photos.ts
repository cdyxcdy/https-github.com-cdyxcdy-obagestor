export const vehiclePhotoBucket = 'vehicle-photos';
export function validateVehiclePhoto(file: Pick<File, 'type' | 'size'>) {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) return 'Escolha uma foto JPG, PNG ou WebP.';
  if (file.size > 10 * 1024 * 1024) return 'A foto deve ter no máximo 10 MB.';
  if (file.size === 0) return 'Esta foto está vazia. Escolha outra.';
  return null;
}