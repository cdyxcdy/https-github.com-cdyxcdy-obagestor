type Card = { id: number; creditLimit: number; debitBalance?: number; creditAdjustment?: number; debitAdjustment?: number };
type Movement = { id: number; cardId?: number; type: 'receita' | 'gasto'; amount: number; accountType?: 'Crédito' | 'Débito'; paymentMethod?: string };

export function getDisplayedHomeCredit(available: number, resetBaseline = 0) {
  void resetBaseline;
  return Math.max(0, available);
}

export function getTotalExpenses(records: Movement[]) {
  return records.filter(record => record.type === 'gasto').reduce((sum, record) => sum + Math.round(record.amount * 100), 0) / 100;
}

export function getCardAvailableBalance(bank: Card, records: Movement[], accountType: 'Crédito' | 'Débito', excludeRecordId?: number) {
  const linked = records.filter(record => record.cardId === bank.id && record.id !== excludeRecordId);
  const income = linked.filter(record => record.type === 'receita' && record.accountType === accountType).reduce((sum, record) => sum + record.amount, 0);
  const isCredit = accountType === 'Crédito';
  const spent = linked.filter(record => record.type === 'gasto' && (isCredit ? record.paymentMethod === 'Cartão crédito' : (record.paymentMethod === 'Cartão débito' || (record.paymentMethod === 'Pix' && record.accountType === 'Débito')))).reduce((sum, record) => sum + record.amount, 0);
  const opening = isCredit ? bank.creditLimit : bank.debitBalance ?? 0;
  const adjustment = isCredit ? bank.creditAdjustment ?? 0 : bank.debitAdjustment ?? 0;
  return Math.max(0, Math.round((opening + adjustment + income - spent) * 100) / 100);
}

export function getHomeCardBalances(banks: Card[], records: Movement[]) {
  const credit = banks.reduce((sum, bank) => sum + getCardAvailableBalance(bank, records, 'Crédito'), 0);
  const cardDebit = banks.reduce((sum, bank) => sum + getCardAvailableBalance(bank, records, 'Débito'), 0);
  const unlinkedReceipts = records.filter(record => record.type === 'receita' && !record.cardId && ['Pix', 'Transferência'].includes(record.paymentMethod ?? '')).reduce((sum, record) => sum + record.amount, 0);
  return { credit: Math.round(credit * 100) / 100, debit: Math.round((cardDebit + unlinkedReceipts) * 100) / 100 };
}