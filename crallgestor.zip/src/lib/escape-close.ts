// Browser-safe Escape-key arbiter: one window listener, a stack of closers, highest priority acts.
// Radix layers (shadcn Dialog/Select/Popover/Command) dismiss themselves on Escape, so they are
// detected in the DOM and skipped here to avoid closing a window and its tab at the same time.

type EscapeEntry = { id: number; priority: number; close: () => void };

const openLayer = [
  '[role="dialog"][data-state="open"]',
  '[role="alertdialog"][data-state="open"]',
  '[role="listbox"][data-state="open"]',
  '[role="menu"][data-state="open"]',
  '[role="tooltip"][data-state="open"]',
].join(",");

let sequence = 0;
let listening = false;
const entries: EscapeEntry[] = [];

function handleKeyDown(event: KeyboardEvent) {
  if (event.key !== "Escape" || event.repeat || event.defaultPrevented) return;
  if (document.querySelector(openLayer)) return; // a system dialog, select or popover owns this key press
  const top = entries.reduce<EscapeEntry | undefined>(
    (best, entry) => (!best || entry.priority > best.priority || (entry.priority === best.priority && entry.id > best.id)) ? entry : best,
    undefined,
  );
  if (!top) return;
  event.preventDefault();
  top.close();
}

/** Registers a closer while a window or tab is open. Returns the unregister function. */
export function registerEscapeClose(close: () => void, priority = 0) {
  const entry: EscapeEntry = { id: ++sequence, priority, close };
  entries.push(entry);
  if (!listening && typeof window !== "undefined") {
    window.addEventListener("keydown", handleKeyDown);
    listening = true;
  }
  return () => {
    const index = entries.indexOf(entry);
    if (index >= 0) entries.splice(index, 1);
  };
}
