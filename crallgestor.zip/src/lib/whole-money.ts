// Display-only formatter: rounds to whole reais without changing stored amounts.
const fmt = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", minimumFractionDigits: 0, maximumFractionDigits: 0 });
export function wholeMoney(value: number) {
  return fmt.format(Math.round(value)).replace(/\u00a0/g, " ");
}
