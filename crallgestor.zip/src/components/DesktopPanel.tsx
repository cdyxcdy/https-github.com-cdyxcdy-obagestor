import { Button } from "@/components/ui/button";
import { createPortal } from "react-dom";
import { RisingMessages, SidebarNotifications } from "@/components/ActivityFeed";
import { receivedTransfers, RECEIPT_ROTATION_MS } from "@/lib/activity-feed";
import type { NotificationSettings } from "@/lib/notification-settings";
import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { getCardAvailableBalance } from "@/lib/card-balances";
import { centsBalance } from "@/lib/cents-balance";
import { financialPaymentMethods } from "@/lib/payment-presentation";
import {
  ArrowLeftRight, BarChart3, CalendarCheck, ChevronRight, CreditCard, Gauge, Home, ListChecks,
  Fingerprint, ReceiptText, Check, Pencil, PiggyBank, Landmark, Users, Car, Settings, LogOut, ShoppingCart, UserRound, Wallet, Zap, AlertCircle, Heart,
} from "lucide-react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CrallAssistant } from "@/components/CrallAssistant";
import { DonationContracts } from "@/components/DonationContracts";
import { getHomeCardBalances } from "@/lib/card-balances";
import { cardThumbnail } from "@/lib/card-thumbnails";
import { newestRecordsFirst, recordDisplayDate } from "@/lib/record-order";

type Rec = { id: number; title: string; category: string; amount: number; type: "receita" | "gasto"; date: string; paymentMethod?: string; cardName?: string; cardId?: number; accountType?: "Crédito" | "Débito"; fixedExpenseId?: number; paidAt?: string };
type CardBank = { id: number; name: string; invested: number; status?: string; primary?: boolean; creditLimit: number; debitBalance?: number; creditAdjustment?: number; debitAdjustment?: number; desiredBalances?: { creditLimit: number; debitBalance: number }; color?: string; brand?: string; dueDay?: number };
type PanelStore = { banks: CardBank[]; records: Rec[]; fixedExpenses?: { id: number; name: string; amount: number; dueDay: number; paidMonths: string[] }[]; investments?: { bank: string; percentage: number }[] };
const quickCategories = ["Assinaturas", "Dinheiro", "Doações", "Vestuários", "Supermercados", "Lazer", "Saúde", "Transportes", "Despesas fixas", "Impostos", "Despesas aleatórias", "Empréstimos", "Troco"].sort((a, b) => b.length - a.length || a.localeCompare(b, "pt-BR"));

const item = "flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm font-semibold transition-colors";
const idle = "text-muted-foreground hover:bg-muted hover:text-foreground";
const active = "bg-primary text-primary-foreground shadow-[0_8px_24px_var(--primary-glow)]";

export function DesktopSidebar({ view, isAdmin, onSelect, userId, email, notifications, saveNotifications }: { view: string; isAdmin: boolean; onSelect: () => void; openAgenda?: () => void; onSettings: () => void; onLogout: () => void; userId: string; email?: string; notifications: NotificationSettings; saveNotifications: (settings: NotificationSettings) => void }) {
  return <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-border bg-background/95 p-4 backdrop-blur-2xl lg:flex" aria-label="Menu lateral">
    {isAdmin ? <CrallAssistant variant="sidebar" /> : <Link to="/dashboard" search={{ tab: "home" }} onClick={onSelect} className="flex items-center gap-3 px-2 py-2"><span className="grid size-12 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground"><BarChart3 size={26} /></span><span className="font-display text-2xl font-bold">CRALL</span></Link>}
    <hr className="my-3 border-border" />
    <nav className="flex flex-1 flex-col gap-1 overflow-y-auto overflow-x-hidden min-h-0 min-w-0">
      <Link to="/dashboard" search={{ tab: "home" }} onClick={onSelect} aria-current={view === "home" ? "page" : undefined} className={`${item} ${view === "home" ? active : idle}`}><Home size={20} />Início (Dashboard)</Link>
      <Link to="/dashboard" search={{ tab: "cards" }} onClick={onSelect} aria-current={view === "cards" ? "page" : undefined} className={`${item} ${view === "cards" ? active : idle}`}><CreditCard size={20} />Cartões &amp; Contas</Link>
      {isAdmin && <Link to="/funcionarios" className={`${item} ${idle}`}><Users size={20} />Funcionários</Link>}
      {isAdmin && <Link to="/dashboard" search={{ tab: "frotapro" }} onClick={onSelect} aria-current={view === "frotapro" ? "page" : undefined} className={`${item} ${view === "frotapro" ? active : idle}`}><Car size={20} />FrotaPro</Link>}
      {isAdmin && <Link to="/crallpoint" className={`${item} ${idle}`}><Fingerprint size={20} />Crall Point</Link>}
      <SidebarNotifications userId={userId} settings={notifications} save={saveNotifications} isAdmin={isAdmin}/>
      <DonationContracts userId={userId} email={email ?? ""} />
    </nav>
  </aside>;
}

function TopCard({ label, value, note, icon, tone, big, alert, siren }: { label: string; value: string; note: ReactNode; icon: ReactNode; tone: string; big?: boolean; alert?: boolean; siren?: boolean }) {
  return <div className={`money-card rounded-2xl border-2 p-4 [container-type:inline-size] ${siren ? "blink-siren border-destructive/70" : alert ? "blink-yellow" : ""}`} style={{ borderColor: siren ? undefined : `color-mix(in oklch, ${tone}, transparent 50%)` }}>
    <div className="flex items-center gap-3"><span className={`grid shrink-0 place-items-center rounded-xl ${big ? "size-10" : "size-9"}`} style={{ background: tone, color: "var(--background)" }}>{icon}</span><p className={`${big ? "text-base" : "text-sm"} font-semibold leading-tight`}>{label}</p></div>
    <p className={`${big ? "financial-value-md" : "financial-value-sm"} mt-1 font-display font-bold`} style={{ color: tone }}>{value}</p>
    <div className="mt-1 text-sm text-muted-foreground">{note}</div>
  </div>;
}

const palette = ["var(--primary)", "var(--income)", "var(--accent)", "var(--reports)", "var(--records)", "var(--destructive)", "var(--muted-foreground)"];

const quickCatalog = [
  { id: "records", label: "Receitas e Gastos", icon: ReceiptText, tone: "var(--destructive)", tab: "records" },
  { id: "cards", label: "Cartões", icon: CreditCard, tone: "var(--primary)", tab: "cards" },
  { id: "fixedExpenses", label: "Despesas Fixas", icon: CalendarCheck, tone: "var(--accent)", tab: "fixedExpenses" },
  { id: "tasks", label: "Minhas Tarefas", icon: ListChecks, tone: "var(--reports)", tab: "tasks" },
  { id: "frotapro", label: "FrotaPro", icon: Car, tone: "var(--records)", tab: "frotapro", admin: true },
  { id: "funcionarios", label: "Funcionários", icon: Users, tone: "var(--credit)", path: "/funcionarios", admin: true },
  { id: "crallpoint", label: "Crall Point", icon: Fingerprint, tone: "var(--destructive)", path: "/crallpoint", admin: true },
] as const;
const defaultQuick = ["records", "cards"];

/** Quick access shows exactly one editable shortcut, saved per user on this device. */
function QuickAccess({ userId, isAdmin, onSelect, onQuickRecord, onQuickCard }: { userId: string; isAdmin: boolean; onSelect: () => void; onQuickRecord: () => void; onQuickCard: () => void }) {
  const key = `oba-quick-access:${userId}`;
  const allowed = quickCatalog.filter(q => (isAdmin || !("admin" in q)) && q.id !== "cards" && q.id !== "tasks");
  const fix = (v: string[]) => { const ok = v.filter(id => allowed.some(q => q.id === id)).filter((x, i, a) => a.indexOf(x) === i); for (const d of [...defaultQuick, ...allowed.map(q => q.id)]) if (ok.length < 1 && !ok.includes(d)) ok.push(d); return ok.slice(0, 1); };
  const [ids, setIds] = useState<string[]>(defaultQuick.slice(0, 1));
  const [draft, setDraft] = useState<string[] | null>(null);
  useEffect(() => { try { const v = JSON.parse(localStorage.getItem(key) ?? "null"); if (Array.isArray(v)) setIds(fix(v.filter((x): x is string => typeof x === "string"))); } catch { /* ignore */ } }, [key]); // eslint-disable-line react-hooks/exhaustive-deps
  const save = () => { if (draft) { setIds(draft); localStorage.setItem(key, JSON.stringify(draft)); } setDraft(null); };
  const list = (draft ?? ids).map(id => allowed.find(q => q.id === id)).filter(q => q !== undefined);
  const cls = "quick-shortcut flex h-auto min-h-16 w-full items-center justify-start gap-3 whitespace-normal rounded-xl border border-border bg-muted/30 p-3 transition-colors hover:border-primary/60";
  return <section className={`money-card relative min-w-0 rounded-xl p-3 ${draft ? "z-30" : ""}`} aria-label="Atalhos diretos">
    <div className="mb-2 flex items-center justify-between gap-2"><h2 className="flex items-center gap-2 text-sm font-bold"><Zap size={18} className="text-primary" />Atalhos diretos</h2>
      {draft ? <div className="flex gap-1"><button type="button" onClick={() => setDraft(defaultQuick.slice(0, 1))} className="rounded-lg px-2 py-1 text-xs font-bold text-muted-foreground hover:bg-muted">Padrão</button><button type="button" onClick={() => setDraft(null)} className="rounded-lg px-2 py-1 text-xs font-bold text-muted-foreground hover:bg-muted">Cancelar</button><button type="button" onClick={save} className="flex items-center gap-1 rounded-lg bg-primary px-2 py-1 text-xs font-bold text-primary-foreground"><Check size={14} />Salvar</button></div>
        : <Button variant="icon" size="icon" onClick={() => setDraft(ids)} aria-label="Editar atalhos" title="Editar" className="size-8 min-h-8 shrink-0"><Pencil size={16}/></Button>}
    </div>
    <div className="grid gap-3">
      {list.map((q, i) => {
        const inner = <><span className="grid size-9 shrink-0 place-items-center rounded-lg" style={{ background: q.tone, color: "var(--background)" }}><q.icon size={20} /></span><span className="min-w-0 break-words text-left text-sm font-bold">{q.label}</span></>;
        if (draft) return <div key={i} className={`${cls} flex-wrap border-dashed`}>{inner}
          <div className="flex w-full min-w-0 flex-wrap items-center gap-2"><select aria-label={`Atalho ${i + 1}`} value={q.id} onChange={e => setDraft(d => { const n = [...(d ?? ids)]; const o = n.indexOf(e.target.value); if (o >= 0) n[o] = n[i] ?? e.target.value; n[i] = e.target.value; return n; })} className="min-w-0 flex-1 text-sm">{allowed.map(o => <option key={o.id} value={o.id}>{o.label}</option>)}</select>
          <button type="button" onClick={() => setDraft(d => [...(d ?? ids)].reverse())} className="rounded-lg px-2 py-1 text-xs font-bold text-muted-foreground hover:bg-muted" aria-label="Trocar ordem">{i === 0 ? "↓" : "↑"}</button></div></div>;
        if (q.id === "records") return <Button key={q.id} variant="ghost" onClick={onQuickRecord} className={cls}>{inner}</Button>;
        if (q.id === "cards") return <Button key={q.id} variant="ghost" onClick={onQuickCard} className={cls}>{inner}</Button>;
        return "path" in q ? <Link key={q.id} to={q.path} className={cls}>{inner}</Link> : <Link key={q.id} to="/dashboard" search={{ tab: q.tab }} onClick={onSelect} className={cls}>{inner}</Link>;
      })}
    </div>
  </section>;
}

function ReceiptsCard({ records, money }: { records: Rec[]; money: (n: number) => string }) {
  const receipts = newestRecordsFirst(receivedTransfers(records));
  const total = receipts.reduce((sum, record) => sum + record.amount, 0);
  const messages = receipts.slice(0, 20).map(record => ({ id: String(record.id), body: `Você acaba de receber ${record.paymentMethod === "Pix" ? "um Pix" : "uma transferência"} de ${money(record.amount)} · ${record.title}.` }));
  return <section className="money-card receipts-card min-w-0 rounded-xl p-3" aria-label="Recebimentos por Pix e transferência">
    <h2 className="flex items-start gap-2 text-sm font-bold"><ArrowLeftRight size={18} className="shrink-0 text-primary"/><span>Recebimentos por Pix / Transferência</span></h2>
    <strong className="receipt-total my-2 block font-display text-primary">{money(total)}</strong>
    <RisingMessages interval={RECEIPT_ROTATION_MS} messages={messages} empty="Nenhum Pix ou transferência recebido ainda."/>
  </section>;
}

const chartBox =  { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, color: "var(--popover-foreground)" };

const cents = (v: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);
function CentsCard({ records }: { records: Rec[] }) {
  const c = centsBalance(records);
  return <section className="money-card flex min-w-0 flex-col gap-2 rounded-xl p-3" aria-label="Balanço de centavos">
    <h2 className="text-xs font-bold uppercase text-muted-foreground">🪙 Centavos</h2>
    <p className="flex justify-between gap-2 text-xs"><span>Entradas</span><strong className="text-primary">+ {cents(c.income)}</strong></p>
    <p className="flex justify-between gap-2 text-xs"><span>Saídas</span><strong className="text-destructive">− {cents(c.expense)}</strong></p>
    <hr className="border-border"/>
    <p className="flex justify-between gap-2 text-sm"><span className="font-semibold">Saldo</span><strong className={c.net < 0 ? "text-destructive" : "text-primary"}>{c.net < 0 ? "− " : "+ "}{cents(Math.abs(c.net))}</strong></p>
  </section>;
}

function FixedHomeCard({ items, money, onSelect }: { items: NonNullable<PanelStore["fixedExpenses"]>; money: (n: number) => string; onSelect: () => void }) {
  const d = new Date(); const month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  const paid = items.filter(i => i.paidMonths.includes(month));
  const total = items.reduce((s, i) => s + i.amount, 0); const paidTotal = paid.reduce((s, i) => s + i.amount, 0);
  return <section className="money-card flex flex-1 flex-col rounded-xl p-4">
    <div className="flex items-center justify-between gap-2"><h2 className="flex items-center gap-2 text-lg font-bold"><CalendarCheck size={18} className="text-primary"/>Despesas fixas</h2><Link to="/dashboard" search={{ tab: "fixedExpenses" }} onClick={onSelect} className="flex items-center gap-1 text-xs font-bold text-primary">Abrir <ChevronRight size={14}/></Link></div>
    <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
      <p><span className="block text-xs text-muted-foreground">Total do mês</span><strong>{money(total)}</strong></p>
      <p><span className="block text-xs text-muted-foreground">Pagas ({paid.length})</span><strong className="text-primary">{money(paidTotal)}</strong></p>
      <p><span className="block text-xs text-muted-foreground">Pendentes ({items.length - paid.length})</span><strong className="text-destructive">{money(total - paidTotal)}</strong></p>
    </div>
  </section>;
}

function CardsLoop({ banks, records, money }: { banks: CardBank[]; records: Rec[]; money: (n: number) => string }) {
  if (!banks.length) return null;
  const items = banks.map(b => {
    const credit = getCardAvailableBalance(b, records, "Crédito");
    const debit = getCardAvailableBalance(b, records, "Débito");
    const thumb = cardThumbnail(b.name);
    return <div key={b.id} className="money-card flex shrink-0 items-center gap-3 rounded-xl px-4 py-2">
      {thumb ? <img src={thumb.image} alt={`Cartão ${thumb.label}`} width={48} height={30} className="h-8 w-12 rounded border border-border object-cover"/> : <CreditCard size={20} className="text-primary"/>}
      <strong className="text-sm">{b.name}</strong>
      {b.creditLimit > 0 || credit > 0 ? <span className="text-xs">Crédito <strong className="text-[var(--credit)]">{money(credit)}</strong></span> : null}
      {debit > 0 && <span className="text-xs">Débito <strong className="text-[var(--income)]">{money(debit)}</strong></span>}
      {(b.invested ?? 0) > 0 && <span className="text-xs">Investido <strong className="text-[var(--reports)]">{money(b.invested)}</strong></span>}
    </div>;
  });
  return <section aria-label="Cartões cadastrados" className="cards-loop overflow-hidden">
    <div className="cards-loop-track flex w-max gap-3" style={{ animationDuration: `${Math.max(20, banks.length * 8)}s` }}>{items}<div aria-hidden className="flex gap-3">{items}</div></div>
  </section>;
}

export function DesktopHome({ store, money, expenses, onSelect, userId, isAdmin, saveRecord, saveCard }: { store: PanelStore; money: (n: number) => string; expenses: number; onSelect: () => void; userId: string; isAdmin: boolean; saveRecord: (r: Rec) => void; saveCard: (b: CardBank) => void }) {
  const [quick, setQuick] = useState<null | "record" | "cards">(null);
  const [adjustBank, setAdjustBank] = useState<CardBank | null>(null);
  const balances = getHomeCardBalances(store.banks, store.records);
  const credit = balances.credit;
  const siren = credit <= 500; const alert = !siren && credit <= 1000;
  const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const today = new Date();
  const week = Array.from({ length: 7 }, (_, i) => { const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - (6 - i)); const key = iso(d); const day = store.records.filter(r => recordDisplayDate(r) === key); return { dia: `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}`, Receitas: day.filter(r => r.type === "receita").reduce((s, r) => s + r.amount, 0), Despesas: day.filter(r => r.type === "gasto").reduce((s, r) => s + r.amount, 0) }; });
  const months = Array.from({ length: 6 }, (_, i) => { const d = new Date(today.getFullYear(), today.getMonth() - (5 - i), 1); const key = iso(d).slice(0, 7); const m = store.records.filter(r => recordDisplayDate(r).slice(0, 7) === key); return { mes: d.toLocaleDateString("pt-BR", { month: "short" }).replace(".", ""), Receitas: m.filter(r => r.type === "receita").reduce((s, r) => s + r.amount, 0), Despesas: m.filter(r => r.type === "gasto").reduce((s, r) => s + r.amount, 0) }; });
  const monthKey = iso(today).slice(0, 7);
  const byCat = Object.entries(store.records.filter(r => r.type === "gasto" && recordDisplayDate(r).slice(0, 7) === monthKey).reduce<Record<string, number>>((a, r) => { a[r.category] = (a[r.category] ?? 0) + r.amount; return a; }, {})).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  const catTotal = byCat.reduce((s, c) => s + c.value, 0);
  const latest = newestRecordsFirst(store.records).slice(0, 50);
  const tip = (v: unknown) => money(Number(Array.isArray(v) ? v[0] ?? 0 : v ?? 0));
  const investedBanks = store.banks.filter(b => b.status !== "Arquivado" && (b.invested ?? 0) > 0).map(b => { const rate = store.investments?.find(i => i.bank.trim().toLowerCase() === b.name.trim().toLowerCase())?.percentage ?? 0; return { ...b, rate, yieldMonth: b.invested * rate / 100 }; });
  const totalInvested = investedBanks.reduce((s, b) => s + b.invested, 0);
  return <div className="rise-in flex flex-col gap-4 pb-6">
    <div className="desktop-balance-grid grid grid-cols-2 gap-4 xl:grid-cols-4">
      <TopCard big label="Crédito disponível" value={money(credit)} tone="var(--credit)" icon={<CreditCard size={22} />} siren={siren} alert={alert} note={siren ? <span className="flex items-center gap-1 font-bold text-destructive"><AlertCircle size={14} />Atenção! Urgente!</span> : alert ? <span className="font-bold text-[var(--warning,#eab308)]">Chegou a R$ 1.000!</span> : "Limite disponível"} />
      <TopCard big label="Gastos totais" value={`− ${money(expenses)}`} tone="var(--destructive)" icon={<Wallet size={22} />} note="Total de saídas" />
      <TopCard big label="Débito disponível" value={money(balances.debit)} tone="var(--income)" icon={<CreditCard size={22} />} note="Saldo atual" />
      <TopCard big label="Total investido" value={money(totalInvested)} tone="var(--reports)" icon={<PiggyBank size={22} />} note={`${investedBanks.length} ${investedBanks.length === 1 ? "banco ativo" : "bancos ativos"}`} />
    </div>
    <CardsLoop banks={store.banks.filter(b => b.status !== "Arquivado")} records={store.records} money={money} />
    <div className="grid grid-cols-1 items-stretch gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <div className="flex min-w-0 flex-col gap-3">
      <div className="grid min-w-0 grid-cols-[minmax(0,2fr)_minmax(0,3fr)_minmax(0,2fr)] items-stretch gap-3">
        <QuickAccess userId={userId} isAdmin={isAdmin} onSelect={onSelect} onQuickRecord={() => setQuick("record")} onQuickCard={() => setQuick("cards")} />
        <ReceiptsCard records={store.records} money={money} />
        <CentsCard records={store.records} />
      </div>
      <FixedHomeCard items={store.fixedExpenses ?? []} money={money} onSelect={onSelect} />
      </div>
      <section className="money-card flex min-h-0 min-w-0 flex-col rounded-xl p-4 xl:max-h-[34rem]"><div className="flex flex-wrap items-center justify-between gap-2"><h2 className="text-lg font-bold">Movimentações de gastos</h2><Link to="/dashboard" search={{ tab: "records" }} onClick={onSelect} className="flex items-center gap-1 text-xs font-bold text-primary">Ver todas <ChevronRight size={14}/></Link></div><ul className="mt-3 min-h-0 flex-1 divide-y divide-border overflow-y-auto pr-1" onMouseLeave={e => e.currentTarget.scrollTo({ top: 0, behavior: "smooth" })}>{latest.length ? latest.map(r => {
        const donation = r.type === "gasto" && r.category === "Doações";
        const thumb = cardThumbnail(r.cardName);
        return <li key={r.id} className="activity-record grid grid-cols-[auto_minmax(0,1fr)] items-start gap-3 py-3">
          {donation ? <span className="grid size-10 place-items-center rounded-lg bg-accent/15 text-xl" aria-label="Doação">💝</span> : thumb ? <img src={thumb.image} alt={`Cartão ${thumb.label}`} width={64} height={40} className="h-10 w-16 rounded-md border border-border object-cover"/> : <ReceiptText size={20} className="text-primary"/>}
          <div className="min-w-0"><strong className="block break-words text-sm">{r.title}</strong><span className="block break-words text-xs text-muted-foreground">{recordDisplayDate(r).split("-").reverse().join("/")}{r.cardName ? ` · ${r.cardName}` : ""}</span><div className="mt-1 flex flex-wrap items-center gap-2">{donation && <span className="donation-label">[DOAÇÃO]</span>}<strong className={`break-words text-sm ${r.type === "receita" ? "text-primary" : "text-destructive"}`}>{r.type === "receita" ? "+ " : "− "}{money(r.amount)}</strong></div></div>
        </li>;
      }) : <li className="py-2 text-sm text-muted-foreground">Nenhum lançamento ainda.</li>}</ul></section>
    </div>
    <div className="grid grid-cols-[minmax(0,3fr)_minmax(0,2fr)] gap-4">
      <section className="money-card flex h-72 flex-col rounded-2xl p-4"><h2 className="text-lg font-bold">Fluxo financeiro</h2><p className="text-xs text-muted-foreground">Receitas e despesas dos últimos 7 dias</p><div className="mt-2 min-h-0 flex-1"><ResponsiveContainer width="100%" height="100%"><AreaChart data={week} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}><CartesianGrid stroke="var(--border)" strokeDasharray="4 4" vertical={false} /><XAxis dataKey="dia" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} /><YAxis width={70} tickFormatter={v => money(Number(v))} tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} /><Tooltip formatter={tip} contentStyle={chartBox} /><Area type="monotone" dataKey="Receitas" stroke="var(--income)" strokeWidth={3} fill="var(--income)" fillOpacity={0.12} /><Area type="monotone" dataKey="Despesas" stroke="var(--destructive)" strokeWidth={3} fill="var(--destructive)" fillOpacity={0.1} /></AreaChart></ResponsiveContainer></div></section>
      <section className="money-card flex h-72 flex-col overflow-hidden rounded-2xl p-4"><h2 className="text-lg font-bold">Despesas por categoria</h2><p className="text-xs text-muted-foreground">Distribuição dos gastos deste mês</p><div className="mt-2 grid flex-1 grid-cols-[150px_minmax(0,1fr)] items-center gap-4"><div className="relative mx-auto size-36 shrink-0"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={byCat.length ? byCat : [{ name: "Sem gastos", value: 1 }]} dataKey="value" cx="50%" cy="50%" innerRadius={44} outerRadius={64} stroke="none">{(byCat.length ? byCat : [{ name: "-" }]).map((c, i) => <Cell key={c.name} fill={byCat.length ? palette[i % palette.length] : "var(--muted)"} />)}</Pie></PieChart></ResponsiveContainer><div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center leading-tight"><strong className="block text-sm">{money(catTotal)}</strong><span className="text-[10px] text-muted-foreground">Total</span></div></div><ul className="max-h-48 space-y-2 overflow-y-auto pr-1 text-sm">{byCat.length ? byCat.slice(0, 8).map((c, i) => <li key={c.name} className="flex items-center justify-between gap-2"><span className="flex min-w-0 items-center gap-2"><i className="size-2.5 shrink-0 rounded-full" style={{ background: palette[i % palette.length] }} /><span className="truncate">{c.name}</span></span><strong className="shrink-0">{Math.round(c.value / catTotal * 100)}%</strong></li>) : <li className="text-muted-foreground">Nenhum gasto neste mês.</li>}</ul></div></section>
    </div>
    <div className="grid grid-cols-[minmax(0,3fr)_minmax(0,2fr)] gap-4">
      <section className="money-card flex h-72 flex-col rounded-2xl p-4"><h2 className="text-lg font-bold">Receitas x Despesas</h2><p className="text-xs text-muted-foreground">Últimos 6 meses</p><div className="mt-2 min-h-0 flex-1"><ResponsiveContainer width="100%" height="100%"><BarChart data={months} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}><CartesianGrid stroke="var(--border)" strokeDasharray="4 4" vertical={false} /><XAxis dataKey="mes" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} /><YAxis width={70} tickFormatter={v => money(Number(v))} tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} /><Tooltip formatter={tip} contentStyle={chartBox} cursor={{ fill: "var(--muted)", opacity: 0.3 }} /><Bar dataKey="Receitas" fill="var(--income)" radius={[6, 6, 0, 0]} /><Bar dataKey="Despesas" fill="var(--destructive)" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></section>
      <section className="money-card flex h-72 flex-col rounded-2xl p-4"><h2 className="text-lg font-bold">Investimentos por banco</h2><p className="text-xs text-muted-foreground">Distribuição do total aplicado</p><div className="mt-2 min-h-0 flex-1">{investedBanks.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={investedBanks.map(b => ({ name: b.name, Investido: b.invested }))} layout="vertical" margin={{ top: 4, right: 12, left: 0, bottom: 0 }}><XAxis type="number" hide /><YAxis type="category" dataKey="name" width={100} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} /><Tooltip formatter={tip} contentStyle={chartBox} cursor={{ fill: "var(--muted)", opacity: 0.3 }} /><Bar dataKey="Investido" fill="var(--reports)" radius={[0, 6, 6, 0]} /></BarChart></ResponsiveContainer> : <p className="grid h-full place-items-center text-sm text-muted-foreground">Nenhum valor investido ainda.</p>}</div></section>
    </div>
    {investedBanks.length > 0 && <section><h2 className="mb-3 flex items-center gap-2 text-lg font-bold"><Landmark size={18} className="text-[var(--reports)]" />Investimentos por banco</h2><div className="grid grid-cols-3 gap-4 xl:grid-cols-4">{investedBanks.map(b => { const thumb = cardThumbnail(b.name); return <article key={b.id} className="money-card rounded-2xl border-2 p-4 [container-type:inline-size]" style={{ borderColor: "color-mix(in oklch, var(--reports), transparent 55%)" }}><div className="flex items-center gap-3">{thumb ? <img src={thumb.image} alt={`Cartão ${thumb.label}`} loading="lazy" width={64} height={40} className="h-10 w-16 shrink-0 rounded-md border border-border object-cover" /> : <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-[var(--reports)] text-[var(--background)]"><Landmark size={20} /></span>}<strong className="min-w-0 truncate">{b.name}</strong></div><p className="financial-value-sm mt-3 font-display font-bold text-[var(--reports)]">{money(b.invested)}</p><p className="mt-1 text-xs text-muted-foreground">{b.rate > 0 ? <>Rendimento mensal ~ <strong className="text-[var(--income)]">+ {money(b.yieldMonth)}</strong> ({b.rate.toLocaleString("pt-BR")}% a.m.)</> : "Valor aplicado"}</p></article>; })}</div></section>}
    {quick === "record" && <QuickRecordModal store={store} money={money} onClose={() => setQuick(null)} onSave={r => { setQuick(null); saveRecord(r); }} />}
    {quick === "cards" && !adjustBank && <QuickCardPicker banks={store.banks.filter(b => b.status !== "Arquivado")} onClose={() => setQuick(null)} onPick={b => setAdjustBank(b)} />}
    {adjustBank && <CardAdjustModal bank={adjustBank} records={store.records} money={money} onClose={() => { setAdjustBank(null); setQuick(null); }} onBack={() => setAdjustBank(null)} onSave={b => { setAdjustBank(null); setQuick(null); saveCard(b); }} />}
  </div>;
}

const modalField = "w-full rounded-xl border border-border bg-background px-3 py-2 text-sm";
const modalLabel = "mb-1 block text-xs font-bold text-muted-foreground";

function QuickRecordModal({ store, money, onClose, onSave }: { store: PanelStore; money: (n: number) => string; onClose: () => void; onSave: (r: Rec) => void }) {
  const banks = store.banks.filter(b => b.status !== "Arquivado");
  const [title, setTitle] = useState("");
  const [type, setType] = useState<"receita" | "gasto">("gasto");
  const [paymentMethod, setPaymentMethod] = useState(financialPaymentMethods[0] ?? "Transferência");
  const [cardName, setCardName] = useState(banks.find(b => b.primary)?.name ?? banks[0]?.name ?? "Nenhum");
  const [accountType, setAccountType] = useState("Nenhum");
  const [category, setCategory] = useState(quickCategories[0] ?? "Dinheiro");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [error, setError] = useState<string | null>(null);
  const save = () => {
    const value = Math.max(0, Number(amount));
    if (!value) { setError("Informe um valor maior que zero."); return; }
    const paymentAccount = paymentMethod === "Cartão crédito" ? "Crédito" : paymentMethod === "Cartão débito" ? "Débito" : undefined;
    const bank = cardName !== "Nenhum" ? banks.find(b => b.name === cardName) : undefined;
    const finalAccount = paymentAccount ?? (accountType === "Nenhum" ? undefined : accountType);
    if (type === "gasto" && paymentAccount) {
      if (!bank) { setError(`Para pagar no ${paymentAccount}, escolha um cartão com saldo disponível.`); return; }
      const available = getCardAvailableBalance(bank, store.records, paymentAccount);
      if (value > available) { setError(`${bank.name} possui ${money(available)} disponíveis. Escolha outro cartão ou forma de pagamento.`); return; }
    }
    onSave({ id: Date.now(), title: title.trim().slice(0, 100) || "Lançamento", category, paymentMethod, amount: value, type, date, ...(finalAccount === "Crédito" || finalAccount === "Débito" ? { accountType: finalAccount as "Crédito" | "Débito" } : {}), ...(bank ? { cardId: bank.id, cardName: bank.name } : {}) });
  };
  return createPortal(<div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-background/80 p-2 pt-1 backdrop-blur" onClick={onClose}>
    <div role="dialog" aria-modal="true" aria-label="Novo lançamento" className="money-card w-full max-w-md max-h-[calc(100dvh-0.5rem)] overflow-y-auto rounded-2xl p-4" onClick={e => e.stopPropagation()}>
      <h2 className="text-lg font-bold">Novo lançamento</h2>
      <div className="mt-2 flex gap-2">{(["gasto", "receita"] as const).map(t => <Button key={t} variant={type === t ? "default" : "outline"} onClick={() => setType(t)} className="flex-1" aria-pressed={type === t}>{t === "gasto" ? "GASTO" : "RECEITA"}</Button>)}</div>
      <div className="mt-2 grid gap-2">
        <div><label className={modalLabel} htmlFor="qr-title">Descrição</label><input id="qr-title" className={modalField} value={title} onChange={e => setTitle(e.target.value)} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className={modalLabel} htmlFor="qr-amount">Valor</label><input id="qr-amount" className={modalField} type="number" min="0" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} /></div>
          <div><label className={modalLabel} htmlFor="qr-date">Data</label><input id="qr-date" className={modalField} type="date" value={date} onChange={e => setDate(e.target.value)} /></div>
        </div>
        <div><label className={modalLabel} htmlFor="qr-cat">Categoria</label><select id="qr-cat" className={modalField} value={category} onChange={e => setCategory(e.target.value)}>{quickCategories.map(c => <option key={c} value={c}>{c}</option>)}</select></div>
        <div><label className={modalLabel} htmlFor="qr-pay">Forma de pagamento</label><select id="qr-pay" className={modalField} value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>{financialPaymentMethods.map(m => <option key={m} value={m}>{m}</option>)}</select></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className={modalLabel} htmlFor="qr-bank">Banco ou cartão</label><select id="qr-bank" className={modalField} value={cardName} onChange={e => setCardName(e.target.value)}><option value="Nenhum">Nenhum</option>{banks.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}</select></div>
          <div><label className={modalLabel} htmlFor="qr-acc">Aplicar em</label><select id="qr-acc" className={modalField} value={accountType} onChange={e => setAccountType(e.target.value)}>{["Nenhum", "Crédito", "Débito"].map(a => <option key={a} value={a}>{a}</option>)}</select></div>
        </div>
      </div>
      {error && <p className="mt-3 text-sm font-semibold text-destructive">{error}</p>}
      <div className="mt-4 flex justify-end gap-2"><Button variant="ghost" onClick={onClose}>Cancelar</Button><Button onClick={save}>Salvar</Button></div>
    </div>
  </div>, document.body);
}

function QuickCardPicker({ banks, onClose, onPick }: { banks: CardBank[]; onClose: () => void; onPick: (b: CardBank) => void }) {
  return <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur" onClick={onClose}>
    <div className="money-card w-full max-w-md rounded-2xl p-5" onClick={e => e.stopPropagation()}>
      <h2 className="text-lg font-bold">Escolha um cartão</h2>
      {banks.length ? <div className="mt-4 grid grid-cols-3 gap-3">{banks.map(b => { const thumb = cardThumbnail(b.name); return <button key={b.id} type="button" onClick={() => onPick(b)} aria-label={b.name} title={b.name} className="grid place-items-center rounded-xl border-2 border-border p-2 transition-colors hover:border-primary/60">
        {thumb ? <img src={thumb.image} alt={thumb.label} width={96} height={60} className="h-14 w-full rounded-lg border border-border object-cover shadow-sm" /> : <span className="grid h-14 w-full place-items-center rounded-lg bg-primary/15 text-primary"><CreditCard size={28} /></span>}
      </button>; })}</div> : <p className="mt-3 text-sm text-muted-foreground">Nenhum cartão cadastrado ainda.</p>}
      <div className="mt-4 flex justify-end"><button type="button" onClick={onClose} className="rounded-xl px-4 py-2 text-sm font-bold text-muted-foreground hover:bg-muted">Fechar</button></div>
    </div>
  </div>;
}

type CardDest = "Débito" | "Crédito" | "Investimento";
function CardAdjustModal({ bank, records, money, onClose, onBack, onSave }: { bank: CardBank; records: Rec[]; money: (n: number) => string; onClose: () => void; onBack: () => void; onSave: (b: CardBank) => void }) {
  const [dest, setDest] = useState<CardDest>("Débito");
  const [mode, setMode] = useState<"add" | "set">("add");
  const [amount, setAmount] = useState("");
  const [error, setError] = useState<string | null>(null);
  const creditNow = getCardAvailableBalance(bank, records, "Crédito");
  const debitNow = getCardAvailableBalance(bank, records, "Débito");
  const thumb = cardThumbnail(bank.name);
  const save = () => {
    const value = Math.max(0, Number(amount));
    if (!value) { setError("Informe um valor maior que zero."); return; }
    const apply = (current: number) => Math.max(0, Math.round((mode === "add" ? current + value : value) * 100) / 100);
    const next: CardBank = { ...bank };
    if (dest === "Investimento") next.invested = apply(bank.invested ?? 0);
    else {
      const creditNew = dest === "Crédito" ? apply(creditNow) : creditNow;
      const debitNew = dest === "Débito" ? apply(debitNow) : debitNow;
      next.desiredBalances = { creditLimit: creditNew, debitBalance: debitNew };
      next.creditLimit = creditNew; next.debitBalance = debitNew;
    }
    onSave(next);
  };
  const destBtn = (d: CardDest) => <button key={d} type="button" onClick={() => setDest(d)} className={`rounded-xl border-2 px-3 py-2 text-sm font-bold ${dest === d ? "border-primary bg-primary text-primary-foreground" : "border-border"}`}>{d}</button>;
  return <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur" onClick={onClose}>
    <div className="money-card w-full max-w-md rounded-2xl p-5" onClick={e => e.stopPropagation()}>
      <div className="flex items-center gap-3">{thumb ? <img src={thumb.image} alt={thumb.label} width={96} height={60} className="h-14 w-24 rounded-lg border border-border object-cover shadow-sm" /> : <span className="grid size-12 place-items-center rounded-xl bg-primary/15 text-primary"><CreditCard size={24} /></span>}<h2 className="min-w-0 truncate text-lg font-bold">{bank.name}</h2></div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
        <div className="rounded-xl bg-muted/40 p-2"><span className="block font-bold text-muted-foreground">Débito</span><strong>{money(debitNow)}</strong></div>
        <div className="rounded-xl bg-muted/40 p-2"><span className="block font-bold text-muted-foreground">Crédito</span><strong>{money(creditNow)}</strong></div>
        <div className="rounded-xl bg-muted/40 p-2"><span className="block font-bold text-muted-foreground">Investido</span><strong>{money(bank.invested ?? 0)}</strong></div>
      </div>
      <div className="mt-3"><label className={modalLabel} htmlFor="ca-amount">Valor</label><input id="ca-amount" className={modalField} type="number" min="0" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} /></div>
      <div className="mt-3"><span className={modalLabel}>Lançar em</span><div className="grid grid-cols-3 gap-2">{destBtn("Débito")}{destBtn("Crédito")}{destBtn("Investimento")}</div></div>
      <div className="mt-3"><span className={modalLabel}>Tipo de lançamento</span><div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => setMode("add")} className={`rounded-xl border-2 px-3 py-2 text-sm font-bold ${mode === "add" ? "border-primary bg-primary text-primary-foreground" : "border-border"}`}>+ Adicionar valor</button>
        <button type="button" onClick={() => setMode("set")} className={`rounded-xl border-2 px-3 py-2 text-sm font-bold ${mode === "set" ? "border-primary bg-primary text-primary-foreground" : "border-border"}`}>✏️ Editar valor</button>
      </div></div>
      {error && <p className="mt-3 text-sm font-semibold text-destructive">{error}</p>}
      <div className="mt-4 flex justify-between"><button type="button" onClick={onBack} className="rounded-xl px-4 py-2 text-sm font-bold text-muted-foreground hover:bg-muted">← Voltar</button><div className="flex gap-2"><button type="button" onClick={onClose} className="rounded-xl px-4 py-2 text-sm font-bold text-muted-foreground hover:bg-muted">Cancelar</button><button type="button" onClick={save} className="rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground">Salvar</button></div></div>
    </div>
  </div>;
}
