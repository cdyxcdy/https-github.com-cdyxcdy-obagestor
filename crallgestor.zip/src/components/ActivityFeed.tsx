import { useEffect, useState } from 'react';
import { Settings, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useInbox } from '@/lib/inbox';
import { notificationOptions, type NotificationSettings } from '@/lib/notification-settings';
import { notificationVisible, NOTIFICATION_ROTATION_MS } from '@/lib/activity-feed';

export function RisingMessages({ messages, interval = NOTIFICATION_ROTATION_MS, empty }: { messages: { id: string; title?: string; body: string }[]; interval?: number; empty: string }) {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    if (messages.length < 2) return;
    const timer = window.setInterval(() => setIndex(value => (value + 1) % messages.length), interval);
    return () => window.clearInterval(timer);
  }, [messages.length, interval]);
  const active = messages.length ? index % messages.length : 0;
  return <div className="rising-messages" aria-live="off">
    {messages.length ? messages.map((message, i) => <div key={message.id} className={i === active ? 'rising-message is-active' : 'rising-message'} aria-hidden={i !== active}>
      {message.title && <strong className="mb-1 block text-sm">{message.title}</strong>}
      <p className="text-sm leading-relaxed text-muted-foreground">{message.body}</p>
    </div>) : <p className="text-sm leading-relaxed text-muted-foreground">{empty}</p>}
  </div>;
}

export function SidebarNotifications({ userId, settings, save, isAdmin }: { userId: string; settings: NotificationSettings; save: (settings: NotificationSettings) => void; isAdmin: boolean }) {
  const inbox = useInbox(userId);
  const [editing, setEditing] = useState(false);
  const messages = inbox.filter(message => notificationVisible(message.title, settings));
  return <section className="sidebar-notifications money-card my-3 w-full min-w-0 rounded-xl p-3" aria-label="Avisos do sistema">
    <div className="mb-2 flex items-center justify-between gap-2"><h2 className="text-sm font-bold">Notificações</h2><Button variant="icon" size="icon" className="size-8 min-h-8 shrink-0" aria-label={editing ? 'Fechar escolhas de notificações' : 'Escolher notificações'} title="Escolher notificações" onClick={() => setEditing(value => !value)}>{editing ? <X size={16}/> : <Settings size={16}/>}</Button></div>
    {editing ? <div className="max-h-64 space-y-2 overflow-y-auto" role="group" aria-label="Categorias de aviso">{notificationOptions.filter(option => isAdmin || !option.admin).map(option => <label key={option.key} className="flex items-start gap-2 text-xs leading-relaxed"><input type="checkbox" className="mt-0.5 size-4 shrink-0 accent-primary" checked={settings[option.key]} onChange={event => save({ ...settings, [option.key]: event.target.checked, receitasGastos: false })}/><span className="min-w-0 break-words">{option.label}</span></label>)}</div> : <RisingMessages messages={messages} empty="Nenhum aviso ativo no momento."/>}
  </section>;
}