import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export const buttonVariants = cva(
  "inline-flex min-h-10 items-center justify-center gap-2 rounded-lg px-4 text-sm font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 active:translate-y-0.5",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow-[0_4px_0_var(--primary-shadow),0_10px_24px_var(--primary-glow)] hover:-translate-y-0.5 hover:shadow-[0_6px_0_var(--primary-shadow),0_14px_30px_var(--primary-glow)]",
        primary: "bg-primary text-primary-foreground shadow-[0_4px_0_var(--primary-shadow),0_10px_24px_var(--primary-glow)] hover:-translate-y-0.5 hover:shadow-[0_6px_0_var(--primary-shadow),0_14px_30px_var(--primary-glow)]",
        secondary: "border border-border/80 bg-card/80 text-foreground shadow-sm backdrop-blur-xl hover:-translate-y-0.5 hover:bg-muted",
        outline: "border border-input bg-background/70 text-foreground shadow-sm backdrop-blur-xl hover:-translate-y-0.5 hover:bg-muted",
        ghost: "text-muted-foreground hover:bg-muted hover:text-foreground",
        danger: "bg-destructive text-destructive-foreground hover:opacity-90",
        destructive: "bg-destructive text-destructive-foreground hover:opacity-90",
        link: "text-primary underline-offset-4 hover:underline",
        icon: "size-10 border-2 border-primary/60 bg-primary/10 p-0 text-primary shadow-[0_0_0_1px_var(--primary-glow)] hover:border-primary hover:bg-primary/20 hover:text-primary [&_svg]:opacity-100 [&_svg]:stroke-[2.5]",
      },
      size: {
        default: "h-10",
        sm: "h-8 min-h-8 px-3 text-xs",
        icon: "size-10 min-h-10 p-0",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  },
);

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants> & { asChild?: boolean };

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button({ className, variant, size, asChild, ...props }, ref) {
  const Comp = asChild ? Slot : "button";
  return <Comp ref={ref} className={cn(buttonVariants({ variant, size }), className)} {...props} />;
});