import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Check, Copy, Trash2, LockKeyhole, LogOut, QrCode, ShieldCheck, UserCheck, UserX, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { bootstrapAdmin, grantLicense, listUsersForLicense, setClientAccess, deleteClient, startAccountTrial } from "@/lib/license.functions";
import { supabase } from "@/integrations/supabase/client";
import qrcodeAsset from "@/assets/qr-de-30-reais.jpeg.asset.json";

const PIX_CODE = "00020126580014br.gov.bcb.pix01365b17e4bb-c68d-4b46-9514-f321f709f118520400005303986540530.005802BR5918CLAUDINEY DA SILVA6009Sao Paulo62230519daqr26676752799505563046635";

type PendingUser = { id: string; email: string; createdAt: string; licensed: boolean; suspended: boolean; isAdmin: boolean; expired: boolean; expiresAt: string | null; isTrial: boolean };

export function LicenseLock({ isAdmin, adminsExist, suspended = false, expired = false, trialAvailable = false, isTrial = false, onTrialStarted, onBecameAdmin }: { isAdmin: boolean; adminsExist: boolean; suspended?: boolean; expired?: boolean; trialAvailable?: boolean; isTrial?: boolean; onTrialStarted?: () => Promise<void>; onBecameAdmin: () => void }) {
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const runBootstrap = useServerFn(bootstrapAdmin);
  const runTrial = useServerFn(startAccountTrial);
  const beginTrial = async () => {
    setBusy(true); setMessage("");
    try { await runTrial(); await onTrialStarted?.(); }
    catch (error) { setMessage(error instanceof Error ? error.message : "Não foi possível iniciar o teste."); }
    finally { setBusy(false); }
  };

  const copyPix = async () => {
    try { await navigator.clipboard.writeText(PIX_CODE); setCopied(true); setTimeout(() => setCopied(false), 2500); }
    catch { setMessage("Não foi possível copiar. Selecione o código manualmente."); }
  };

  const becomeAdmin = async () => {
    setBusy(true); setMessage("");
    try {
      const result = await runBootstrap();
      if (result.isAdmin) onBecameAdmin();
      else setMessage("Já existe um administrador configurado.");
    } catch { setMessage("Não foi possível configurar o administrador."); }
    finally { setBusy(false); }
  };

  if (suspended) return (
    <main className="finance-dark grid min-h-dvh place-items-center px-4 text-foreground">
      <section className="w-full max-w-md text-center">
        <UserX className="mx-auto text-destructive" size={40} />
        <h1 className="mt-4 font-display text-2xl font-bold">Acesso desativado</h1>
        <p className="mt-3 text-sm text-muted-foreground">Sua conta foi desativada pelo administrador. Seus dados continuam guardados. Entre em contato com o responsável para solicitar a reativação.</p>
        <Button variant="outline" className="mt-6 gap-2" onClick={() => void supabase.auth.signOut().then(() => window.location.assign("/"))}><LogOut size={18} /> Sair da conta</Button>
      </section>
    </main>
  );

  return (
    <main className="finance-dark relative grid min-h-dvh place-items-center overflow-hidden px-4 py-8 text-foreground">
      <div aria-hidden="true" className="pointer-events-none absolute -left-24 top-10 size-72 rounded-full bg-primary/25 blur-3xl" />
      <div aria-hidden="true" className="pointer-events-none absolute -right-20 bottom-10 size-72 rounded-full bg-accent/20 blur-3xl" />
      <section className="rise-in relative w-full max-w-md">
        <div className="money-card rounded-3xl p-6 text-center">
          <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-[0_0_24px_var(--primary-glow)]"><LockKeyhole size={26} /></span>
          <h1 className="mt-4 font-display text-2xl font-bold">{expired ? isTrial ? "Teste encerrado" : "Acesso vencido" : "Acesso por 30 dias"}</h1>
          <p className="mt-2 text-sm text-muted-foreground">Para liberar seu painel completo por 30 dias, pague</p>
          <p className="mt-1 font-display text-4xl font-bold text-primary">R$ 30,00</p>

          <div className="mt-5 rounded-2xl border border-border bg-background/60 p-4">
            <p className="mb-3 flex items-center justify-center gap-2 text-sm font-bold"><QrCode size={18} className="text-primary" />Escaneie o QR Code Pix</p>
            <img src={qrcodeAsset.url} alt="QR Code Pix de R$ 30,00" className="mx-auto w-56 rounded-xl border border-border bg-white p-2" />
          </div>

          <div className="mt-4 rounded-2xl border border-border bg-background/60 p-4 text-left">
            <p className="text-sm font-bold">Ou copie o código Pix:</p>
            <p className="mt-2 break-all rounded-lg bg-muted p-2 font-mono text-[11px] text-muted-foreground">{PIX_CODE}</p>
            <Button className="mt-3 w-full gap-2" onClick={() => void copyPix()}>
              {copied ? <Check size={18} /> : <Copy size={18} />}
              {copied ? "Código copiado!" : "Copiar código Pix"}
            </Button>
          </div>

          {trialAvailable && <div className="mt-5 border-t border-border pt-5">
            <h2 className="font-display text-lg font-bold text-primary">Faça um teste de 1 hora!</h2>
            <p className="mt-1 text-sm text-foreground">Venha conhecer o sistema!</p>
            <Button variant="outline" className="mt-3 w-full" disabled={busy} onClick={() => void beginTrial()}>{busy ? "Iniciando teste…" : "CLIQUE AQUI"}</Button>
            <p className="mt-3 text-xs text-muted-foreground">Um único teste por conta, começando ao clicar. Após 1 hora, o acesso será desativado, sem apagar seus dados. Após a confirmação do pagamento, será liberado novamente por 30 dias.</p>
          </div>}
          <p className="mt-4 text-xs text-muted-foreground">Após a confirmação do pagamento pelo administrador, seu acesso fica liberado por 30 dias em todos os seus aparelhos. No vencimento, o acesso é bloqueado e seus dados continuam guardados.</p>
          {message && <p role="status" className="mt-3 text-sm text-destructive">{message}</p>}

          {!adminsExist && (
            <Button variant="outline" className="mt-4 w-full gap-2" disabled={busy} onClick={() => void becomeAdmin()}>
              <ShieldCheck size={18} /> Sou o dono do app — ativar minha conta
            </Button>
          )}
        </div>

        {isAdmin && <AdminClients />}
      </section>
    </main>
  );
}


export function AdminClients({ onCount }: { onCount?: (pending: number) => void }) {
  const [users, setUsers] = useState<PendingUser[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const loadUsers = useServerFn(listUsersForLicense);
  const runGrant = useServerFn(grantLicense);
  const runAccess = useServerFn(setClientAccess);
  const runDelete = useServerFn(deleteClient);
  const [deleteUser, setDeleteUser] = useState<PendingUser | null>(null);
  const [confirmUser, setConfirmUser] = useState<PendingUser | null>(null);
  const refreshUsers = async () => {
    try { const list = await loadUsers(); setUsers(list); onCount?.(list.filter(u => !u.licensed && !u.suspended).length); } catch { setUsers([]); setMessage("Não foi possível carregar as contas."); }
  };
  useEffect(() => { void refreshUsers(); const timer = window.setInterval(() => void refreshUsers(), 10000); return () => window.clearInterval(timer); }, []);
  const approve = async (userId: string) => {
    setBusy(true); setMessage("");
    try { await runGrant({ data: { userId } }); await refreshUsers(); }
    catch { setMessage("Não foi possível liberar esta conta."); }
    finally { setBusy(false); }
  };
  const sorted = [...(users ?? [])].sort((a, b) => Number(a.licensed) - Number(b.licensed) || b.createdAt.localeCompare(a.createdAt));
  const changeAccess = async (user: PendingUser, active: boolean) => {
    setBusy(true); setMessage("");
    try { await runAccess({ data: { userId: user.id, active } }); setConfirmUser(null); await refreshUsers(); }
    catch { setMessage("Não foi possível alterar o acesso desta conta."); }
    finally { setBusy(false); }
  };
  const pending = sorted.filter(u => !u.licensed && !u.suspended).length;
  return (
    <div className="money-card mt-4 rounded-3xl p-6 text-left">
      <h2 className="flex items-center gap-2 font-display text-lg font-bold"><Users size={20} className="text-primary" /> Clientes ({sorted.length})</h2>
      <p className="mt-1 text-xs text-muted-foreground">{pending} aguardando liberação. Confira o Pix de R$ 30,00 antes de liberar ou renovar. Cada liberação inicia 30 dias de acesso.</p>
      {message && <p role="status" className="mt-2 text-sm text-destructive">{message}</p>}
      <ul className="mt-4 max-h-[60vh] space-y-2 overflow-y-auto">
        {sorted.map(user => (
          <li key={user.id} className="flex items-center justify-between gap-2 rounded-xl border border-border bg-background/60 px-3 py-2">
            <span className="min-w-0"><span className="block truncate text-sm">{user.email}</span><small className="block text-muted-foreground">Cadastro: {new Date(user.createdAt).toLocaleDateString("pt-BR")}</small>{!user.isAdmin && user.expiresAt && <small className="block text-muted-foreground">Vencimento: {new Date(user.expiresAt).toLocaleString("pt-BR")}</small>}</span>
            <div className="flex shrink-0 flex-col items-end gap-2">
              <span className={`flex items-center gap-1 text-xs font-bold ${user.suspended || user.expired ? "text-destructive" : "text-primary"}`}>
                {user.suspended || user.expired ? <UserX size={15} /> : <UserCheck size={15} />}
                {user.isAdmin ? "Administrador" : user.suspended ? "Inativo" : user.expired ? user.isTrial ? "Teste encerrado" : "Vencido" : user.licensed ? user.isTrial ? "Em teste" : "Liberado" : "Pendente"}
              </span>
              {!user.isAdmin && <div className="flex flex-wrap justify-end gap-2">
                <Button size="sm" disabled={busy} onClick={() => void approve(user.id)}>{user.expiresAt ? "Renovar 30 dias" : "Liberar"}</Button>
                {user.licensed && <Button size="sm" variant="outline" disabled={busy} onClick={() => setConfirmUser(user)}>Desativar</Button>}
                <Button size="icon" variant="ghost" aria-label={`Excluir ${user.email}`} title="Excluir cliente" disabled={busy} onClick={() => setDeleteUser(user)}><Trash2 size={16}/></Button>
              </div>}
            </div>
          </li>
        ))}
        {users && users.length === 0 && <li className="text-sm text-muted-foreground">Nenhuma conta cadastrada ainda.</li>}
        {users === null && <li className="text-sm text-muted-foreground">Carregando contas…</li>}
      </ul>
      {deleteUser && <div role="alertdialog" aria-label="Confirmar exclusão" className="mt-4 border-t border-border pt-4">
        <p className="text-sm font-bold">Excluir {deleteUser.email} e seus dados definitivamente?</p>
        <div className="mt-3 flex gap-2">
          <Button variant="destructive" size="sm" disabled={busy} onClick={async () => {
            setBusy(true); setMessage("");
            try { await runDelete({ data: { userId: deleteUser.id } }); setDeleteUser(null); await refreshUsers(); }
            catch { setMessage("Não foi possível excluir esta conta."); }
            finally { setBusy(false); }
          }}>Confirmar exclusão</Button>
          <Button variant="outline" size="sm" disabled={busy} onClick={() => setDeleteUser(null)}>Cancelar</Button>
        </div>
      </div>}
      {confirmUser && <div role="alertdialog" aria-label="Confirmar desativação" className="mt-4 border-t border-border pt-4">
        <p className="text-sm font-bold">Desativar {confirmUser.email}?</p>
        <p className="mt-2 text-xs text-muted-foreground">O cliente perderá acesso ao app. Os dados serão preservados e você poderá reativá-lo.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant="destructive" size="sm" disabled={busy} onClick={() => void changeAccess(confirmUser, false)}>Confirmar desativação</Button>
          <Button variant="outline" size="sm" disabled={busy} onClick={() => setConfirmUser(null)}>Cancelar</Button>
        </div>
      </div>}
    </div>
  );
}
