import { Edit3, Trash2 } from 'lucide-react';
import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import type { TasksState } from '@/lib/tasks-schema';

type Purchase = TasksState['purchases'][number];
const money = (value: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

export function ShoppingRecords({ rows, vehicleName, onEdit, onRemove, onToggle }: {
  rows: Purchase[];
  vehicleName: (id: number) => string;
  onEdit: (row: Purchase) => void;
  onRemove: (row: Purchase) => void;
  onToggle: (row: Purchase) => void;
}) {
  const [desktop, setDesktop] = useState(false);
  const hold = useRef<{timer: ReturnType<typeof setTimeout>; x: number; y: number} | null>(null);
  const cancelHold = () => {
    if (hold.current) clearTimeout(hold.current.timer);
    hold.current = null;
  };
  useEffect(() => cancelHold, []);
  useEffect(() => {
    const media = window.matchMedia('(min-width: 768px)');
    const update = () => { cancelHold(); setDesktop(media.matches); };
    update();
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);
  const startHold = (event: PointerEvent<HTMLTableRowElement>, row: Purchase) => {
    cancelHold();
    if (window.matchMedia('(min-width: 768px)').matches || !event.isPrimary || event.button !== 0 || (event.target instanceof Element && event.target.closest('button'))) return;
    // Keep the gesture attached to the row while a finger drifts between cells.
    if (event.pointerType === 'touch') event.currentTarget.setPointerCapture?.(event.pointerId);
    hold.current = {x: event.clientX, y: event.clientY, timer: setTimeout(() => {
      hold.current = null;
      onToggle(row);
    }, 1000)};
  };
  if (!rows.length) return <p className="py-8 text-center text-sm text-muted-foreground">Nenhum produto na lista de compras</p>;
  return <div className="shopping-sheet-scroll" role="region" aria-label="Lista de produtos" tabIndex={0}>
    <table className="shopping-sheet">
      <thead><tr>{desktop && <th scope="col" className="shopping-check"><span className="sr-only">Comprada</span></th>}<th scope="col" className="shopping-product">Nome do produto</th><th scope="col" className="shopping-condition">Novo / usado</th><th scope="col" className="shopping-origin">Original / paralelo</th><th scope="col" className="shopping-vehicle">Veículo</th><th scope="col" className="shopping-money">Valor da peça</th><th scope="col" className="shopping-money">Mão de obra</th><th scope="col">Ações</th></tr></thead>
      <tbody>{rows.map(row => <tr key={row.id} className="shopping-row" data-purchased={!!row.purchased} tabIndex={0} aria-label={`${row.product}: ${row.purchased ? 'Comprada' : 'Pendente'}`} title={row.purchased ? 'Comprada' : 'Pendente'} onPointerDown={event => startHold(event, row)} onPointerUp={cancelHold} onPointerCancel={cancelHold} onPointerLeave={event => {if (event.pointerType !== 'touch') cancelHold();}} onBlur={event => {if (!event.currentTarget.contains(event.relatedTarget)) cancelHold();}} onPointerMove={event => {if (hold.current && Math.hypot(event.clientX - hold.current.x, event.clientY - hold.current.y) > 16) cancelHold();}} onContextMenu={event => event.preventDefault()} onKeyDown={event => {if (event.target === event.currentTarget && !event.repeat && (event.key === 'Enter' || event.key === ' ')) {event.preventDefault();onToggle(row);}}}>
        {desktop && <td className="shopping-check"><Checkbox checked={!!row.purchased} aria-label={`Marcar ${row.product} como comprada`} onCheckedChange={() => onToggle(row)}/></td>}
        <td data-label="Nome do produto">{row.product}</td><td data-label="Novo / usado">{row.condition}</td><td data-label="Original / paralelo">{row.origin}</td><td data-label="Veículo">{vehicleName(row.vehicleId)}</td><td data-label="Valor da peça" className="shopping-money">{money(row.partCost)}</td><td data-label="Mão de obra" className="shopping-money">{money(row.laborCost)}</td>
        <td><div className="shopping-actions"><Button variant="icon" size="icon" title="Editar produto" aria-label={`Editar ${row.product}`} onClick={() => onEdit(row)}><Edit3 size={16}/></Button><Button variant="icon" size="icon" className="text-destructive" title="Excluir produto" aria-label={`Excluir ${row.product}`} onClick={() => onRemove(row)}><Trash2 size={16}/></Button></div></td>
      </tr>)}</tbody>
    </table>
  </div>;
}