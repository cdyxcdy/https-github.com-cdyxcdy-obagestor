import { Children, isValidElement, useEffect, useState, type ReactNode, type FormEvent } from 'react';
import { Car, Users, Wrench, ArrowDownLeft, ArrowUpRight, ArrowUpRight as OpenArrow, Plus, Edit3, Trash2, Check, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { TasksWindow } from './TasksWindow';
import { ShoppingRecords } from './ShoppingRecords';
import { VehiclePhoto, VehiclePhotoEditor } from './VehiclePhoto';
import { emptyTasks, tasksSchema, taskAccountSchema, vehicleSchema, vehiclesActiveFirst, addVehicleKm, reactivateVehicle, vehicleKmWarning, driverSchema, maintenanceSchema, purchaseSchema, fuelSchema, fuelMetrics, maintenanceStatus, type TasksState } from '@/lib/tasks-schema';

type Section = keyof TasksState;
type Row = TasksState[Section][number];
type Field = { key: string; label: string; type?: string; options?: { value: string; label: string }[]; optional?: boolean };
const money = (n: number) => new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);
const num = (n: number) => new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2}).format(n);
const today = () => new Date().toLocaleDateString('sv-SE');
const titles: Record<Section,string> = { accounts:'Contas', vehicles:'Veículos', drivers:'Motoristas', maintenance:'Manutenção', fuel:'Combustível e KM', purchases:'Orçamentos de peças' };
const singular: Record<Section,string> = { accounts:'conta', vehicles:'veículo', drivers:'motorista', maintenance:'manutenção', fuel:'abastecimento', purchases:'produto' };
const schemas = {accounts:taskAccountSchema,vehicles:vehicleSchema,drivers:driverSchema,maintenance:maintenanceSchema,fuel:fuelSchema,purchases:purchaseSchema};
const columnLabels: Record<Section, string[]> = {
 accounts: ['Descrição', 'Valor', 'Vencimento', 'Situação / pessoa'],
 drivers: ['Motorista', 'Telefone / CNH', 'Vencimento CNH', 'Status'],
 vehicles: ['Foto', 'Veículo / placa', 'Tipo', 'Odômetro', 'KM final', 'Motorista', 'Status'],
 maintenance: ['Serviço', 'Veículo / data', 'KM / custo', 'Status'],
 purchases: ['Nome do produto', 'Novo / usado', 'Original / paralelo', 'Veículo', 'Valor da peça', 'Mão de obra'],
 fuel: ['Veículo', 'Data / motorista', 'Quilometragem', 'Consumo'],
};

export function TasksManager({value,onChange}:{value:Partial<TasksState>|undefined;onChange:(next:TasksState)=>void}) {
 const data:TasksState={
  accounts:value?.accounts??emptyTasks.accounts,
  drivers:value?.drivers??emptyTasks.drivers,
  vehicles:value?.vehicles??emptyTasks.vehicles,
  maintenance:value?.maintenance??emptyTasks.maintenance,
  fuel:value?.fuel??emptyTasks.fuel,
  purchases:value?.purchases??emptyTasks.purchases,
 };
 const [fleetSection,setFleetSection]=useState<Section|null>(null);
 const section:Section=fleetSection??'accounts';
  const openSection=(next:Section)=>setFleetSection(next);
  const [accountFilter,setAccountFilter]=useState('A pagar');
 const [editing,setEditing]=useState<{section:Section;row?:Row;focusField?:string;fieldKeys?:string[]}|null>(null);
 const [removing,setRemoving]=useState<Row|null>(null);
 const [deactivating,setDeactivating]=useState<TasksState['vehicles'][number]|null>(null);
 const [photoVehicle,setPhotoVehicle]=useState<TasksState['vehicles'][number]|null>(null);
 const [draftPhoto,setDraftPhoto]=useState<string|null>(null);
 const [photoBusy,setPhotoBusy]=useState(false);
 useEffect(()=>{setDraftPhoto(null);setPhotoBusy(false)},[editing]);
 const [finalKm,setFinalKm]=useState('');
 const [error,setError]=useState('');
 const [desktop,setDesktop]=useState(false);
 useEffect(()=>{const media=window.matchMedia('(min-width:768px)');const update=()=>setDesktop(media.matches);update();media.addEventListener('change',update);return()=>media.removeEventListener('change',update)},[]);
 const editableCells=(section:Section,row:Row,children:ReactNode)=>{
  if(section==='drivers'||!desktop||section==='accounts')return children;
  const keys:Partial<Record<Section,string[]>>={vehicles:['name','kind','odometer','finalKm','driverId','name'],drivers:['name','phone','licenseDue','name'],maintenance:['title','vehicleId','dueKm','title']};
  const cells=isValidElement<{children:ReactNode}>(children)?children.props.children:children;
  return Children.map(cells,(child,index)=>{
   if(!isValidElement(child))return child;
   if((section==='vehicles'&&(index===2||index===3||index===5))||(section==='maintenance'&&index!==0))return child;
   const fieldKey=keys[section]?.[index]??'name';
   const edit=()=>{setError('');setEditing({section,row,focusField:fieldKey,...(section==='vehicles'?{fieldKeys:index===0?['name','plate']:[fieldKey]}:{})})};
   return <Button asChild variant="ghost" className="fleet-edit-cell" role="button" tabIndex={0} title="Editar informação" onClick={edit} onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();edit()}}}>{child}</Button>;
  });
 };
 const vehicleName=(id:number)=>data.vehicles.find(v=>v.id===id)?.name??'Veículo removido';
 const driverName=(id:number|null)=>data.drivers.find(v=>v.id===id)?.name??'Sem motorista';
 const vehicleOptions=data.vehicles.map(v=>({value:String(v.id),label:`${v.name} · ${v.plate}`}));
 const driverOptions=[{value:'',label:'Nenhum'},...data.drivers.map(v=>({value:String(v.id),label:v.name}))];
 const fields:Record<Section,Field[]>={
   purchases:[{key:'product',label:'Nome do produto'},{key:'condition',label:'Novo ou usado',options:['Novo','Usado'].map(v=>({value:v,label:v}))},{key:'origin',label:'Original ou paralelo',options:['Original','Paralelo'].map(v=>({value:v,label:v}))},{key:'vehicleId',label:'Para qual veículo',options:vehicleOptions},{key:'partCost',label:'Valor da peça (R$)',type:'number'},{key:'laborCost',label:'Valor da mão de obra (R$)',type:'number'}],
   accounts:[{key:'title',label:'Descrição'},{key:'amount',label:'Valor (R$)',type:'number'},{key:'dueDate',label:'Vencimento',type:'date'},{key:'person',label:'Pessoa ou empresa',optional:true}],
  vehicles:[{key:'name',label:'Nome / modelo'},{key:'plate',label:'Placa'},{key:'kind',label:'Tipo de veículo',options:['Carro de passeio','Caminhonete','Moto'].map(v=>({value:v,label:v}))},{key:'odometer',label:'Odômetro',type:'number'},...(editing?.section==='vehicles'&&editing.row?[{key:'finalKm',label:'KM final',type:'number',optional:true}]:[]),{key:'driverId',label:'Motorista',options:driverOptions,optional:true}],
  drivers:[{key:'name',label:'Nome'},{key:'phone',label:'Telefone',type:'tel',optional:true},{key:'license',label:'CNH',optional:true},{key:'licenseDue',label:'Vencimento da CNH',type:'date',optional:true},{key:'active',label:'Status',options:[{value:'true',label:'Ativo'},{value:'false',label:'Inativo'}]}],
  maintenance:[{key:'vehicleId',label:'Veículo',options:vehicleOptions},{key:'title',label:'Serviço'},{key:'dueDate',label:'Data agendada / vencimento',type:'date'},{key:'dueKm',label:'Vencimento em KM',type:'number',optional:true},{key:'cost',label:'Custo previsto (R$)',type:'number'}],
  fuel:[{key:'vehicleId',label:'Veículo',options:vehicleOptions},{key:'driverId',label:'Motorista',options:driverOptions,optional:true},{key:'date',label:'Data',type:'date'},{key:'startKm',label:'KM inicial',type:'number'},{key:'endKm',label:'KM final',type:'number'},{key:'liters',label:'Litros consumidos',type:'number'},{key:'price',label:'Preço por litro (R$)',type:'number'}]
 };
 const initial:Record<Section,Record<string,unknown>>={accounts:{kind:accountFilter==='A receber'||accountFilter==='Recebidas'?'Receber':'Pagar',amount:0,dueDate:today(),person:'',settled:false},vehicles:{kind:'Carro de passeio',odometer:0,driverId:null,active:true},drivers:{phone:'',license:'',licenseDue:'',active:true},maintenance:{vehicleId:data.vehicles[0]?.id,title:'',dueDate:today(),dueKm:null,cost:0,completed:false},purchases:{product:'',condition:'Novo',origin:'Original',vehicleId:data.vehicles[0]?.id,partCost:0,laborCost:0},fuel:{vehicleId:data.vehicles[0]?.id,driverId:null,date:today(),startKm:0,endKm:0,liters:0,price:0}};
 const editFields=editing?.fieldKeys?fields[editing.section].filter(field=>editing.fieldKeys?.includes(field.key)):editing?fields[editing.section]:[];
 const editTitle=editing?.fieldKeys?.includes('photoPath')?'Editar foto do veículo':editing?.fieldKeys?`Editar ${editFields.map(field=>field.label).join(' / ')}`:editing?`${editing.row?'Editar':'Adicionar'} ${singular[editing.section]}`:'';
 const save=(event:FormEvent<HTMLFormElement>)=>{
  event.preventDefault();if(!editing||photoBusy)return;
  const entries=Object.fromEntries(new FormData(event.currentTarget));
  const currentVehicle=editing.section==='vehicles'?data.vehicles.find(vehicle=>vehicle.id===editing.row?.id):undefined;
  const next:Record<string,unknown>={...initial[editing.section],...(currentVehicle??editing.row),id:editing.row?.id??Date.now()};
  for(const field of editFields){const val=String(entries[field.key]??'').trim();if(editing.section==='vehicles'&&field.key==='finalKm')continue;next[field.key]=field.key==='active'?val==='true':field.type==='number'||field.key.endsWith('Id')?(val===''&&field.optional?null:Number(val)):val;}
  if(editing.section==='vehicles'){
   next['plate']=String(next['plate']).toUpperCase();if(draftPhoto)next['photoPath']=draftPhoto;
   const distance=String(entries['finalKm']??'').trim();
   if(distance){
    const base=vehicleSchema.safeParse(next);
    if(!base.success){setError('Confira os campos do veículo.');return;}
    try{Object.assign(next,addVehicleKm(base.data,Number(distance)))}catch(cause){setError(cause instanceof Error?cause.message:'Confira o KM final.');return;}
   }
  }
  const parsed=schemas[editing.section].safeParse(next);
  if(!parsed.success){setError(parsed.error.issues[0]?.message??'Confira os campos.');return;}
  const updated={...data,[editing.section]:[...data[editing.section].filter(r=>r.id!==next['id']),parsed.data]};
  const valid=tasksSchema.safeParse(updated);if(!valid.success){setError('Confira os valores informados.');return;}
  onChange(valid.data);setEditing(null);setError('');
 };
 const change=(key:Section,row:Row)=>onChange({...data,[key]:data[key].map(item=>item.id===row.id?row:item)} as TasksState);
 const toggleActive=(row:TasksState['vehicles'][number]|TasksState['drivers'][number])=>{
  if('plate'in row){
   if(row.active){setError('');setFinalKm('');setDeactivating(row);}
   else {change('vehicles',reactivateVehicle(row));setError('')}
  }else change('drivers',{...row,active:!row.active});
 };
 const deactivateVehicle=(event:FormEvent<HTMLFormElement>)=>{
  event.preventDefault();if(!deactivating)return;
  if(!finalKm.trim()){setError('Informe o KM final.');return;}
  const parsed=vehicleSchema.safeParse({...deactivating,finalKm:Number(finalKm),active:false});
  if(!parsed.success){setError('Informe um KM final válido, entre 0 e 1.000.000.000.');return;}
  const current=data.vehicles.find(vehicle=>vehicle.id===deactivating.id);
  if(!current){setError('Este veículo não está mais cadastrado.');return;}
  const warning=vehicleKmWarning({...current,finalKm:parsed.data.finalKm});
  if(warning){setError(warning);return;}
  change('vehicles',{...addVehicleKm(current,Number(finalKm)),active:false});
  setDeactivating(null);setError('');
 };
 const remove=()=>{if(!removing)return;let next={...data,[section]:data[section].filter(r=>r.id!==removing.id)} as TasksState;if(section==='drivers')next={...next,vehicles:next.vehicles.map(v=>v.driverId===removing.id?{...v,driverId:null}:v),fuel:next.fuel.map(v=>v.driverId===removing.id?{...v,driverId:null}:v)};onChange(next);setRemoving(null);};
 const accountGroups=[
  {label:'A pagar',kind:'Pagar',settled:false,icon:ArrowUpRight,tone:'text-[var(--income)]'},
  {label:'Pagas',kind:'Pagar',settled:true,icon:Check,tone:'text-[var(--income)]'},
  {label:'A receber',kind:'Receber',settled:false,icon:ArrowDownLeft,tone:'text-[var(--income)]'},
  {label:'Recebidas',kind:'Receber',settled:true,icon:Check,tone:'text-[var(--income)]'},
 ] as const;
 const selectedGroup=accountGroups.find(group=>group.label===accountFilter);
 const blockedDelete=section==='vehicles'&&!!removing&&(data.maintenance.some(r=>r.vehicleId===removing.id)||data.fuel.some(r=>r.vehicleId===removing.id)||data.purchases.some(r=>r.vehicleId===removing.id));
 const renderRecords=(section:Section)=>{
    if(section==='purchases')return <ShoppingRecords rows={data.purchases} vehicleName={vehicleName} onToggle={row=>change('purchases',{...row,purchased:!row.purchased})} onEdit={row=>{setError('');setEditing({section,row})}} onRemove={setRemoving}/>;
  const rows=section==='accounts'?data.accounts.filter(a=>selectedGroup&&a.kind===selectedGroup.kind&&a.settled===selectedGroup.settled).sort((a,b)=>Number(a.settled)-Number(b.settled)||a.dueDate.localeCompare(b.dueDate)):section==='vehicles'?vehiclesActiveFirst(data.vehicles):data[section];
 return <>
  {error&&section==='vehicles'&&!deactivating&&!editing&&<p role="alert" className="text-sm text-destructive">{error}</p>}
  {!rows.length&&<p className="py-8 text-center text-sm text-muted-foreground">{(section==='maintenance'||section==='fuel')&&!data.vehicles.length?'Nenhum veículo cadastrado':`Nenhum registro em ${titles[section].toLowerCase()}`}</p>}
    <div className="task-sheet-scroll" role="region" aria-label={`Registros de ${titles[section]}`} tabIndex={0}><div data-fleet={section!=='accounts'} data-fleet-section={section} className="task-records grid gap-4">{rows.length>0&&<div className="task-sheet-header" aria-hidden="true">{columnLabels[section].map(label=><span key={label}>{label}</span>)}<span>{desktop&&section!=='accounts'?'Ações':'Editar / excluir'}</span>{section==='accounts'&&<span>Ação</span>}</div>}{rows.map(row=><article key={row.id} className="task-record min-w-0 rounded-lg border border-border"><div className="task-record-layout"><div className="task-record-content min-w-0 space-y-2">
   {'kind'in row&&'amount'in row&&<><h3 className="break-words font-bold">{row.title}</h3><p className="task-record-amount text-lg font-bold">{money(row.amount)}</p><p className="text-sm text-muted-foreground">A {row.kind.toLowerCase()} · {row.dueDate.split('-').reverse().join('/')}</p><p className={row.settled?'text-primary':row.dueDate<today()?'text-destructive':'text-muted-foreground'}>{row.settled?(row.kind==='Pagar'?'Paga':'Recebida'):row.dueDate<today()?'Vencida':'Pendente'}{row.person&&` · ${row.person}`}</p></>}
    {'plate'in row&&<Button variant="ghost" className="vehicle-photo-button" aria-label={row.photoPath?`Abrir foto de ${row.name}`:`Adicionar foto de ${row.name}`} title={row.photoPath?'Abrir foto':'Adicionar foto'} onClick={()=>{if(row.photoPath)setPhotoVehicle(row);else{setError('');setEditing({section:'vehicles',row,fieldKeys:['photoPath']})}}}><VehiclePhoto path={row.photoPath} name={row.name}/></Button>}
    {'plate'in row&&editableCells(section,row,<><h3 className="break-words font-bold">{row.name}<span className="task-plate">{row.plate}</span></h3><p className="text-sm text-muted-foreground">{row.kind}</p><p className="text-sm"><Button variant="ghost" className="h-auto min-h-0 gap-0 rounded-none p-0 text-inherit underline decoration-border underline-offset-4 transition-none active:translate-y-0" aria-label={`Editar odômetro de ${row.name}`} title="Editar odômetro" onClick={()=>{setError('');setEditing({section:'vehicles',row,focusField:'odometer',fieldKeys:['odometer']})}}><span className="vehicle-km-label">Odômetro: </span>{num(row.odometer)} km</Button></p><p className="text-sm font-bold"><Button variant="ghost" className="h-auto min-h-0 gap-0 rounded-none p-0 text-inherit underline decoration-border underline-offset-4 transition-none active:translate-y-0" aria-label={`Editar KM final de ${row.name}`} title="Editar KM final" onClick={()=>{setError('');setEditing({section:'vehicles',row,focusField:'finalKm',fieldKeys:['finalKm']})}}><span className="vehicle-km-label">KM final: </span>{row.finalKm==null?'—':`${num(row.finalKm)} km`}</Button></p><p className="text-sm">{driverName(row.driverId)}</p><Button asChild variant="ghost" className="fleet-status fleet-status-toggle" role="button" tabIndex={0} onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();toggleActive(row)}}} title={row.active?'Desativar':'Ativar'} onClick={()=>toggleActive(row)}><p data-status={row.active?'Ativo':'Inativo'}>{row.active?'Ativo':'Inativo'}</p></Button></>)}
     {'license'in row&&<><Button variant="ghost" className="fleet-edit-cell h-auto justify-start whitespace-normal text-left" title="Editar motorista" aria-label={`Editar motorista ${row.name}`} onClick={()=>{setError('');setEditing({section:'drivers',row,focusField:'name'})}}><span className="break-words font-bold">{row.name}</span></Button><p className="break-words text-sm text-muted-foreground"><span className="fleet-cell-line">{row.phone||'Sem telefone'}</span><span className="fleet-cell-line">CNH: {row.license||'Não informada'}</span></p><p className={row.licenseDue&&row.licenseDue<today()?'text-destructive':'text-muted-foreground'}>{row.licenseDue?row.licenseDue.split('-').reverse().join('/'):'Não informado'}</p><Button variant="ghost" className="fleet-status fleet-status-toggle" data-status={row.active?'Ativo':'Inativo'} title={row.active?'Desativar motorista':'Ativar motorista'} onClick={()=>toggleActive(row)}>{row.active?'Ativo':'Inativo'}</Button></>}
     {'completed'in row&&editableCells(section,row,<><h3 className="break-words font-bold">{row.title}</h3><p className="text-sm text-muted-foreground"><span className="fleet-cell-line">{vehicleName(row.vehicleId)}</span><span className="fleet-cell-line">{row.dueDate.split('-').reverse().join('/')}</span></p><p className="text-sm">{row.dueKm!==null&&<span className="fleet-cell-line">{num(row.dueKm)} km</span>}<span className="fleet-cell-line">{money(row.cost)}</span></p><Button variant="ghost" className="fleet-status fleet-status-toggle" data-status={maintenanceStatus(row,data.vehicles.find(v=>v.id===row.vehicleId)?.odometer??0,today())} title={row.completed?'Reabrir manutenção':'Concluir manutenção'} onClick={()=>change('maintenance',{...row,completed:!row.completed})}>{maintenanceStatus(row,data.vehicles.find(v=>v.id===row.vehicleId)?.odometer??0,today())}</Button></>)}
    {'liters'in row&&<><h3 className="break-words font-bold">{vehicleName(row.vehicleId)}</h3><p className="text-sm text-muted-foreground">{row.date.split('-').reverse().join('/')} · {driverName(row.driverId)}</p><p className="text-sm">{num(row.startKm)} → {num(row.endKm)} km</p><p className="text-sm">{num(row.liters)} L × {money(row.price)}</p><p className="font-bold">{money(fuelMetrics(row).cost)} · {num(fuelMetrics(row).kmPerLiter)} km/L</p><p className="text-sm">{num(fuelMetrics(row).distance)} km · {money(fuelMetrics(row).costPerKm)}/km</p></>}
  </div><div className="task-record-actions flex shrink-0 gap-3">{(section==='accounts'||(!desktop&&section!=='drivers'))&&<Button variant="icon" size="icon" title="Editar registro" aria-label={`Editar ${singular[section]}`} onClick={()=>{setError('');setEditing({section,row})}}><Edit3 size={16}/></Button>}<Button variant="icon" size="icon" className="text-destructive" title="Excluir registro" aria-label={`Excluir ${singular[section]}`} onClick={()=>setRemoving(row)}><Trash2 size={16}/></Button></div></div>
  {'settled'in row&&<Button className="task-record-toggle mt-4" size="sm" variant="secondary" onClick={()=>change('accounts',{...row,settled:!row.settled})}><Check size={16}/>{row.settled?'Reabrir':row.kind==='Pagar'?'Marcar como paga':'Marcar como recebida'}</Button>}
   
   </article>)}</div></div>
    </>;
 };
 return <section className="tasks-manager space-y-6 border-t border-border pt-6">
  <nav aria-label="Áreas de tarefas" className="fleet-navigation">{([{key:'drivers',icon:Users},{key:'vehicles',icon:Car},{key:'maintenance',icon:Wrench},{key:'purchases',icon:ShoppingCart}] as const).map(({key,icon:Icon})=><Button key={key} variant="secondary" className={`fleet-tab fleet-${key}`} aria-label={titles[key]} aria-pressed={fleetSection===key} onClick={()=>openSection(key)}><span className="fleet-tab-top"><span className="fleet-tab-icon"><Icon size={24}/></span><OpenArrow className="fleet-tab-arrow" size={18}/></span><span className="fleet-tab-bottom"><span className="fleet-tab-title">{titles[key]}</span><span className="fleet-tab-count">{data[key].length}</span></span></Button>)}</nav>
   <div aria-label="Totais das contas" className="tasks-totals grid grid-cols-2 gap-3 border-b border-border pb-6">{accountGroups.map(({label,kind,settled,icon:Icon,tone})=><Button key={label} variant="secondary" aria-label={`Ver contas ${label.toLowerCase()}`} aria-pressed={accountFilter===label} onClick={()=>{openSection('accounts');setAccountFilter(label)}} className="task-total h-auto min-w-0 flex-col items-start gap-3 text-left"><span className="task-total-label flex w-full min-w-0 items-center justify-between gap-2"><span>{label}</span><Icon size={18}/></span><strong data-account-total={label} className={`task-total-value block w-full font-display ${tone}`}>{money(data.accounts.filter(a=>a.kind===kind&&a.settled===settled).reduce((s,a)=>s+a.amount,0))}</strong></Button>)}</div>
   {fleetSection&&<TasksWindow wide title={fleetSection==='accounts'?accountFilter:titles[fleetSection]} onClose={()=>setFleetSection(null)}><div className="space-y-5"><div className="flex justify-end"><Button disabled={(fleetSection==='maintenance'||fleetSection==='purchases')&&!data.vehicles.length} onClick={()=>{setError('');setEditing({section:fleetSection})}}><Plus size={16}/>Adicionar {singular[fleetSection]}</Button></div>{fleetSection==='purchases'&&!data.vehicles.length&&<p className="text-sm text-muted-foreground">Cadastre um veículo para adicionar produtos.</p>}{renderRecords(fleetSection)}</div></TasksWindow>}
  {editing&&<TasksWindow initialFocusName={editing.focusField} title={editTitle} onClose={()=>setEditing(null)}><form onSubmit={save}><div className="grid gap-4">{editing.section==='vehicles'&&(!editing.fieldKeys||editing.fieldKeys.includes('photoPath'))&&<VehiclePhotoEditor path={draftPhoto??(editing.row&&'photoPath'in editing.row?editing.row.photoPath:undefined)} onChange={setDraftPhoto} onBusy={setPhotoBusy}/>}{editFields.map(field=>{const values={...initial[editing.section],...editing.row} as Record<string,unknown>;return <label className="text-sm font-semibold" key={field.key}>{field.label}{field.options?<select name={field.key} defaultValue={editing.section==='vehicles'&&field.key==='finalKm'?'':String(values[field.key]??'')} required={!field.optional} className="mt-1 w-full min-w-0 rounded-lg border border-input bg-background p-3">{field.options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select>:<input name={field.key} type={field.type??'text'} autoFocus={editing.focusField===field.key} defaultValue={editing.section==='vehicles'&&field.key==='finalKm'?'':String(values[field.key]??'')} required={!field.optional} min={field.type==='number'?0:undefined} step={field.type==='number'?'any':undefined} maxLength={120} className="mt-1 w-full min-w-0 rounded-lg border border-input bg-background p-3"/>}</label>})}</div>{error&&<p role="alert" className="mt-3 text-sm text-destructive">{error}</p>}<div className="mt-5 flex justify-end gap-2"><Button type="button" variant="secondary" onClick={()=>setEditing(null)}>Cancelar</Button><Button type="submit" disabled={photoBusy}>Salvar</Button></div></form></TasksWindow>}
  {photoVehicle&&<TasksWindow wide title={`Foto de ${photoVehicle.name}`} onClose={()=>setPhotoVehicle(null)}><div className="space-y-4"><VehiclePhoto path={photoVehicle.photoPath} name={photoVehicle.name} large/><Button variant="secondary" onClick={()=>{setEditing({section:'vehicles',row:photoVehicle,fieldKeys:['photoPath']});setPhotoVehicle(null)}}>Trocar foto</Button></div></TasksWindow>}
  {deactivating&&<TasksWindow title="Desativar veículo" onClose={()=>setDeactivating(null)}><form onSubmit={deactivateVehicle}><h3 className="font-bold">{deactivating.name} · {deactivating.plate}</h3><p className="mt-3 text-sm text-muted-foreground">Odômetro: {num(deactivating.odometer)} km</p><label className="mt-4 block text-sm font-semibold">KM final<input name="finalKm" type="number" min={0} max={1_000_000_000} step="any" required value={finalKm} onChange={event=>{setFinalKm(event.target.value);setError('')}} className="mt-1 w-full min-w-0 rounded-lg border border-input bg-background p-3"/></label>{(error||(finalKm.trim()&&vehicleKmWarning({...deactivating,finalKm:Number(finalKm)})))&&<p role="alert" className="mt-3 text-sm text-destructive">{error||vehicleKmWarning({...deactivating,finalKm:Number(finalKm)})}</p>}<div className="mt-5 flex justify-end gap-2"><Button type="button" variant="secondary" onClick={()=>setDeactivating(null)}>Cancelar</Button><Button type="submit">Salvar e desativar</Button></div></form></TasksWindow>}
  {removing&&<TasksWindow title="Confirmar exclusão" onClose={()=>setRemoving(null)}><h2 className="text-xl font-bold">Excluir {singular[section]}?</h2><p className="mt-2 text-sm text-muted-foreground">{blockedDelete?'Este veículo possui manutenção, combustível ou compras registradas. Remova esses registros primeiro ou desative o veículo.':'Este registro será removido.'}</p><div className="mt-5 flex justify-end gap-2"><Button variant="secondary" onClick={()=>setRemoving(null)}>Cancelar</Button><Button variant="destructive" disabled={blockedDelete} onClick={remove}>Excluir</Button></div></TasksWindow>}
 </section>;
}
