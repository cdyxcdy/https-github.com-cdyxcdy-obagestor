import { useEffect, useRef, useState } from 'react';
import { Camera, ImagePlus, Car } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { vehiclePhotoBucket, validateVehiclePhoto } from '@/lib/vehicle-photos';

export function VehiclePhoto({ path, name, large = false }: { path?: string | null | undefined; name: string; large?: boolean }) {
  const [url, setUrl] = useState('');
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let alive = true;
    setUrl(''); setFailed(false);
    if (path) void supabase.storage.from(vehiclePhotoBucket).createSignedUrl(path, 3600).then(({ data, error }) => {
      if (alive) { setUrl(data?.signedUrl ?? ''); setFailed(Boolean(error)); }
    });
    return () => { alive = false; };
  }, [path]);
  return url ? <img src={url} alt={`Foto de ${name}`} className={large ? 'vehicle-photo-large' : 'vehicle-photo-thumb'} onError={() => { setUrl(''); setFailed(true); }} /> : <span className={large ? 'vehicle-photo-empty' : 'vehicle-photo-thumb vehicle-photo-placeholder'}><Car size={large ? 48 : 24} />{large && <span>{failed ? 'Não foi possível carregar a foto. Feche e tente novamente.' : path ? 'Carregando foto…' : 'Sem foto'}</span>}</span>;
}

export function VehiclePhotoEditor({ path, onChange, onBusy }: { path?: string | null | undefined; onChange: (path: string) => void; onBusy: (busy: boolean) => void }) {
  const camera = useRef<HTMLInputElement>(null);
  const gallery = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function upload(file?: File) {
    if (!file || busy) return;
    const warning = validateVehiclePhoto(file);
    if (warning) { setError(warning); return; }
    setBusy(true); onBusy(true); setError('');
    try {
      const { data: { user }, error: authError } = await supabase.auth.getUser();
      if (authError || !user) throw new Error('Entre novamente para enviar a foto.');
      const extension = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
      const photoPath = `${user.id}/${crypto.randomUUID()}.${extension}`;
      const { error: uploadError } = await supabase.storage.from(vehiclePhotoBucket).upload(photoPath, file, { contentType: file.type, upsert: false });
      if (uploadError) throw new Error('Não foi possível enviar a foto. Tente novamente.');
      onChange(photoPath);
    } catch (cause) { setError(cause instanceof Error ? cause.message : 'Não foi possível enviar a foto.'); }
    finally { setBusy(false); onBusy(false); }
  }
  return <div className="space-y-3"><p className="text-sm font-semibold">Foto do veículo</p>{path && <VehiclePhoto path={path} name="veículo" large />}
    <div className="grid grid-cols-2 gap-2"><Button type="button" variant="secondary" disabled={busy} onClick={() => camera.current?.click()}><Camera size={18} />Tirar foto</Button><Button type="button" variant="secondary" disabled={busy} onClick={() => gallery.current?.click()}><ImagePlus size={18} />Galeria</Button></div>
    <input ref={camera} type="file" className="hidden" aria-label="Tirar foto do veículo" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={event => { void upload(event.target.files?.[0]); event.target.value = ''; }} />
    <input ref={gallery} type="file" className="hidden" aria-label="Escolher foto da galeria" accept="image/jpeg,image/png,image/webp" onChange={event => { void upload(event.target.files?.[0]); event.target.value = ''; }} />
    {busy && <p role="status" className="text-sm text-muted-foreground">Enviando foto…</p>}{error && <p role="alert" className="text-sm text-destructive">{error}</p>}
  </div>;
}