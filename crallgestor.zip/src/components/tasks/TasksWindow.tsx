import { useRef, type ReactNode } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppBack } from '@/hooks/use-app-back';

export function TasksWindow({ title, onClose, children, wide = false, initialFocusName }: {
  title: string; onClose: () => void; children: ReactNode; wide?: boolean; initialFocusName?: string | undefined;
}) {
  useAppBack(onClose);
  const contentRef = useRef<HTMLDivElement>(null);
  return <Dialog.Root open onOpenChange={open => { if (!open) onClose(); }}>
    <Dialog.Portal>
      <Dialog.Overlay className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm" />
      <Dialog.Content ref={contentRef} onOpenAutoFocus={event=>{if(!initialFocusName)return;const input=contentRef.current?.querySelector<HTMLInputElement|HTMLSelectElement>(`[name="${initialFocusName}"]`);if(input){event.preventDefault();input.focus();if(input instanceof HTMLInputElement)input.select();}}} aria-describedby={undefined} className={`tasks-manager finance-dark fixed inset-3 z-50 m-auto flex h-fit max-h-[calc(100dvh-24px)] min-w-0 flex-col rounded-lg border border-border bg-card text-foreground shadow-xl ${wide ? 'max-w-3xl' : 'max-w-lg'}`}>
        <div className="flex shrink-0 items-center justify-between gap-3 border-b border-border p-4 sm:p-5">
          <Dialog.Title className="min-w-0 font-display text-xl font-bold">{title}</Dialog.Title>
          <Dialog.Close asChild><Button variant="icon" size="icon" aria-label={`Fechar ${title}`} title="Fechar"><X size={20} /></Button></Dialog.Close>
        </div>
        <div className="min-h-0 overflow-y-auto overscroll-contain p-4 sm:p-5">{children}</div>
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}