import { useEffect, useRef, useState, type ReactNode } from "react";
import { Calculator, Minus, NotebookPen, Plus, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";

function FloatingWindow({ title, icon, onClose, width, children }: { title: string; icon: ReactNode; onClose: () => void; width: number; children: ReactNode }) {
  const [pos, setPos] = useState(() => ({ x: Math.max(16, (window.innerWidth - width) / 2), y: Math.max(16, window.innerHeight * 0.12) }));
  const [min, setMin] = useState(false);
  const drag = useRef<{ dx: number; dy: number } | null>(null);
  return <div role="dialog" aria-label={title} className="fixed z-[60] overflow-hidden rounded-2xl border border-border bg-background shadow-2xl" style={{ left: pos.x, top: pos.y, width }}>
    <div className="flex cursor-move select-none items-center gap-2 border-b border-border bg-background/80 px-3 py-2"
      onPointerDown={e => { if ((e.target as HTMLElement).closest("button")) return; drag.current = { dx: e.clientX - pos.x, dy: e.clientY - pos.y }; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); }}
      onPointerMove={e => { if (drag.current) setPos({ x: Math.min(window.innerWidth - 80, Math.max(0, e.clientX - drag.current.dx)), y: Math.min(window.innerHeight - 40, Math.max(0, e.clientY - drag.current.dy)) }); }}
      onPointerUp={() => { drag.current = null; }}>
      <span className="text-primary">{icon}</span><strong className="flex-1 font-display text-sm">{title}</strong>
      <Button variant="icon" size="icon" className="size-8" onClick={() => setMin(m => !m)} aria-label="Minimizar"><Minus size={15} /></Button>
      <Button variant="icon" size="icon" className="size-8" onClick={onClose} aria-label="Fechar"><X size={15} /></Button>
    </div>
    {!min && children}
  </div>;
}

type Note = { id: string; text: string; updatedAt: string };
const stamp = (iso: string) => new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });

function NotesWindow({ userId, onClose }: { userId: string; onClose: () => void }) {
  const key = `crall-notes:${userId}`;
  const [notes, setNotes] = useState<Note[]>(() => { try { return JSON.parse(localStorage.getItem(key) ?? "[]"); } catch { return []; } });
  const [currentId, setCurrentId] = useState<string | null>(() => notes[0]?.id ?? null);
  useEffect(() => { localStorage.setItem(key, JSON.stringify(notes)); }, [key, notes]);
  const current = notes.find(n => n.id === currentId);
  const newNote = () => { const n = { id: crypto.randomUUID(), text: "", updatedAt: new Date().toISOString() }; setNotes(ns => [n, ...ns]); setCurrentId(n.id); };
  const write = (text: string) => {
    if (!current) { const n = { id: crypto.randomUUID(), text, updatedAt: new Date().toISOString() }; setNotes(ns => [n, ...ns]); setCurrentId(n.id); return; }
    setNotes(ns => ns.map(n => n.id === current.id ? { ...n, text, updatedAt: new Date().toISOString() } : n));
  };
  return <FloatingWindow title="Bloco de Notas" icon={<NotebookPen size={18} />} onClose={onClose} width={720}>
    <div className="grid grid-cols-[1fr_200px]">
      <div className="p-4">
        <textarea autoFocus value={current?.text ?? ""} onChange={e => write(e.target.value)} placeholder="Escreva aqui… salva sozinho." className="notepad-paper h-[420px] w-full resize-none rounded-lg p-4" />
        <p className="mt-2 text-xs text-muted-foreground">{current ? `Salvo automaticamente · ${stamp(current.updatedAt)}` : "Comece a digitar"}</p>
      </div>
      <aside className="flex flex-col border-l border-border p-3">
        <Button size="sm" onClick={newNote}><Plus size={15} /> Nova nota</Button>
        <p className="mt-3 text-xs font-bold uppercase text-muted-foreground">Arquivo</p>
        <div className="mt-1 max-h-[400px] flex-1 space-y-1 overflow-y-auto">
          {notes.map(n => <div key={n.id} className={`group flex items-start gap-1 rounded-lg p-2 text-xs ${n.id === currentId ? "bg-primary/15" : "hover:bg-muted"}`}>
            <button type="button" className="min-w-0 flex-1 text-left" onClick={() => setCurrentId(n.id)}><span className="block truncate font-semibold">{n.text.split("\n")[0] || "Nota vazia"}</span><span className="text-muted-foreground">{stamp(n.updatedAt)}</span></button>
            <button type="button" aria-label="Apagar nota" className="text-muted-foreground hover:text-destructive" onClick={() => { if (confirm("Apagar esta nota?")) { setNotes(ns => ns.filter(x => x.id !== n.id)); if (n.id === currentId) setCurrentId(null); } }}><Trash2 size={13} /></button>
          </div>)}
        </div>
      </aside>
    </div>
  </FloatingWindow>;
}

function CalculatorWindow({ onClose }: { onClose: () => void }) {
  const [expr, setExpr] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const calc = () => {
    const safe = expr.replace(/×/g, "*").replace(/÷/g, "/").replace(/,/g, ".");
    if (!/^[\d+\-*/.()%\s]+$/.test(safe)) return;
    try {
      const r = Function(`"use strict";return (${safe.replace(/(\d+(?:\.\d+)?)%/g, "($1/100)")})`)() as number;
      if (!Number.isFinite(r)) return;
      const out = String(Math.round(r * 1e10) / 1e10).replace(".", ",");
      setHistory(h => [`${expr} = ${out}`, ...h].slice(0, 20)); setExpr(out);
    } catch { /* ignore */ }
  };
  const keys = ["C", "(", ")", "÷", "7", "8", "9", "×", "4", "5", "6", "-", "1", "2", "3", "+", "%", "0", ",", "="];
  const press = (k: string) => k === "C" ? setExpr("") : k === "=" ? calc() : setExpr(e => e + k);
  return <FloatingWindow title="Calculadora" icon={<Calculator size={18} />} onClose={onClose} width={320}>
    <div className="p-3">
      <input value={expr} onChange={e => setExpr(e.target.value)} onKeyDown={e => { if (e.key === "Enter") calc(); }} className="w-full rounded-lg p-3 text-right font-display text-2xl" aria-label="Conta" autoFocus />
      <div className="mt-3 grid grid-cols-4 gap-2">{keys.map(k => <Button key={k} variant={k === "=" ? "primary" : "secondary"} className="h-12 text-lg" onClick={() => press(k)}>{k}</Button>)}</div>
      {history.length > 0 && <div className="mt-3 max-h-32 space-y-1 overflow-y-auto border-t border-border pt-2 text-right text-xs text-muted-foreground">{history.map((h, i) => <button type="button" key={i} className="block w-full text-right hover:text-foreground" onClick={() => setExpr(h.split(" = ")[1] ?? "")}>{h}</button>)}</div>}
    </div>
  </FloatingWindow>;
}

export function FloatingToolButtons({ userId }: { userId: string }) {
  const [notes, setNotes] = useState(false);
  const [calc, setCalc] = useState(false);
  return <>
    <Button variant="icon" size="icon" className="hidden shrink-0 md:size-12 lg:inline-flex" onClick={() => setNotes(v => !v)} aria-label="Bloco de Notas" title="Bloco de Notas"><NotebookPen size={20} /></Button>
    <Button variant="icon" size="icon" className="hidden shrink-0 md:size-12 lg:inline-flex" onClick={() => setCalc(v => !v)} aria-label="Calculadora" title="Calculadora"><Calculator size={20} /></Button>
    {notes && <NotesWindow userId={userId} onClose={() => setNotes(false)} />}
    {calc && <CalculatorWindow onClose={() => setCalc(false)} />}
  </>;
}
