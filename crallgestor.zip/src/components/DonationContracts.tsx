import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { FileSignature, FolderOpen, Mail, Send, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEscapeClose } from "@/hooks/use-escape-close";
import { buildContractPdf, contractText, isValidDonee, REQUIRED_DOCUMENTS, type Donee } from "@/lib/donation-contract";

type Saved = { donees: Donee[]; docs: Record<string, string[]> };
const today = () => new Date().toISOString().slice(0, 10);
const fileName = (d: Donee) => `contrato-doacao-${d.name.trim().replace(/\s+/g, "-").toLowerCase()}-${d.date}.pdf`;

export function DonationContracts({ userId, email }: { userId: string; email: string }) {
  const [open, setOpen] = useState(false);
  return <>
    <button type="button" onClick={() => setOpen(true)} className="mt-2 flex w-full min-w-0 items-start gap-3 rounded-xl border border-border bg-muted/30 px-3 py-2 text-left text-sm font-semibold hover:border-primary/60">
      <FileSignature size={20} className="mt-0.5 shrink-0 text-primary" />
      <span className="min-w-0"><span className="block">Contrato Doação e E-mail</span><span className="block truncate text-xs font-normal text-muted-foreground">{email}</span></span>
    </button>
    {open && <ContractsWindow userId={userId} email={email} close={() => setOpen(false)} />}
  </>;
}

function ContractsWindow({ userId, email, close }: { userId: string; email: string; close: () => void }) {
  const key = `crall-donations:${userId}`;
  const [data, setData] = useState<Saved>({ donees: [], docs: {} });
  const [form, setForm] = useState({ name: "", document: "", amount: "", date: today() });
  const [folder, setFolder] = useState<FileSystemDirectoryHandle | null>(null);
  const [msg, setMsg] = useState("");
  useEscapeClose(close, true, 50);
  useEffect(() => { try { const v = JSON.parse(localStorage.getItem(key) ?? "null"); if (v && Array.isArray(v.donees)) setData({ donees: v.donees, docs: v.docs ?? {} }); } catch { /* ignore */ } }, [key]);
  const persist = (n: Saved) => { setData(n); localStorage.setItem(key, JSON.stringify(n)); };

  const add = () => {
    const d = { id: crypto.randomUUID(), name: form.name.trim(), document: form.document.trim(), amount: Number(form.amount.replace(/\./g, "").replace(",", ".")), date: form.date, status: "Pendente" as const };
    if (!isValidDonee(d)) { setMsg("Preencha nome, valor e data."); return; }
    persist({ ...data, donees: [d, ...data.donees] }); setForm({ name: "", document: "", amount: "", date: today() }); setMsg("Pessoa adicionada.");
  };
  const pdf = (d: Donee) => buildContractPdf(contractText(d, email));
  const send = (d: Donee) => {
    const url = URL.createObjectURL(pdf(d)); const a = document.createElement("a"); a.href = url; a.download = fileName(d); a.click(); setTimeout(() => URL.revokeObjectURL(url), 2000);
    window.open(`https://mail.google.com/mail/?view=cm&fs=1&su=${encodeURIComponent(`Contrato de doação - ${d.name}`)}&body=${encodeURIComponent("Segue em anexo o contrato de doação (PDF baixado no computador).")}`, "_blank", "noopener");
    setMsg("PDF baixado e Gmail aberto — anexe o arquivo e envie.");
  };
  const pickFolder = async () => {
    const w = window as unknown as { showDirectoryPicker?: (o?: object) => Promise<FileSystemDirectoryHandle> };
    if (!w.showDirectoryPicker) { setMsg("Seu navegador não permite escolher pasta; o PDF será baixado em Downloads."); return; }
    try { setFolder(await w.showDirectoryPicker({ mode: "readwrite" })); setMsg("Pasta escolhida."); } catch { /* cancelled */ }
  };
  const archive = async (d: Donee) => {
    if (folder) { const f = await folder.getFileHandle(fileName(d), { create: true }); const wr = await f.createWritable(); await wr.write(pdf(d)); await wr.close(); }
    else { const url = URL.createObjectURL(pdf(d)); const a = document.createElement("a"); a.href = url; a.download = fileName(d); a.click(); setTimeout(() => URL.revokeObjectURL(url), 2000); }
    persist({ ...data, donees: data.donees.map(x => x.id === d.id ? { ...x, status: "Arquivado" } : x) }); setMsg(`Contrato de ${d.name} arquivado.`);
  };
  const toggleDoc = (id: string, doc: string) => { const cur = data.docs[id] ?? []; persist({ ...data, docs: { ...data.docs, [id]: cur.includes(doc) ? cur.filter(x => x !== doc) : [...cur, doc] } }); };
  const money = (n: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n);

  return createPortal(<div className="fixed inset-0 z-[80] flex items-start justify-center overflow-y-auto bg-background/80 p-4 backdrop-blur" role="dialog" aria-modal="true" aria-label="Contrato Doação e E-mail" onClick={close}>
    <div className="money-card w-full max-w-3xl rounded-2xl p-5" onClick={e => e.stopPropagation()}>
      <div className="flex items-start justify-between gap-3"><div><h2 className="font-display text-xl font-bold">Contrato Doação e E-mail</h2><p className="flex items-center gap-1 text-xs text-muted-foreground"><Mail size={12}/>{email}</p></div><Button variant="icon" size="icon" onClick={close} aria-label="Fechar"><X size={18}/></Button></div>
      {msg && <p className="mt-3 rounded-lg bg-primary/10 px-3 py-2 text-sm text-primary">{msg}</p>}

      <section className="mt-4 rounded-xl border border-border p-3"><h3 className="mb-2 text-sm font-bold">Nova pessoa que recebeu</h3>
        <div className="grid gap-2 sm:grid-cols-4">
          <input placeholder="Nome" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="sm:col-span-2"/>
          <input placeholder="CPF / RG" value={form.document} onChange={e => setForm({ ...form, document: e.target.value })} data-no-capitalize/>
          <input placeholder="Valor" inputMode="decimal" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })}/>
          <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })}/>
          <Button onClick={add} className="sm:col-span-3">Adicionar</Button>
        </div>
      </section>

      <section className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border p-3"><div><h3 className="text-sm font-bold">Pasta de arquivo</h3><p className="text-xs text-muted-foreground">{folder ? `Salvando em: ${folder.name}` : "Nenhuma pasta escolhida (vai para Downloads)."}</p></div><Button variant="outline" onClick={() => void pickFolder()}><FolderOpen size={16}/>Escolher / criar pasta</Button></section>

      <section className="mt-3 rounded-xl border border-border p-3"><h3 className="mb-2 text-sm font-bold">Lista de pessoas que receberam ({data.donees.length})</h3>
        {data.donees.length === 0 ? <p className="text-sm text-muted-foreground">Ninguém cadastrado ainda.</p> : <ul className="flex flex-col gap-3">{data.donees.map(d => <li key={d.id} className="rounded-lg border border-border p-3">
          <div className="flex flex-wrap items-center justify-between gap-2"><div className="min-w-0"><strong className="break-words">{d.name}</strong><span className="block text-xs text-muted-foreground">{d.date.split("-").reverse().join("/")} · {money(d.amount)} · {d.status}</span></div>
            <div className="flex flex-wrap gap-1"><Button size="sm" onClick={() => send(d)}><Send size={14}/>Enviar PDF</Button><Button size="sm" variant="outline" onClick={() => void archive(d)}><FolderOpen size={14}/>Arquivar</Button><Button size="sm" variant="ghost" aria-label="Excluir" onClick={() => persist({ ...data, donees: data.donees.filter(x => x.id !== d.id) })}><Trash2 size={14}/></Button></div></div>
          <details className="mt-2"><summary className="cursor-pointer text-xs font-bold text-primary">Documentos para recebimento ({(data.docs[d.id] ?? []).length}/{REQUIRED_DOCUMENTS.length})</summary>
            <div className="mt-2 grid gap-1">{REQUIRED_DOCUMENTS.map(doc => <label key={doc} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={(data.docs[d.id] ?? []).includes(doc)} onChange={() => toggleDoc(d.id, doc)}/>{doc}</label>)}</div></details>
        </li>)}</ul>}
      </section>
    </div>
  </div>, document.body);
}
