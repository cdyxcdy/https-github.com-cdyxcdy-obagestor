import { useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { CalendarDays, Plus, Pencil, Trash2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar, CalendarDayButton } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useAppBack } from '@/hooks/use-app-back';
import { agendaColors, appointmentSchema, appointmentsOnDay, localDate, type Appointment } from '@/lib/agenda';

const colorNames = { cyan: 'Ciano', coral: 'Coral', green: 'Verde', gold: 'Dourado' };
export function Agenda({ open, onOpenChange, items, save }: { open: boolean; onOpenChange: (open: boolean)=>void; items: Appointment[]; save: (items: Appointment[])=>Promise<void> }) {
  const [day,setDay]=useState(new Date());
  const [month,setMonth]=useState(new Date());
  const [selected,setSelected]=useState<string|null>(null);
  const [draft,setDraft]=useState<Appointment|null>(null);
  const [removing,setRemoving]=useState(false);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const detail=items.find(item=>item.id===selected);
  const closeChild=()=>{setSelected(null);setDraft(null);setRemoving(false);setError('');};
  useAppBack(closeChild, open && (selected!==null || draft!==null));
  useAppBack(()=>onOpenChange(false), open && selected===null && draft===null);
  const persist=async(next:Appointment[])=>{
    setBusy(true);setError('');
    try { await save(next); closeChild(); }
    catch { setError('Não foi possível salvar. Tente novamente.'); }
    finally { setBusy(false); }
  };
  const create=()=>{setError('');setDraft({id:crypto.randomUUID(),title:'',date:localDate(day),time:'09:00',notes:'',color:'cyan'});};
  return <Dialog open={open} onOpenChange={next=>{if(!busy){closeChild();onOpenChange(next);}}}>
    <DialogContent className="finance-dark agenda-window">
      <div className="pr-8"><DialogTitle className="flex items-center gap-2"><CalendarDays className="text-primary"/>Agenda particular</DialogTitle><DialogDescription>Compromissos pessoais</DialogDescription></div>
      <Calendar locale={ptBR} mode="single" selected={day} onSelect={date=>{if(date)setDay(date);}} month={month} onMonthChange={setMonth} className="agenda-calendar pointer-events-auto" components={{DayButton: props=>{
        const appointments=appointmentsOnDay(items,localDate(props.day.date));
        const colors=[...new Set(appointments.map(item=>item.color))];
        return <CalendarDayButton {...props} className={appointments.length?'agenda-scheduled-day':undefined} data-color={colors[0]} onClick={event=>{props.onClick?.(event);const first=appointments[0];if(first){setSelected(first.id);setError('');}}}><span className="agenda-day-number">{props.day.date.getDate()}</span><span className="agenda-dots" aria-hidden>{colors.map(color=><i key={color} className="agenda-dot" data-color={color}/>)}</span></CalendarDayButton>;
      }}}/>
      <div className="flex justify-end"><Button size="sm" onClick={create}><Plus size={16}/>Agendar</Button></div>
      <Dialog open={selected!==null||draft!==null} onOpenChange={next=>{if(!next&&!busy)closeChild();}}>
        <DialogContent className="finance-dark agenda-window agenda-detail">
          <DialogTitle className="break-words pr-8">{draft ? (selected?'Editar compromisso':'Novo compromisso') : detail?.title}</DialogTitle>
          <DialogDescription>{draft?'Agendamento particular':'Detalhes do compromisso'}</DialogDescription>
          {draft?<form className="space-y-4" onSubmit={event=>{event.preventDefault();const result=appointmentSchema.safeParse(draft);if(!result.success){setError('Confira título, data e horário.');return;}void persist([...items.filter(item=>item.id!==draft.id),result.data]);}}>
            <label className="agenda-field">Título<input autoFocus required maxLength={120} value={draft.title} onChange={e=>setDraft({...draft,title:e.target.value})}/></label>
            <div className="grid grid-cols-2 gap-3"><label className="agenda-field">Data<input required type="date" value={draft.date} onChange={e=>setDraft({...draft,date:e.target.value})}/></label><label className="agenda-field">Horário<input required type="time" value={draft.time} onChange={e=>setDraft({...draft,time:e.target.value})}/></label></div>
            <label className="agenda-field">Observações<textarea rows={4} maxLength={4000} value={draft.notes} onChange={e=>setDraft({...draft,notes:e.target.value})}/></label>
            <fieldset><legend className="mb-2 text-sm font-bold">Cor</legend><div className="flex gap-3">{agendaColors.map(color=><Button key={color} type="button" variant="ghost" size="icon" className="agenda-swatch" data-color={color} aria-label={colorNames[color]} aria-pressed={draft.color===color} title={colorNames[color]} onClick={()=>setDraft({...draft,color})}>{draft.color===color&&<Check size={18}/>}</Button>)}</div></fieldset>
            {error&&<p role="alert" className="text-sm text-destructive">{error}</p>}<Button type="submit" disabled={busy} className="w-full">{busy?'Salvando…':'Salvar compromisso'}</Button>
          </form>:detail&&<>
            {appointmentsOnDay(items,detail.date).length>1&&<div className="space-y-2">{appointmentsOnDay(items,detail.date).map(item=><Button key={item.id} variant="ghost" className="agenda-entry" data-color={item.color} aria-pressed={item.id===selected} onClick={()=>{setSelected(item.id);setRemoving(false);}}><span className="font-bold">{item.time}</span><span className="min-w-0 break-words text-left">{item.title}</span></Button>)}</div>}
            <div className="agenda-detail-label" data-color={detail.color}><CalendarDays size={20}/>{format(new Date(`${detail.date}T12:00:00`),'dd/MM/yyyy')} · {detail.time}</div>
            <div><h3 className="mb-2 text-sm font-bold text-muted-foreground">Observações</h3><p className="whitespace-pre-wrap break-words text-base leading-relaxed">{detail.notes||'Sem observações.'}</p></div>
            {error&&<p role="alert" className="text-sm text-destructive">{error}</p>}
            {removing?<div className="space-y-3"><p>Excluir este compromisso?</p><div className="flex gap-2"><Button variant="destructive" disabled={busy} onClick={()=>void persist(items.filter(item=>item.id!==detail.id))}>Sim, excluir</Button><Button variant="secondary" disabled={busy} onClick={()=>setRemoving(false)}>Não</Button></div></div>:<div className="flex gap-2"><Button variant="secondary" onClick={()=>setDraft({...detail})}><Pencil size={16}/>Editar</Button><Button variant="secondary" onClick={()=>setRemoving(true)}><Trash2 size={16}/>Excluir</Button></div>}
          </>}
        </DialogContent>
      </Dialog>
    </DialogContent>
  </Dialog>;
}