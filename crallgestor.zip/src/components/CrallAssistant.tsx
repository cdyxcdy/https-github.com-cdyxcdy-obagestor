import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Download, Headphones, HeadphoneOff, Minus, Send, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { askCrall, crallImage } from "@/lib/crall.functions";
import { useEscapeClose } from "@/hooks/use-escape-close";
import { useNavigate } from "@tanstack/react-router";
import { SCREENS, requestedScreens, splitComparison, wantsImage, wantsPanel, type ScreenTab } from "@/lib/crall-intent";

type Msg = { role: "user" | "assistant"; content: string };
type Panel = { kind: "text"; content: string } | { kind: "image"; src: string; prompt: string } | { kind: "screens"; tabs: ScreenTab[] } | null;
type SR = { continuous: boolean; interimResults: boolean; lang: string; start: () => void; stop: () => void; onresult: ((e: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null; onend: (() => void) | null };

/** Floating CRALL assistant: close turns it off, minimize keeps it listening, headphones mute mic and voice. */
export function CrallAssistant({ variant = "default" }: { variant?: "default" | "sidebar" }) {
  const side = variant === "sidebar";
  const ask = useServerFn(askCrall), image = useServerFn(crallImage);
  const navigate = useNavigate();
  const [state, setState] = useState<"off" | "open" | "min">("off");
  const [muted, setMuted] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState(""); const [busy, setBusy] = useState(false);
  const [panel, setPanel] = useState<Panel>(null); const [speaking, setSpeaking] = useState(false);
  useEscapeClose(() => {
    if (panel) { setPanel(null); return; }
    if (state === "open") setState("min");
  }, state !== "off", 20);
  const recRef = useRef<SR | null>(null); const msgsRef = useRef(msgs); msgsRef.current = msgs;
  const activeRef = useRef(false); activeRef.current = state !== "off" && !muted;

  const speak = (text: string) => {
    if (muted || typeof speechSynthesis === "undefined") return;
    speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text.replace(/[#*_`]/g, "").slice(0, 600)); u.lang = "pt-BR";
    const voices = speechSynthesis.getVoices().filter(v => v.lang.toLowerCase().startsWith("pt"));
    const male = voices.find(v => /male|mascul|daniel|felipe|ricardo|antonio|thiago/i.test(v.name)) ?? voices.find(v => /google/i.test(v.name));
    if (male) u.voice = male; u.pitch = 0.85;
    u.onstart = () => setSpeaking(true); u.onend = () => setSpeaking(false); speechSynthesis.speak(u);
  };
  const send = async (text: string) => {
    const t = text.trim(); if (!t || busy) return;
    setInput(""); setBusy(true);
    const next = [...msgsRef.current, { role: "user" as const, content: t }]; setMsgs(next);
    const screens = wantsPanel(t) ? requestedScreens(t) : [];
    if (screens.length) {
      const names = screens.map(tab => SCREENS.find(x => x.tab === tab)!.label).join(" e ");
      if (screens.length === 1) { setPanel(null); setState("min"); void navigate({ to: "/dashboard", search: { tab: screens[0]! } }); }
      else setPanel({ kind: "screens", tabs: screens });
      const reply = screens.length === 1 ? `Abrindo ${names}.` : `Comparando ${names} lado a lado.`;
      setMsgs([...next, { role: "assistant", content: reply }]); speak(reply); setBusy(false); return;
    }
    try {
      if (wantsImage(t)) {
        const r = await image({ data: { prompt: t } });
        setPanel({ kind: "image", src: r.image, prompt: t });
        setMsgs([...next, { role: "assistant", content: "Pronto! A imagem está no painel central." }]); speak("Pronto! A imagem está no painel.");
      } else {
        const r = await ask({ data: { messages: next.slice(-20) } });
        setMsgs([...next, { role: "assistant", content: r.text }]);
        if (wantsPanel(t)) setPanel({ kind: "text", content: r.text });
        speak(r.text);
      }
    } catch (e) { setMsgs([...next, { role: "assistant", content: e instanceof Error ? e.message : "Erro ao responder." }]); }
    finally { setBusy(false); }
  };
  const sendRef = useRef(send); sendRef.current = send;

  useEffect(() => {
    const W = window as unknown as { SpeechRecognition?: new () => SR; webkitSpeechRecognition?: new () => SR };
    const Ctor = W.SpeechRecognition ?? W.webkitSpeechRecognition;
    if (!Ctor || state === "off" || muted) { recRef.current?.stop(); recRef.current = null; return; }
    const rec = new Ctor(); rec.continuous = true; rec.interimResults = false; rec.lang = "pt-BR";
    rec.onresult = e => { for (let i = e.resultIndex; i < e.results.length; i++) { const r = e.results[i]!; if (!r.isFinal) continue; const said = r[0].transcript; const m = said.match(/cr[aá]l+\s*,?\s*(.*)/i); if (!m) continue; const text = m[1]!.trim(); setState(s => s === "min" ? "open" : s); if (text) void sendRef.current(text); else speak("Sim? Estou ouvindo."); } };
    rec.onend = () => { if (activeRef.current && recRef.current === rec) try { rec.start(); } catch { /* already running */ } };
    recRef.current = rec; try { rec.start(); } catch { /* permission */ }
    return () => { recRef.current = null; rec.onend = null; rec.stop(); };
  }, [state, muted]);
  useEffect(() => { if (muted && typeof speechSynthesis !== "undefined") { speechSynthesis.cancel(); setSpeaking(false); } }, [muted]);
  const close = () => { setState("off"); setPanel(null); if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel(); };

  const orb = <span aria-hidden="true" className={`crall-orb block rounded-full ${side ? "size-11" : "size-14"} ${speaking || busy ? "crall-orb-active" : ""} ${muted ? "opacity-40 grayscale" : ""}`}/>;
  const tapRef = useRef<number | null>(null); const holdRef = useRef<number | null>(null); const heldRef = useRef(false);
  const status = state === "off" ? "off" : muted ? "paused" : "on";
  const tap = () => {
    if (heldRef.current) { heldRef.current = false; return; }
    if (tapRef.current) { clearTimeout(tapRef.current); tapRef.current = null; close(); return; }
    tapRef.current = window.setTimeout(() => { tapRef.current = null; if (state === "off") { setMuted(false); setState("min"); } else setMuted(v => !v); }, 260);
  };
  const holdStart = () => { heldRef.current = false; holdRef.current = window.setTimeout(() => { heldRef.current = true; close(); }, 650); };
  const holdEnd = () => { if (holdRef.current) clearTimeout(holdRef.current); holdRef.current = null; };
  const statusColor = status === "on" ? "var(--income)" : status === "paused" ? "var(--accent)" : "var(--destructive)";
  const sideOrb = side && <div className="flex items-center gap-3 rounded-2xl border border-border bg-card/70 p-2">
    <button type="button" onClick={tap} onPointerDown={holdStart} onPointerUp={holdEnd} onPointerLeave={holdEnd} onContextMenu={e => e.preventDefault()}
      aria-label={`CRALL ${status === "on" ? "ativada" : status === "paused" ? "pausada" : "desligada"}. Toque para alternar, toque duplo ou segure para desligar`}
      className="relative shrink-0 select-none rounded-full p-0.5" style={{ boxShadow: `0 0 0 2px ${statusColor}, 0 0 18px ${statusColor}` }}>
      <span aria-hidden="true" className={`crall-orb block size-11 rounded-full ${speaking || busy ? "crall-orb-active" : ""} ${status !== "on" ? "opacity-60" : ""}`}/>
    </button>
    <button type="button" onClick={() => { if (state === "off") setMuted(false); setState("open"); }} className="min-w-0 text-left" title="Abrir conversa">
      <strong className="block font-display text-lg leading-tight">CRALL IA</strong>
      <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><i className="size-2 rounded-full" style={{ background: statusColor }}/>{status === "on" ? "Assistente online" : status === "paused" ? "Pausada" : "Desligada"}</span>
    </button>
  </div>;
  const split = panel?.kind === "text" ? splitComparison(panel.content) : null;

  return <div className={side ? "hidden lg:block" : "hidden md:block lg:hidden"}>
    {sideOrb}
    {!side && state === "off" && <button type="button" onClick={() => setState("open")} aria-label="Ligar assistente CRALL" title="CRALL" className={`rounded-full ${side ? "shrink-0" : "fixed bottom-6 right-6 z-50 lg:bottom-auto lg:right-auto lg:left-[17rem] lg:top-4"}`}>{orb}</button>}
    {state === "open" && <div className="fixed inset-0 z-40 grid place-items-center bg-background/70 p-6 backdrop-blur-sm" onMouseDown={e => { if (e.target === e.currentTarget) setState("min"); }}>
      <div role="dialog" aria-label="Conversa com a CRALL" className="money-card flex h-[85vh] w-[min(64rem,92vw)] flex-col rounded-3xl p-6 shadow-2xl">
        <div className="mb-4 flex items-center gap-3"><span aria-hidden="true" className={`crall-orb block size-12 rounded-full ${speaking || busy ? "crall-orb-active" : ""}`}/><h2 className="font-display text-2xl font-bold">CRALL</h2><div className="ml-auto flex items-center gap-1"><Button variant="icon" size="icon" onClick={() => setMuted(v => !v)} aria-label={muted ? "Reativar microfone e áudio" : "Silenciar microfone e áudio"} className={`size-7 min-h-7 ${muted ? "text-destructive" : ""}`}>{muted ? <HeadphoneOff size={14}/> : <Headphones size={14}/>}</Button><Button variant="icon" size="icon" onClick={close} aria-label="Fechar CRALL" className="size-7 min-h-7"><X size={14}/></Button></div></div>
        <div className="flex-1 space-y-3 overflow-y-auto pr-2 text-base leading-relaxed">{!msgs.length && <p className="text-muted-foreground">Olá! Sou o CRALL. Fale "CRALL, ..." ou escreva abaixo. Peça "mostre" para abrir o painel ou "crie uma imagem" para gerar artes.</p>}
          {msgs.map((m, i) => <p key={i} className={`whitespace-pre-wrap rounded-2xl px-4 py-3 ${m.role === "user" ? "ml-24 bg-primary/15" : "mr-24 bg-muted"}`}>{m.content}</p>)}
          {busy && <p className="text-muted-foreground">CRALL está pensando…</p>}</div>
        <form className="mt-4 flex gap-3" onSubmit={e => { e.preventDefault(); void send(input); }}><input aria-label="Mensagem para CRALL" className="flex-1 text-base" value={input} maxLength={2000} onChange={e => setInput(e.target.value)} placeholder="Pergunte à CRALL"/><Button type="submit" disabled={busy} aria-label="Enviar"><Send size={18}/>Enviar</Button></form>
      </div>
    </div>}
    {panel && state !== "off" && <div role="dialog" aria-label="Painel da CRALL" className="fixed inset-x-0 top-10 z-[60] mx-auto w-[min(80rem,95vw)] max-h-[90vh] overflow-y-auto rounded-3xl border border-border bg-card p-6 shadow-2xl">
      <div className="mb-3 flex items-center"><h2 className="font-display text-lg font-bold">CRALL</h2>
        {panel.kind === "image" && <a href={panel.src} download="crall-imagem.png" className="ml-auto mr-2 inline-flex items-center gap-1 text-sm font-bold text-primary"><Download size={16}/>Baixar</a>}
        <Button variant="icon" size="icon" className={panel.kind === "image" ? "" : "ml-auto"} onClick={() => setPanel(null)} aria-label="Fechar painel"><X size={16}/></Button></div>
      {panel.kind === "screens" ? <div className="grid h-[72vh] grid-cols-2 gap-3">{panel.tabs.map(tab => <div key={tab} className="flex min-h-0 flex-col overflow-hidden rounded-2xl border border-border"><strong className="bg-muted px-3 py-1.5 text-sm">{SCREENS.find(x => x.tab === tab)!.label}</strong><iframe title={SCREENS.find(x => x.tab === tab)!.label} src={`/dashboard?tab=${tab}`} className="min-h-0 w-full flex-1 bg-background"/></div>)}</div> :
        panel.kind === "image" ? <img src={panel.src} alt={panel.prompt} className="mx-auto max-h-[65vh] rounded-xl"/> :
        split ? <div className="grid grid-cols-2 gap-4">{split.map((s, i) => <div key={i} className="whitespace-pre-wrap rounded-2xl bg-muted p-4 text-sm">{s.replace(/^## /, "")}</div>)}</div> :
        <div className="whitespace-pre-wrap text-sm">{panel.content}</div>}
    </div>}
  </div>;
}
