import { useEffect, useState, type ReactNode, type FormEvent } from "react";
import { LockKeyhole, LogOut } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { createDevicePin, matchesDevicePin, failedPin, pinStorageKey, readDevicePin, validPin } from "@/lib/device-pin";
import selo from "@/assets/selo-humanus.png.asset.json";
import { confirmedDeviceName } from "@/lib/device-confirmation";

// Device convenience lock only; Cloud authentication and license checks remain authoritative.
export function DevicePinGate({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [ready, setReady] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [unlocked, setUnlocked] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [pin, setPin] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let active = true;
    const applyIdentity = (id: string | null) => {
      if (!active) return;
      setUserId(id); setRegistered(id ? !!readDevicePin(id) : false); setUnlocked(false);
      setPin(""); setConfirmation(""); setName(""); setMessage(""); setReady(true);
    };
    void supabase.auth.getUser().then(({ data }) => applyIdentity(data.user?.id ?? null)).catch(() => applyIdentity(null));
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT") applyIdentity(session?.user.id ?? null);
    });
    return () => { active = false; data.subscription.unsubscribe(); };
  }, []);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!userId || busy || !validPin(pin)) return;
    setBusy(true); setMessage("");
    try {
      const { data, error } = await supabase.auth.getUser();
      if (error || data.user?.id !== userId) { setUserId(null); setUnlocked(false); return; }
      const record = readDevicePin(userId);
      if (!record) {
        if (!confirmedDeviceName(name)) { setMessage("Nome de confirmação incorreto."); return; }
        if (pin !== confirmation) { setMessage("Os números não conferem. Confirme o PIN novamente."); return; }
        const created = await createDevicePin(pin);
        localStorage.setItem(pinStorageKey(userId), JSON.stringify(created));
        setRegistered(true); setUnlocked(true);
      } else {
        if (record.blockedUntil > Date.now()) { setMessage("Muitas tentativas. Aguarde um minuto para tentar novamente."); return; }
        if (!await matchesDevicePin(pin, record)) {
          localStorage.setItem(pinStorageKey(userId), JSON.stringify(failedPin(record, Date.now())));
          setMessage("PIN incorreto."); return;
        }
        localStorage.setItem(pinStorageKey(userId), JSON.stringify({ ...record, failures: 0, blockedUntil: 0 }));
        setUnlocked(true);
      }
    } catch { setMessage("Não foi possível liberar o acesso neste aparelho. Tente novamente."); }
    finally { setPin(""); setConfirmation(""); setBusy(false); }
  };
  const signOut = async () => {
    setBusy(true);
    await queryClient.cancelQueries(); queryClient.clear();
    const { error } = await supabase.auth.signOut();
    if (error) { setMessage("Não foi possível sair. Tente novamente."); setBusy(false); return; }
    window.location.replace("/");
  };
  if (!ready) return <main className="finance-dark grid min-h-dvh place-items-center bg-background text-foreground" aria-busy="true">Aguarde…</main>;
  if (!userId || unlocked) return children;
  if (registered) return <main className="finance-dark grid min-h-dvh place-items-center px-4 py-8 text-foreground">
    <form onSubmit={event => void submit(event)} className="flex w-full max-w-xs flex-col items-center gap-8">
      <img src={selo.url} width={320} height={320} alt="Selo Humanus" className="size-64 object-contain drop-shadow-[0_0_40px_var(--primary-glow)] sm:size-80"/>
      <Input aria-label="Senha" placeholder="Senha" className="h-14 text-center text-2xl tracking-[0.5em]" type="password" inputMode="numeric" autoComplete="off" maxLength={4} value={pin} disabled={busy} onChange={e => { const v = e.target.value.replace(/\D/g, "").slice(0, 4); setPin(v); if (v.length === 4) setTimeout(() => e.target.form?.requestSubmit(), 0); }} autoFocus/>
      {message && <p role="alert" className="text-sm text-destructive">{message}</p>}
    </form>
  </main>;
  return <main className="finance-dark grid min-h-dvh place-items-center bg-background px-4 py-8 text-foreground">
    <section className="w-full max-w-sm text-center">
      <img src={selo.url} width={200} height={200} alt="Selo Humanus" className="mx-auto size-40 object-contain"/>
      <LockKeyhole className="mx-auto mt-6 text-primary" size={28}/>
      <h2 className="mt-3 text-xl font-semibold">Ativar senha neste aparelho</h2>
      <form onSubmit={event => void submit(event)} className="mt-6 space-y-4 text-left">
        {!registered && <label className="block text-sm font-semibold">Nome de confirmação
          <Input aria-label="Nome de confirmação" className="mt-2 h-12" autoComplete="off" value={name} onChange={e => setName(e.target.value)} required/>
        </label>}
        <label className="block text-sm font-semibold">PIN de quatro dígitos
          <Input aria-label="PIN de quatro dígitos" className="mt-2 h-14 text-center text-2xl" type="password" inputMode="numeric" pattern="[0-9]{4}" autoComplete="off" maxLength={4} value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))} autoFocus required/>
        </label>
        {!registered && <label className="block text-sm font-semibold">Confirme seu PIN
          <Input aria-label="Confirme seu PIN" className="mt-2 h-14 text-center text-2xl" type="password" inputMode="numeric" pattern="[0-9]{4}" autoComplete="off" maxLength={4} value={confirmation} onChange={e => setConfirmation(e.target.value.replace(/\D/g, "").slice(0, 4))} required/>
        </label>}
        {message && <p role="alert" className="text-sm text-destructive">{message}</p>}
        <Button className="w-full" type="submit" disabled={busy || !validPin(pin) || (!registered && !validPin(confirmation))}>{busy ? "Aguarde…" : registered ? "Entrar" : "Ativar e entrar"}</Button>
      </form>
      <Button variant="ghost" className="mt-4" disabled={busy} onClick={() => void signOut()}><LogOut size={16}/>Sair da conta</Button>
    </section>
  </main>;
}