import { useEffect, useState } from "react";
import { getMarketData, type MarketData } from "@/lib/market.functions";

const fmt = (v: number, d = 2) => v.toLocaleString("pt-BR", { minimumFractionDigits: d, maximumFractionDigits: d });

function Tag({ change }: { change: number | null }) {
  if (change === null) return null;
  const up = change >= 0;
  return <span className="ml-2 rounded-md px-1.5 py-0.5 text-xs font-bold" style={{ background: `color-mix(in oklch, var(${up ? "--income" : "--destructive"}), transparent 80%)`, color: `var(${up ? "--income" : "--destructive"})` }}>{up ? "▲ +" : "▼ "}{fmt(change)}%</span>;
}

export function MarketTicker() {
  const [data, setData] = useState<MarketData | null>(null);
  useEffect(() => {
    let alive = true;
    const load = () => getMarketData().then(d => { if (alive) setData(d); }).catch(() => {});
    load();
    const id = window.setInterval(load, 60_000);
    return () => { alive = false; window.clearInterval(id); };
  }, []);
  const monthly = data?.selic != null ? (Math.pow(1 + data.selic / 100, 1 / 12) - 1) * 100 : null;
  const items = [
    <span key="i"><b className="text-muted-foreground">B3 · IBOV</b> <strong className="ml-1">{data?.ibov.value != null ? `${fmt(data.ibov.value, 0)} pts` : "—"}</strong><Tag change={data?.ibov.change ?? null} /></span>,
    <span key="u"><b className="text-muted-foreground">Dólar</b> <strong className="ml-1">{data?.usd.value != null ? `R$ ${fmt(data.usd.value)}` : "—"}</strong><Tag change={data?.usd.change ?? null} /></span>,
    <span key="s"><b className="text-muted-foreground">Selic</b> <strong className="ml-1">{data?.selic != null ? `${fmt(data.selic)}% a.a.` : "—"}</strong>{monthly != null && <span className="ml-2 text-xs text-muted-foreground">~{fmt(monthly)}% a.m.</span>}</span>,
  ];
  return <div className="market-ticker relative hidden h-11 min-w-0 flex-1 overflow-hidden rounded-xl border border-border bg-card/60 lg:block" aria-label="Mercado em tempo real">
    <div className="market-ticker-track flex h-full w-max items-center gap-10 whitespace-nowrap px-4 text-sm">
      {items}{items.map((x, i) => <span key={`d${i}`} aria-hidden>{x.props.children}</span>)}
    </div>
  </div>;
}
