<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Use one authenticated app with one private realtime finance-state row per user; persist section patches and atomically mutate cards, records and fixed/foreign payments. Foreign payments reduce only matching currency assets; derive analytics and PDF reports client-side for privacy.
- Derive card credit and debit balances from their opening amounts plus bank-linked records; include both available balances in the home total, derive the home investment total from each card's synchronized invested balance, require fixed-expense payments to identify the card and credit/debit mode, and reject card-linked expenses atomically when that mode lacks sufficient balance so every view stays consistent.
- Share card-balances across displays/checks; ignore Home resets. Locked card edits reconcile desired balances with signed adjustments against records; checks include adjustments to preserve history and concurrency. Preserve legacy payment methods to avoid balance/billing changes.
- Exclude Selic from foreign investments.
- Separate browser-safe PDF building from download/share; validate without state changes.
- Enforce expiry via finance RLS; paid grants are admin-only. Atomic self-trials require no existing license to prevent repeats. Recheck expiry, hide finance and preserve data; admins are exempt.
- bootstrap_admin must verify the owner email; hide its button otherwise to prevent ownership claims.
- Keep cards in normal flow with responsive tracks and full-width balances to prevent overlaps without changing calculations.
- Mount bottom navigation once; cap finance content and wide dialogs to tablet width and align navigation, avoiding desktop expansion while keeping Home available.
- Share tab scroll resets; keep task filters local. Swipe excludes header, fields, holds and dialogs; allow content-button swipes. Preserve vertical scroll/history; block drag clicks, not taps. Show active heading/content on mobile; preserve larger-screen navigation.
- Initialize new finance accounts from empty defaults, never from an unscoped browser cache; key local snapshots by user ID so shared devices cannot copy another account's cards or records.
- Keep tasks backward-compatible; shared account dialogs filter kind/settled and default to selected kind. Section patches persist completion without changing finance balances. Shopping holds capture touch, tolerate jitter, cancel on scroll and exclude actions.
- Sort vehicles on a copy with the tasks helper to preserve stored order.
- Sort record display on a copy via record-order; fixed payments use paidAt, not synthetic IDs, preserving stored dates and balances.
- Add submitted final-distance increments to the odometer only through the shared save helper; leave increment inputs blank and never sum on reactivation or render to prevent repeated accumulation.
- Validate distance increments and odometer sums in the browser-safe tasks helper without tightening stored-state parsing, preserving legacy records and maintenance checks.
- Merge only submitted vehicle fields in scoped edits to preserve other values; driver names open full edits and statuses toggle directly; desktop maintenance edits open only through the service, with completion toggled through status.
- Use validated search for tabs and scoped history for windows. Reset first non-preload app entry to Home, preserving navigation and Back without changing financial data.
- Use responsive tracks for task totals/navigation/actions; separate mobile text and actions to prevent clipping without logic changes.
- Separate fleet/accounts styles in accessible nested modals; tablet-width spreadsheets, mobile cards below 768px, wrapped cells, no horizontal scroll. Preserve actions, position, legacy rows and totals.
- Style editable fields, selectors, and shared calendars centrally in the global stylesheet and icon actions through the shared Button variant so all tabs have consistent visible controls without changing their behavior.
- Keep notification choices and reminder generation in a browser-safe shared validation module; gate each message by its saved per-user choice and deduplicate reminders per day without mutating financial state.
- Use versioned padded any/maskable PWA icons and a solid launch background; native launch screens cannot use HTML/animations or delay loading.

- Store vehicle photos in an owner-scoped private storage bucket and persist only optional object paths in tasks; signed display URLs preserve privacy and legacy records.

- Store validated private appointments in a finance-state agenda section with nested dialogs; patches preserve balances and user isolation.
- Disable native pull-to-refresh via root CSS overscroll behavior to preserve scrolling and tab gestures.

- Browser-safe activity feeds derive Pix/transfer income totals and filter old notices by current preferences; never mutate balances.
- Root typing helper capitalizes sentences via native input events; preserve identifiers.
- Device PIN is a salted, account-scoped local screen lock, not Cloud authentication; require signed-in device registration and never store raw PINs.
