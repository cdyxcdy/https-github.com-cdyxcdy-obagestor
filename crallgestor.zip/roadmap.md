# Ajustes solicitados
- [x] Em Cartões: Crédito, Débito e Investimento em todos os cartões, inclusive nos novos
- [x] Início do computador ajustado à tela, com cards maiores
- [x] Configurações sem escolha de mensagens por enquanto (usuário edita depois)
- [ ] Publicar as telas: roleta do celular, miniaturas dos cartões, painel, ESC, números de cadastro e agenda no topo
- [x] Mover a agenda para a linha do topo, ao lado do nome, em celular, tablet e computador; removidos os botões anteriores da agenda (incluindo o "Hoje" do painel), sem alterar compromissos
- [x] Número de cadastro editável: o proprietário digita o número que quiser (1 a 4 dígitos), com recusa de repetição; 7 testes aprovados
- [x] Remover o título "Visão geral" e a frase abaixo dele no painel do computador
- [x] Adicionar A receber e Recebidas abaixo de A pagar e Pagas com o mesmo layout e janelas; cadastro, recarga, receber, reabrir e exclusão conferidos na conta conectada; registro temporário removido, celular sem rolagem lateral, 18 testes aprovados e build OK. Falta publicar as telas.
- [x] Adicionar teste único de 1 hora na tela do QR; ativação, duração exata, recarga, rejeição de repetição e bloqueio com RLS conferidos na conta autorizada, prazo original restaurado; 19 testes aprovados. Falta publicar as telas.
- [x] Cobrar R$ 30 por 30 dias desde cada liberação/renovação com QR e Pix copia e cola enviados; renovação e bloqueio de sessão aberta conferidos, acesso aos dados negado no vencimento, 16 testes aprovados; falta publicar telas
- [x] Excluir duas contas de teste, seus dados e foto; somente administrador permanece, conferido na área de Clientes e nos registros
- [x] Voltar o nome para Oba Financeiro nas telas, relatórios e aplicativo instalado, sem alterar funções
- [x] Adicionar botão Início inferior transparente e flutuante somente no celular; retorno ao topo conferido na conta conectada, tablet/PC preservados e 6 testes aprovados
- [x] Desativar puxar para atualizar; gesto conferido sem recarga e navegação entre abas preservada na conta conectada
- [x] Renomear aplicativo para OPTMUS FINANCE nas telas, relatórios e nome instalado; nome conferido e 15 testes aprovados
- [x] Colorir quadrado inteiro dos dias agendados, destacar número e abrir janela flutuante ao tocar no dia sobre o calendário em todas as plataformas; conferidos celular, tablet e PC, testes aprovados e compromisso temporário excluído
- [x] Avisar no sino um dia antes dos compromissos, respeitando escolha salva e deduplicação diária; regra testada e aviso conferido na conta conectada
- [x] Criar agenda particular no topo com posições por plataforma, compromissos coloridos e janela de detalhes; cadastro, recarga, detalhes e exclusão conferidos na conta conectada, teste temporário removido; 9 testes aprovados e build OK
- [x] Enquadrar todos os cards do Início na mesma tela do celular; conferido em 393×785 sem rolagem, preservando topo e cálculos
- [x] Organizar títulos dos cards de seção somente no celular; cinco títulos conferidos ao deslizar, sem cortes, navegação de PC/tablet preservada e build OK
- [x] Corrigir palavra do título do Início para “INFORMAÇÕES”; letra A e título completo conferidos na tela
- [x] Colocar card de título no Início igual às outras páginas, com “INICIO - APENAS INFORMÇÕES”, somente no celular; apresentação conferida, PC/tablet preservados
- [x] Corrigir retorno ao deslizar para a direita no celular, inclusive sobre botões do conteúdo; ida/volta e toque intencional conferidos na conta conectada sem salvar alterações, 18 testes aprovados
- [x] Impedir edição e ações por clique acidental depois de arrastar no celular; toque abre edição e arrastar não abre, conferidos na conta conectada sem salvar alterações; 15 testes aprovados, incluindo compras por pressão longa
- [x] Corrigir somente no celular para um card de seção por página, substituído ao deslizar; quatro páginas e retorno ao Início conferidos por toque na conta conectada, PC/tablet preservados, quatro testes aprovados e sem erros; nenhuma alteração nos dados
- [x] Navegar deslizando a tela entre Início, Despesas fixas, Cartões, Receitas e gastos e Minhas Tarefas somente no celular; botão Início oculto só no celular; quatro testes aprovados e conta conectada conferida por toque real em ida/volta, rolagem vertical, janela aberta e PC/tablet preservados, sem erros nem alteração financeira
- [x] Corrigir Crédito disponível como soma real dos cartões, incluir pagamentos no débito nos Gastos totais, remover todo zeramento por gesto e permitir editar saldos finais para zero; testes de cálculos e fluxo conectado aprovados, dados temporários removidos e valores originais restaurados
- [x] Ajustar somente no PC Contas a pagar sem rolagem lateral; textos, valores e botões conferidos com duas contas reais em 1280 e 1082px, sem cortes; celular preservado
- [x] Ordenar despesas fixas pagas junto dos demais lançamentos conforme quando foram pagas; horário salvo nos novos pagamentos, IDs antigos sem prioridade, oito testes aprovados; conta conectada sem lançamentos para comparação visual
- [x] Deixar estática somente a aba Receitas e gastos; ausência de movimentos conferida na conta conectada e pulsação de Cartões preservada
- [x] Retirar botão Mais recentes de Receitas e gastos e manter lançamentos atuais no topo; ausência conferida na conta conectada e ordenação coberta por testes
- [x] Garantir retorno ao topo ao clicar em Início, inclusive repetidamente e após navegar por outras abas; 7 testes aprovados e retorno ao topo conferido na conta conectada
- [x] Remover opções e avisos de contas a receber próximas/vencidas e registros/alterações de combustível, preservando registros; 5 testes aprovados e opções conferidas na conta conectada
- [x] Retirar novamente o contato WhatsApp do administrador da tela de acesso desativado
- [x] Corrigir demora do risco na Lista de compras após segurar por 1 segundo no celular; 7 testes aprovados e toque com movimento conferido na conta conectada, com risco em cerca de 1 segundo
- [x] Organizar textos nas colunas dos veículos, preservando fotos maiores e sem rolagem lateral; títulos e nomes conferidos na conta conectada
- [x] Trocar KM inicial por Odômetro; KM final soma uma única vez ao salvar, sem somar ao reativar ou recarregar; 24 testes aprovados e persistência conferida na conta conectada com veículo temporário removido após teste
- [x] Retirar rolagem lateral das quatro janelas da Frota; conferido com registros existentes em 1280, 770 e 393 px
- [x] Organizar textos da Frota com colunas proporcionais, telefone/CNH e manutenção em blocos legíveis; 15 testes aprovados
- [x] Frota: foto por câmera ou galeria no cadastro de veículo e miniatura clicável para ampliar, com fotos privadas; envio, recarga e ampliação conferidos na conta conectada e 19 testes aprovados
- [x] Usar apresentação compacta de tablet no computador, com páginas e janelas limitadas a 768px, sem ampliar cards; preservar celular e dados
- [x] Colocar Frota acima das contas A pagar e Pagas em todas as plataformas
- [x] Lista de compras: quadrinho no começo do pedido apenas no PC; pressão longa preservada no celular; marcar/desmarcar conferido na conta conectada e 5 testes aprovados
- [x] Abrir sempre no Início em todas as plataformas, preservando navegação e dados; abertura e recarga conferidas em 1280, 770 e 393 px, com 7 testes aprovados
- [x] Retirar textos e opções Pix da área financeira, preservando histórico, saldos e cobrança do acesso; opções conferidas na conta conectada e 14 testes aprovados
- [x] Manter Lista de compras no padrão de cores e efeitos da Frota; marcar peças compradas com pressão de 1 segundo, riscando a linha no celular e PC; persistência validada
- [x] Criar Lista de compras na Frota com seis campos, edição/exclusão e modelo Planilha limpa; validar salvamento e apresentação
- [x] Tornar status dos motoristas clicável, separar edição por informação dos veículos e editar manutenção somente pelo serviço no PC
- [x] Retirar PDF e resumo financeiro de Minhas Tarefas, mantendo somente contas a pagar e frota
- [x] Motoristas: editar somente pelo nome; manutenção: concluir/reabrir pelo status, sem botão separado
- [x] Retirar Editar das linhas de frota no PC e abrir edição clicando nas informações, preservando celular
- [x] Abrir edição ao clicar em KM inicial ou final em computador e celular
- [x] Deixar KM final maior e destacado para tocar no celular
- [x] Retirar KM total e acumular inicial + final no próprio KM final ao reativar
- [x] Avisar e impedir KM final menor que o inicial ao desativar ou editar o veículo
- [x] Corrigir proporções e alinhamento das linhas de frota no PC
- [x] Integrar voltar do celular às abas e janelas do app
- [x] Pedir KM final ao desativar veículos, somar inicial e final e organizar os valores na linha
- [x] Pulsar o contorno colorido somente da aba superior aberta em todas as plataformas
- [x] Colocar Pendente no mês e Pago no mês lado a lado no celular, preservando computador e valores
- [x] Apresentar exemplos e aplicar a escolha Excel clássico apenas no PC, preservando cartões no celular
- [x] Mostrar registros das janelas em linhas desde o primeiro cadastro a partir de 768px, com rolagem lateral local
- [x] Apresentar janelas no PC como planilhas do Excel, com cabeçalhos, colunas alinhadas e linhas compactas
- [x] Colocar todos os botões de cada registro na mesma linha das informações no PC, sem segunda linha de ações
- [x] Remover filtros abaixo de A pagar e Pagas, mantendo quadros e Adicionar conta, e apresentar registros das janelas em linhas no computador
- [x] Abrir informações de A pagar e Pagas somente ao clicar, em janelas flutuantes sem mover a página
- [x] Manter a posição da página ao clicar nos quadros e botões A pagar e Pagas
- [x] Manter somente A pagar e Pagas, removendo quadros e botões de recebimentos sem apagar registros
- [x] Abrir Motoristas, Veículos e Manutenção em janelas flutuantes sem substituir contas ou mover a página
- [x] Impedir salto ao topo ao abrir Motoristas, Veículos e Manutenção em Minhas Tarefas
- [x] Remover somente os três quadros Entradas, Gastos e Saldo em conta do Dashboard
- [x] Adicionar arrastar e confirmar zeramento visual do Crédito disponível, preservando cartões, Dashboard e relatórios
- [x] Restaurar crédito e débito reais no Início usando os mesmos saldos dos cartões, sem zeramento mensal
- [x] Modernizar os quatro quadros de contas em branco e cinza com ícones destacados, preservando funções e frota
- [x] Aplicar o mesmo visual aos filtros e botões abaixo dos quadros de contas
- [x] Remover a opção Combustível e KM e modernizar somente os quadros da frota, preservando registros e contas
- [x] Corrigir e validar aplicação e persistência das cores dos cartões sem alterar saldos
- [x] Modernizar a abertura nativa com carteira premium e fundo escuro sem alterar as demais telas
- [x] Abrir todas as abas e áreas de tarefas no topo, inclusive ao reabrir, em celular, tablet e computador
- [x] Organizar todos os quadros de contas e frota no celular e deixá-los maiores e dinâmicos no computador
- [x] Ampliar escolhas de notificações, ligar cada opção aos avisos e validar salvamento
- [x] Modernizar e destacar as quatro abas superiores com movimentos suaves, após escolha visual
- [x] Trocar Tarefa Financeira por Minhas Tarefas
- [x] Criar contas a pagar e receber, veículos e motoristas editáveis em Tarefas
- [x] Adicionar manutenção agendada e cálculo de combustível e quilômetros
- [x] Validar persistência privada e funcionamento das novas tarefas
- [x] Remover do Dashboard os gráficos Rendimentos dos investimentos, Moedas e Cartões mais usados ao lado de Moedas
- [x] Corrigir cortes e alinhamento dos textos dos cartões, priorizando o celular
- [x] Restaurar Início em todas as telas, fixo à esquerda, mantendo ícone e nome
- [ ] Aplicar identidade OBA! no login
- [ ] Fechar mensagens após excluir a última e incluir avisos de vencimento
- [ ] Substituir Relatórios por Tarefa Financeira com PDF profissional
- [x] Remover completamente o Claudinho e a conexão de áudio, conforme cancelamento do usuário
- [ ] Retirar buscas de Receitas e gastos
- [ ] Ajustar navegação inferior celular e computador
- [ ] Organizar textos, ações e cores dos cartões, sem barra percentual
- [ ] Zerar indicadores mensais do Início sem alterar saldos reais
- [ ] Verificar mudanças no celular e computador
- [ ] Permitir desativar e reativar clientes, bloquear acesso e preservar dados
- [x] Ocultar a marca “Edit with Lovable” nas publicações
- [x] Remover Acesso rápido e a aba Perfil
- [x] Ajustar abas superiores e inferiores no celular
- [x] Zerar todos os valores e lançamentos iniciais
- [x] Adicionar filtros por dia e mês aos relatórios
- [x] Transformar bancos em cartões com emblema, crédito e vencimento
- [x] Calcular rendimentos mensais automaticamente
- [x] Adicionar categorias predefinidas aos lançamentos
- [x] Permitir fotos editáveis nas metas
- [x] Validar o aplicativo no celular e no computador

# Novos ajustes
- [x] Permitir editar a cor de cada cartão
- [x] Adicionar notificações de rendimentos, orçamentos, metas e bate-papo
- [x] Adicionar forma de pagamento aos lançamentos
- [x] Retirar o bate-papo

- [x] Sincronizar dados em tempo real entre web, celular e tablet

# Totais e despesas fixas
- [x] Sincronizar Total investido com o capital investido de todos os bancos
- [x] Somar o rendimento mensal de todos os bancos investidos
- [x] Remover Orçamentos e Contas da navegação
- [x] Adicionar Despesas fixas mensais com edição, exclusão e baixa paga
- [x] Descontar cada pagamento uma única vez do Total em conta
- [x] Validar em celular, computador e duas sessões simultâneas

# Gastos e cartões
- [x] Descontar lançamentos de gastos do Total em conta
- [x] Recalcular o saldo ao editar ou excluir um gasto
- [x] Remover Descontos da tela Renda total
- [x] Deixar as letras do cartão Branco em negrito

# Investimentos e navegação
- [x] Remover Transferido dos investimentos
- [x] Calcular rendimento mensal sobre Investido menos Retirada
- [x] Remover a aba inferior Lançamentos
- [x] Validar no celular e publicar a atualização

# Leitura de receitas e gastos no celular
- [x] Reorganizar cada saída para impedir cortes de texto e valor
- [x] Validar no celular e publicar a atualização

# Relatórios em PDF
- [x] Destacar impostos separadamente sem duplicar os gastos
- [x] Modernizar o PDF geral e revisar documentos com várias páginas
- [x] Adicionar download em PDF para o dia ou mês selecionado
- [x] Incluir resumo, categorias e lançamentos no documento
- [x] Validar o download e a apresentação no celular

# Moedas e conversão
- [x] Adicionar Dólar e Euro abaixo dos investimentos
- [x] Permitir editar valores investidos e cotações manuais
- [x] Buscar cotações automáticas com fallback para o último valor salvo
- [x] Adicionar calculadora de conversão entre Real, Dólar e Euro
- [x] Validar sincronização e apresentação no celular
- [x] Exibir por extenso os equivalentes em Real
- [x] Corrigir o rendimento em Dólar e Euro a partir do valor investido em Real

# Gastos em moedas nos relatórios
- [x] Exibir os gastos do período em Real, Dólar e Euro
- [x] Separar os três totais por moeda dentro do PDF

# Notificações e despesas do exterior
- [x] Adicionar aviso diário do Total em conta às 08:00
- [x] Notificar pagamentos de despesas fixas e do exterior
- [x] Adicionar despesas do exterior editáveis com Pago e Pendente
- [x] Descontar pagamentos exteriores uma única vez do rendimento na moeda correspondente, sem alterar o Total em conta

# Navegação da calculadora
- [x] Remover a calculadora da área Moedas
- [x] Criar a aba inferior Conversão ao lado de Metas com as mesmas funções
- [x] Validar a nova aba no celular

# Relatórios independentes por moeda
- [x] Remover conversão automática entre Real, Dólar e Euro nos relatórios
- [x] Somar cada gasto somente na moeda em que foi lançado
- [x] Gerar PDF geral com totais por moeda e lançamentos separados por categoria
- [x] Validar o relatório e todas as páginas do PDF no celular

# Modernização visual
- [x] Aplicar paleta Oceano Coral e novas tipografias
- [x] Criar blocos dinâmicos com vidro e profundidade 3D
- [x] Validar todas as funções e a apresentação no celular e computador

# Dashboard financeiro
- [x] Criar aba inferior Dashboard ao lado de Despesas fixas
- [x] Exibir gastos, entradas, moedas, cartões mais usados e rendimentos
- [x] Permitir escolher o cartão usado em cada lançamento
- [x] Incluir o resumo do Dashboard no PDF filtrado
- [x] Validar a nova aba e o PDF no celular

# Gráficos dinâmicos
- [x] Transformar movimentações, moedas, cartões e rendimentos em gráficos interativos
- [x] Adicionar seleção dinâmica de período para entradas e gastos
- [x] Validar os gráficos no celular e computador

# Reformulação financeira e visual
- [x] Apresentar opções profissionais para a nova tela inicial escura e 3D
- [x] Remover Perfil, edição de nome, Metas, Renda total e lançamentos da tela inicial
- [x] Exibir seletor de Real, Dólar e Euro e destacar a foto da conta sincronizada
- [x] Reorganizar Despesas fixas e Relatórios na navegação
- [x] Integrar entradas, gastos, crédito, débito, investimentos e despesas fixas
- [x] Criar Investimentos no exterior com câmbio, valores por extenso e despesas sincronizadas
- [x] Exibir Selic atualizada e calcular retiradas com IOF
- [x] Escrever por extenso o resultado da calculadora de conversão
- [x] Atualizar cartões com Crédito, Débito e Investimentos
- [ ] Validar sincronização e apresentação em celular, tablet e computador

# Saldos dos cartões
- [x] Adicionar lançamento de saldo em débito ao cadastrar ou editar cartão
- [x] Somar saldos disponíveis em crédito e débito ao Saldo total da tela Início
- [x] Remover Branco da seleção de cores dos cartões
- [x] Validar cadastro e totais sincronizados no celular

# Investimentos dos cartões
- [x] Exibir em cada cartão o valor investido cadastrado nele
- [x] Somar os investimentos dos cartões na tela Início
- [x] Validar a sincronização no celular

# Tela Início
- [x] Remover o bloco de moedas da tela Início
- [x] Remover somente o Saldo total disponível, preservando Entradas, Gastos totais e Investimentos dos cartões
- [x] Remover a Calculadora de Conversão e sua aba inferior

# Novo lançamento
- [x] Adicionar a opção Nenhum no campo Aplicar em

# Despesas fixas por mês
- [x] Remover Total em conta da tela Despesas fixas
- [x] Separar despesas pendentes, pagas e todas no mês escolhido
- [x] Manter a baixa mensal sincronizada entre aparelhos
- [x] Validar os filtros mensais no celular

# Pagamento de despesas fixas
- [x] Perguntar qual cartão será usado no pagamento
- [x] Perguntar se o pagamento será no Crédito ou Débito
- [x] Vincular o lançamento da baixa ao cartão e modo escolhidos
- [x] Validar o pagamento vinculado no celular

# Débito disponível
- [x] Somar no Início exatamente os saldos de débito exibidos em cada cartão
- [x] Validar o total sincronizado no celular

# Bloqueio por saldo do cartão
- [x] Avisar quando o Crédito ou Débito do cartão escolhido não cobrir a compra
- [x] Impedir o lançamento sem saldo suficiente
- [x] Permitir escolher outro cartão ou forma de pagamento
- [x] Aplicar a mesma proteção aos pagamentos de despesas fixas
- [x] Validar o bloqueio no celular

# Cartões (Etapa 1)
- [x] Bandeira editável: Visa, Mastercard, Elo, American Express ou Nenhuma
- [x] Barra de uso do limite em porcentagem
- [x] Aviso de vencimento próximo
- [x] Status Ativo, Bloqueado ou Arquivado
- [x] Cartão principal
- [x] Letras maiores e contorno no cartão preto

# Próximas etapas (aguardando)
- [x] Etapa 2: Início e Receitas e gastos
- [x] Etapa 3: Investimentos exterior, Dashboard e ocultar Dashboard no celular
- [x] Etapa 4: Tela de login moderna e 3 opções de logo
- [x] Logo Carteira digital aplicado ao login e ícones do app

# Ajustes atuais
- [x] Início do computador cabendo na tela sem rolar
- [x] Círculo da IA CRALL no canto superior, ao lado do nome CRALL GESTOR
- [x] Círculo da IA com cor azulada dinâmica estilo ChatGPT
- [x] CRALL ao lado do nome CRALL GESTOR no menu lateral (PC)
- [x] Aumentar os cards Crédito disponível e Gastos totais no Início do PC
- [x] Aviso de estoque baixo na aba Estoque da Lista de Compras
- [x] Roleta radial no celular: Início intacto, deslizar esquerda abre roleta (Cartões, Receitas e Gastos, Despesas Fixas, Minhas Tarefas, FrotaPro admin), direita volta; dois indicadores finos; botão [← Voltar] discreto à esquerda; sem cards abaixo da roleta; voltar nativo do celular funcionando; gestos ida/volta testados na conta conectada, build OK
- [x] Miniaturas dos cartões (~64×40) nas saídas/compras das Últimas Atividades e nos relatórios PDF: Santander SX Visa, Safra Visa, PicPay Black Mastercard, Caixa Elo Mais, Banco do Brasil, Mercado Pago, C6 Mastercard; reconhecimento por nome testado (7/7), entradas sem miniatura, cartões desconhecidos mantêm ícone antigo; cadastros e saldos intactos; build OK
- [x] Tecla ESC fecha a aba aberta: primeiro a janela do sino, clientes, avisos e da CRALL; depois a seção, voltando ao Início; Funcionários e Compras voltam ao painel e o FrotaPro avisa o app para fechar; diálogos do sistema fecham sozinhos; 4 testes aprovados e ida/volta conferida na prévia (Cartões→Início e Funcionários→painel)
- [x] Número de cadastro sequencial (01, 02, 03…) na lista e no cadastro de funcionários, salvo junto do registro e sem reaproveitar números de cadastros excluídos; exibição conferida na prévia com cadastro temporário removido depois; 5 testes aprovados
- [x] Nome CRALL GESTOR maior no menu lateral do computador e na tela de entrada, sem cortes nem sobreposição; conferido na prévia
- [x] Escrever somente o nome Crall Point (grafia corrigida, letras certas) no menu lateral, abaixo de FrotaPro; nada mais criado
- [x] Abrir a tela Crall Point pelo menu lateral: foto, nome, horário e tipo de batida (Entrada, Intervalo, Retorno, Saída); batidas podem ser registradas aqui e a mesma lista fica pronta para sincronizar com outro aplicativo depois; 5 testes aprovados, batidas de teste removidas e build OK
- [ ] Controle de ponto dos funcionários (entrada, saída, horas do dia e total do mês): adiada, aguardando pedido do usuário

- [x] Ajustar avisos dinâmicos laterais, atalho compacto, recebimentos Pix/transferência, destaque de doações e lançamento no topo; filtros salvos e janela em tela baixa conferidos, registros temporários removidos.
- [x] Restaurar bloco de notas e calculadora no cabeçalho do computador; ambas as janelas abertas na conta conectada.
- [x] Restaurar informativos da bolsa no cabeçalho; valores carregados conferidos.
- [x] Maiúscula automática na primeira letra e após ponto em campos de texto; digitação real e quatro testes conferidos, preservando emails e senhas.
- [x] PIN de quatro dígitos em aparelhos autorizados: cadastro, rejeição de PIN incorreto, bloqueio ao recarregar e desbloqueio conferidos; autenticação preservada.
- [x] Em aparelhos novos exigir confirmação digitada do nome CLAUDINEY, além da autorização da conta; nome incorreto rejeitado em teste conectado.
